const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_mark_spam_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const post_comment_id = req.body.post_comment_id;
          const type = req.body.type;
          const community_id = req.body.community_id;
          //new parameter in v1
          /* $user_id =45;
                     $post_comment_id = 3;
                    $type = 'post';
                    $community_id = 49; */
          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `" and user_hash="` +
            user_hash +
            `"`;
          var user_Data = (await query(sql, conn))[0];
          const jsonArray = {};
          var voteArry;

          if (user_Data.user_count > 0) {
            //log_message('debug','in mark_spam_v2 webservice');
            //log_message('debug','data parameters in post '.print_r($_POST,true).'');
            //$catRow = $this->db->get_where('edu_groups',array('id' => $community_id))->row_array();

            if (type == 'post') {
              sql =
                `SELECT * FROM edu_user_post WHERE post_id="` +
                post_comment_id +
                `" AND user_id= "` +
                user_id +
                `"`;
              var eduvoteRow = await query(sql, conn2);
            } else {
              sql =
                `SELECT * FROM edu_user_post WHERE comment_id="` +
                post_comment_id +
                `" AND user_id="` +
                user_id +
                `"`;
              var eduvoteRow = await query(sql, conn2);
            }
            if (eduvoteRow) {
              if (eduvoteRow.mark_spam == 0 || eduvoteRow.mark_spam == null) {
                sql =
                  `UPDATE edu_user_post SET mark_spam = 1 WHERE id ="` +
                  eduvoteRow +
                  `"`;
                await query(sql, conn2);

                if (type == 'post') {
                  // $postRow = $db2->get_where('edu_post', array('id' => $post_comment_id))->row_array();
                  sql =
                    `SELECT*FROM edu_post WHERE id="` + post_comment_id + `"`;
                  var postRow = await query(sql, conn2);

                  sql =
                    `UPDATE edu_post SET spam_count = "` +
                    postRow.spam_count +
                    1 +
                    `" WHERE id ="` +
                    post_comment_id +
                    `"`;
                  await query(sql, conn2);
                } else {
                  //$commentRow = $db2->get_where('edu_post_comment', array('id' => $post_comment_id))->row_array();

                  sql = `SELECT*FORM edu_comment.id ="` + post_comment_id + `"`;
                  var commentRow = await query(sql, conn2);

                  sql =
                    `UPDATE edu_post_comment SET spam_count ="` +
                    commentRow.spam_count +
                    1 +
                    `"WHERE id ="` +
                    post_comment_id +
                    `"`;
                }
                jsonArray.flag = 1;
              } else {
                jsonArray.flag = 2;
              }
            } else {
              voteArry = [
                {
                  user_id: user_id,
                  type: type,
                  mark_spam: 1,
                  date: Date('Y-m-d H:i:s'),
                },
              ];
              if (type == 'post') {
                voteArray.post_id = post_comment_id;
              } else {
                voteArray.comment_id = post_comment_id;
              }
              //$db2->insert('edu_user_post', $voteArray);

              sql = `INSERT INTO edu_post VALUES post_comment_id`;
              postRow = await query(sql, conn2);

              if (type == 'post') {
                sql = `SELECT*FROM edu_post WHERE id="` + post_comment_id + `"`;
                var postRow = await query(sql, conn2);

                sql =
                  `UPDATE edu_post SET spam_count = postRow.spam_count+ 1 WHERE id ="` +
                  post_comment_id +
                  `"`;
                await query(sql, conn2);
              } else {
                sql = `SELECT*FORM edu_comment.id ="` + post_comment_id + `"`;
                var commentRow = await query(sql, conn2);

                sql =
                  `UPDATE edu_post_comment SET spam_count = commentRow.spam_count+1 WHERE id ="` +
                  post_comment_id +
                  `"`;
              }
              jsonArray.flag = 1;
            }
            res.send(jsonArray);
          } else {
            jsonArray.flag = 5;
            res.send(jsonArray);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
