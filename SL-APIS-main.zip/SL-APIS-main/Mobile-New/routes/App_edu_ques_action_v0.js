const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_ques_action_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const post_id = req.body.post_id;
          const user_response = req.body.user_response;
          const quesData = {};

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `" and user_hash="` +
            user_hash +
            `"`;
          user_Data = (await query(sql, conn))[0];
          console.log(user_Data);

          if (user_Data.user_count > 0) {
            console.log('debug', 'in Edu_ques_action service');
            console.log('debug', 'data in post - ' + req.body + '');

            // $postRow = $db2->get_where('edu_post', array('id' => $post_id))->row_array();
            var sql = `SELECT * FROM edu_post WHERE id ="` + post_id + `"`;
            var postRow = await query(sql, conn2);

            //  $attemptRow = $db2->query("SELECT * FROM edu_user_post WHERE user_id=" . $user_id . " AND post_id=" . $post_id . "")->row_array();
            var sql =
              `SELECT * FROM edu_user_post WHERE user_id="` +
              user_id +
              `"AND post_id="` +
              post_id +
              `"`;
            var attemptRow = await query(sql, conn2);

            if (attemptRow) {
              const voteData = [
                {
                  post_id: post_id,
                  type: 'question',
                  user_id: user_id,
                  response_question: user_response,
                  date: Date('Y-m-d H:i:s'),
                },
              ];

              if (
                attemptRow.id != '' &&
                attemptRow.id != null &&
                attemptRow.id != 0
              ) {
                //$db2->where('id', $attemptRow['id']);
                //$db2->update('edu_user_post', array('response_question' => $user_response));
                var sql =
                  `UPDATE edu_user_post SET response_question ="` +
                  user_response +
                  `"WHERE id="` +
                  attemptRow.id +
                  `"`;
              }
            } else {
              var voteData = [
                {
                  post_id: post_id,
                  type: 'question',
                  user_id: user_id,
                  response_question: user_response,
                  date: Date('Y-m-d H:i:s'),
                },
              ];

              //$db2->insert('edu_user_post', $voteData);
              var sql = `INSERT edu_user-post ="` + voteData + `"`;
            }

            if (user_response == postRow.correct_response) {
              quesData.is_ques_correct = 1;
              quesData.attemptmsg =
                `You correctly answered "` + user_response + `"`;
            } else {
              quesData.is_ques_correct = 0;
              quesData.attemptmsg =
                `You answered "` +
                user_response +
                `"Correct answer is "` +
                postRow.correct_response +
                `"`;
            }

            quesData.flag = 1;

            res.send(quesData);
          } else {
            quesData.flag = 5;
            res.send(quesData);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
