const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

function ucfirst(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

router.post('/App_fetch_inst_post_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const data = {};
          data.app_id = req.body.app_id;
          data.post_type = req.body.post_type;
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          var sql = `select count(*)as user_count from user_detail where user_id=${data.user_id} and user_hash="${data.user_hash}"`;
          var user_Data = (await query(sql, conn))[0];

          if (user_Data.user_count > 0) {
            var sql = `SELECT * FROM edu_post WHERE app_id =${data.app_id} AND post_type = "${data.post_type}" AND status = "publish" order by id desc limit 30`;

            post_Data = await query(sql, conn2);

            if (post_Data) {
              const post_inst_data = [];
              var j = 0;

              await Promise.all(
                post_Data.map(async (post) => {
                  post_inst_data.push({
                    post_id: post.id,
                    community_id: post.community_id,
                    app_id: parseInt(post.app_id),
                    user_id: post.user_id,
                    fname: ucfirst(post.user_first_name),
                    lname: ucfirst(post.user_last_name),
                    post_type: post.post_type,
                    post_title: post.title,
                    //post_description : substr(strip_tags(post.description),0,80),
                    post_description: post.description,
                    video_url: post.video_url,
                    user_org_name: post.user_org_name,
                    comment_count: parseInt(post.comment_count),
                    upvote_count: parseInt(post.upvote_count),
                    view_count: Math.ceil((post.view_count + 1) / 3),
                    city_name: post.user_city,
                    spam_count: parseInt(post.spam_count),
                    post_date: post.add_date,
                    is_notify: parseInt(post.is_notify),
                    tag: post.tag,
                    question_reward: post.question_reward,
                    correct_response: post.correct_response,
                    status: post.status,
                    is_user_post: 0,
                    display_type: post,
                    reserve_1: post.reserve_1,
                    group_hash_tag: post.group_hash_tag,
                    ques_attempt_flag: 0,
                    is_ques_correct: 0,
                    attemptmsg: '',
                    user_image: post.user_image_url,
                  });

                  if (post.description == '' || post.description == null) {
                    post_inst_data[j].post_description = '';
                  }

                  if (post.image != '' && post.image != null) {
                    post_inst_data[j].post_image = post.image;
                  } else {
                    post_inst_data[j].post_image = '';
                  }
                  sql = `SELECT * from edu_user_post where user_id=${data.user_id} and post_id=${post.id} and mark_upvote=1`;

                  var q = await query(sql, conn2);
                  if (q.length > 0) {
                    post_inst_data[j].upvoteFlag = 1;
                  } else {
                    post_inst_data[j].upvoteFlag = 0;
                  }
                  var postuser = post.user_type;
                  if (
                    post.user_job_title != '' &&
                    post.user_job_title != null
                  ) {
                    post_inst_data[j].job_title = post.user_job_title;
                  } else if (
                    postuser.indexOf('Student') !== null &&
                    postuser.indexOf('Student') !== -1
                  ) {
                    post_inst_data[j].job_title = 'Student';
                  } else if (
                    postuser.indexOf('Parent') !== null &&
                    postuser.indexOf('Parent') !== -1
                  ) {
                    post_inst_data[j].job_title = 'Parent';
                  } else if (
                    postuser.indexOf('Teacher') !== null &&
                    postuser.indexOf('Teacher') !== -1
                  ) {
                    post_inst_data[j].job_title = 'Teacher';
                  } else {
                    post_inst_data[j].job_title = '';
                  }
                  j++;
                })
              );

              post_Data = post_inst_data;
            } else {
              var post_Data = [];
            }

            res.json(post_Data);
          } else {
            var post_data = [];
            post_data.flag = 5;

            res.json(post_Data);
          }

          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
