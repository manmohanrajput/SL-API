const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_fetch_version_code_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const app_id = req.body.app_id;
      const app_hash = req.body.app_hash;
      var app_details = {};
      var sql =
        `select * from mob_app_detail where app_hash="` +
        app_hash +
        `" and app_id="` +
        app_id +
        `"`;
      const appData = await query(sql, conn);
      console.log(appData);
      if (appData) {
        if (appData.app_force_update) {
          app_details.flag = 1;
          app_details.version_code = appData.app_force_update;
          app_details.splash_url = appData.splash_url;
        } else {
          app_details.flag = 1;
          app_details.version_code = 71;
          app_details.splash_url = '';
        }
      } else {
        app_details.flag = 5;
        app_details.version_code = [];
        app_details.splash_url = '';
      }

      res.json(app_details);
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
