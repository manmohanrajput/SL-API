const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_view_user_profile_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;
      const selected_user_id = req.body.selected_user_id;
      var userData;
      var sql =
        `select count(*)as user_count from user_detail where user_id="` +
        user_id +
        `" and user_hash="` +
        user_hash +
        `"`;
      const user_Data = await query(sql, conn);
      console.log(user_Data);
      if (user_Data[0].user_count > 0) {
        sql =
          `SELECT user_detail.*,city_master.city_name,state.state_name FROM user_detail LEFT JOIN city_master ON user_detail.user_city_id=city_master.city_id LEFT JOIN state ON user_detail.user_state_id=state.state_id WHERE user_detail.user_id="` +
          selected_user_id +
          `"`;
        const userRow = await query(sql, conn);
        console.log(userRow);

        if (userRow) {
          userData = {
            fname: userRow.user_first_name,
            lname: userRow.user_last_name,
            city: userRow.user_city_name,
            state: userRow.user_state_name,
            org_name: userRow.org_name,
            job_title: userRow.job_title,
            subject: userRow.subject,
          };

          if (userRow.job_title != '' && userRow.job_title != null) {
            userData.job_title = userRow.job_title;
          } else if (
            userRow[0].user_type !== null &&
            userRow[0].user_type.indexOf('Student') !== -1
          ) {
            userData.job_title = 'Student';
          } else if (
            userRow[0].user_type !== null &&
            userRow[0].user_type.indexOf('Parent') !== -1
          ) {
            userData.job_title = 'Parent';
          } else if (
            userRow[0].user_type !== null &&
            userRow[0].user_type.indexOf('Teacher') !== -1
          ) {
            userData.job_title = 'Teacher';
          } else {
            userData.job_title = '';
          }

          if (
            userRow[0].user_photo !== null &&
            userRow[0].user_photo.indexOf('https') !== -1
          ) {
            //$userData['user_image'] = $userRow['user_image_url'];
            userData.user_image = userRow.user_photo;
          } else if (userRow.user_photo == '') {
            userData.user_image = '';
          } else {
            userData.user_image =
              'S3URL1' + 'mcluserimage/' + userRow.user_photo + '';
          }

          userData.flag = 1;
        } else {
          userData.flag = 0;
        }
        res.send(userData);
      } else {
        userData.flag = 5;
        res.send(userData);
      }
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
