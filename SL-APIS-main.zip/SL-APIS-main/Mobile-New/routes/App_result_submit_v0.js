const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const pool4 = require('../config/db4');
const query = require('../utils/query');
const mandrill = require('mandrill-api');
const mandrill_client = new mandrill.Mandrill('bAV03zWPNHiodhkVXNkhLQ');
function roundLikePHP(num, dec) {
  var num_sign = num >= 0 ? 1 : -1;
  return parseFloat(
    (
      Math.round(num * Math.pow(10, dec) + num_sign * 0.0001) /
      Math.pow(10, dec)
    ).toFixed(dec)
  );
}

function rtrim(str, chr) {
  var rgxtrim = !chr ? new RegExp('\\s+$') : new RegExp(chr + '+$');
  return str.replace(rgxtrim, '');
}

router.post('/App_result_submit_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          pool4.getConnection(async (err, conn4) => {
            if (err) {
              console.log(err);
              return res.status(500).send('Server Error');
            } else {
              const ques_string = req.body.ques_string;
              const user_id = req.body.user_id;
              const user_hash = req.body.user_hash;
              const test_hash = req.body.test_hash;
              const rgcmid = req.body.rgcmid;
              const positive_mark = req.body.positive_mark;
              const negative_mark = req.body.negative_mark;
              var quesResponse = {};
              console.log('debug', 'in ots_result_submit_v5 service');

              if (user_id > 0) {
              } else {
                console.log('user not authorised');
                die;
                
              }

              // $user_Data = $this->db->query("select count(*)as user_count from user_detail where user_id=" . $user_id . " and user_hash='" . $user_hash . "'")->row_array();
              var sql = `select count(*)as user_count from user_detail where user_id= ${user_id} and user_hash=  "${user_hash}"`;
              var user_Data = await query(sql, conn);
              if (user_Data[0].user_count > 0) {
                //$mobTestData = $this->db->query("SELECT test_id,exam_id,test_type,test_name FROM mob_test_master WHERE mob_test_hash='" . $test_hash . "'")->row_array();
                sql = `SELECT test_id,exam_id,test_type,test_name FROM mob_test_master WHERE mob_test_hash="${test_hash}"`;
                var mobTestData = await query(sql, conn);
                console.log(mobTestData);
                var test_id = mobTestData[0].test_id;

                // $mobExamData = $this->db->query("SELECT hash_tag FROM mob_exam WHERE id=" . $mobTestData['exam_id'] . "")->row_array();
                sql = `SELECT hash_tag FROM mob_exam WHERE id=${mobTestData[0].exam_id}`;
                var mobExamData = await query(sql, conn);
                var quesData = ques_string.split('|');

                quesData.forEach((quesdata) => {
                  var arr = quesdata.split('#');
                });

                //$arr[] = explode('#', $quesdata);

                var correctCount = 0;
                var inCorrectCount = 0;
                var notAttemptCount = 0;

                sql = `SELECT res_id FROM mob_result WHERE res_test_id= ${test_id} AND res_user_id= ${user_id}`;
                var check_res_query = await query(sql, conn);
                var res_count = check_res_query.length;

                if (res_count > 0) {
                  quesResponse.flag = 'already attempt';
                  quesResponse.authFlag = 1;
                } else {
                  var quesIds = '';
                  arr.forEach((ques) => {
                    quesIds += ques[0] + ',';
                    userResp = ques[1];
                  });
                  //$testMasterData = $this->db->query("SELECT test_type,test_name FROM mob_test_master WHERE test_id=" . $test_id . "")->row_array();

                  if (mobTestData.test_type == 'TGEN') {
                    //$quesData = $this->db->query("SELECT * FROM ots_question_master WHERE ques_id IN(" . rtrim($quesIds, ',') . ") ORDER BY FIELD(ques_id," . rtrim($quesIds, ',') . ")")->result_array();
                    sql = `SELECT * FROM ots_question_master WHERE ques_id IN( ${rtrim(
                      quesIds,
                      ','
                    )}) ORDER BY FIELD(ques_id, ${trim(quesIds, ',')}`;
                    var quesData = await query(sql, conn);
                  } else {
                    // $quesData = $this->db->query("SELECT * FROM ots_question_master WHERE ques_id IN(" . rtrim($quesIds, ',') . ") ORDER BY seq_no ASC")->result_array();
                    sql = `SELECT * FROM ots_question_master WHERE ques_id IN( ${rtrim(
                      quesIds,
                      ','
                    )}) ORDER BY seq_no ASC`;
                    var quesData = await query(sql, conn);
                  }

                  var x = 0;
                  quesData.forEach((row) => {
                    if (mobTestData.test_type == 'TGEN') {
                      ques_desc = row.question;
                      opt_correct = row.opt_correct;
                      exp_answer = row.exp_answer;
                      q_id = row.ques_id;
                    } else {
                      ques_desc = row.question;
                      opt_correct = row.opt_correct;
                      exp_answer = row.exp_answer;
                      q_id = row.ques_id;
                    }
                    quesResponse.ques = [];
                    if (quesData) {
                      quesResponse.flag = 1;
                      quesResponse.authFlag = 1;
                      if (userResp[x] == opt_correct) {
                        data = [
                          {
                            ques_id: q_id,
                            ques_desc: ques_desc,
                            opt_1: row.opt_1,
                            opt_2: row.opt_2,
                            opt_3: row.opt_3,
                            opt_4: row.opt_4,
                            opt_5: row.opt_5,
                            correct_opt: opt_correct,
                            ques_expl: exp_answer,
                            user_response: userResp[x],
                            ques_status: 'correct',
                          },
                        ];
                        quesResponse.ques.push(data);
                        correctCount++;
                      } else if (userResp[x] == 0) {
                        var data = [
                          {
                            ques_id: q_id,
                            ques_desc: ques_desc,
                            opt_1: row.opt_1,
                            opt_2: row.opt_2,
                            opt_3: row.opt_3,
                            opt_4: row.opt_4,
                            opt_5: row.opt_5,
                            correct_opt: opt_correct,
                            ques_expl: exp_answer,
                            user_response: 0,
                            ques_status: 'not attempt',
                          },
                        ];
                        quesResponse.ques.push(data);
                        notAttemptCount++;
                      } else {
                        var data = [
                          {
                            ques_id: q_id,
                            ques_desc: ques_desc,
                            opt_1: row.opt_1,
                            opt_2: row.opt_2,
                            opt_3: row.opt_3,
                            opt_4: row.opt_4,
                            opt_5: row.opt_5,
                            correct_opt: opt_correct,
                            ques_expl: exp_answer,
                            user_response: userResp[x],
                            ques_status: 'incorrect',
                          },
                        ];
                        quesResponse.ques.push(data);
                        inCorrectCount++;
                      }
                    } else {
                      quesResponse.flag = 0;
                      quesResponse.authFlag = 1;
                    }

                    x++;
                  });
                  if (quesResponse.flag == 1) {
                    quesResponse.percentage = roundLikePHP(
                      (correctCount /
                        (correctCount + inCorrectCount + notAttemptCount)) *
                        100,
                      2
                    );
                    quesResponse.totCorrect = correctCount;
                    quesResponse.totIncorrect = inCorrectCount;
                    quesResponse.notAttempt = notAttemptCount;
                    quesResponse.mark_obtain =
                      correctCount * positive_mark -
                      inCorrectCount * negative_mark;
                    resultData = [
                      {
                        res_test_id: test_id,
                        res_user_id: user_id,
                        res_correct_ans: correctCount,
                        res_wrong_ans: inCorrectCount,
                        res_per_obtain: quesResponse.percentage,
                        res_positive_mark: positive_mark,
                        res_negative_mark: negative_mark,
                        res_created: Date('Y-m-d h:i:s'),
                      },
                    ];
                    //    $this->db->insert('mob_result', $resultData);
                    sql = `INSERT INTO mob_result ( res_test_id, res_user_id,res_correct_ans,res_wrong_ans,res_per_obtain,res_positive_mark,res_negative_mark,res_created) VALUES (${resultData.res_test_id},${resultData.res_user_id},${resultData.res_correct_ans},${resultData.res_wrong_ans},${resultData.res_per_obtain},${resultData.res_positive_mark},${resultData.res_negative_mark},${resultData.res_created})`;
                    //  $last_res_id = $this->db->insert_id();
                    var last_res_id = await query(sql, conn);
                  }

                  var y = 0;
                  if (quesData) {
                    quesData.forEach((row) => {
                      if (mobTestData.test_type == 'TGEN') {
                        ques_desc = row.question;
                        opt_correct = row.opt_correct;
                        exp_answer = row.exp_answer;
                        q_id = row.ques_id;
                      } else {
                        ques_desc = row.question;
                        opt_correct = row.opt_correct;
                        exp_answer = row.exp_answer;
                        q_id = row.ques_id;
                      }

                      var mobResultAnsData = [
                        {
                          mr_id: last_res_id,
                          mra_ques_id: q_id,
                          mra_ans_key: opt_correct,
                          mra_user_key: userResp[y],
                          //    'mra_reward' => 0,
                        },
                      ];

                      mobResultAnsDataBatch = mobResultAnsData;

                      y++;
                    });

                    // $this->db->insert_batch('mob_result_ans', $mobResultAnsDataBatch);
                    sql = `INSERT INTO mob_result_ans ${mobResultAnsDataBatch}`;
                  }

                  //  $userRow = $this->db->get_where('master_user_login', array('user_id' => $user_id, 'email_verified' => 'yes'))->row_array();
                  sql = `SELECT * FROM master_user_login WHERE user_id =${user_id},email_verfied ='yes'`;
                  var userRow = await query(sql, conn);
                  //  $userDetailRow = $this->db->query("SELECT app_id,user_first_name,user_last_name,user_image_url FROM user_detail WHERE user_id=" . $user_id . "")->row_array();
                  sql = `SELECT app_id,user_first_name,user_last_name,user_image_url FROM user_detail WHERE user_id= ${user_id}`;
                  var userDetailRow = await query(sql, conn);
                  /*             * *** sending mail of question reward ****** */

                  var schol_email_text = '';
                  //if ($quesResponse['percentage'] >= 40) {
                  //  $db2 = $this->load->database('discussiondb', TRUE);
                  //  $scholAvailPostData = $db2->query("SELECT * FROM edu_post WHERE user_id=" . $user_id . " AND community_id=445")->result_array();
                  sql = `SELECT * FROM edu_post WHERE user_id= ${user_id} AND community_id=445`;
                  var scholAvailPostData = await query(sql, conn2);
                  var reserve_inst_ids = '';
                  if (scholAvailPostData) {
                    scholAvailPostData.forEach((scholAvailPost) => {
                      //  $reserve_inst_ids .= (string)$scholAvailPost['reserve_1'] . ',';
                      reserve_inst_ids += scholAvailPost.reserve_1 + ',';
                    });
                  } else {
                    var reserve_inst_ids = '';
                  }

                  if (reserve_inst_ids != '') {
                    eserve_inst_ids_arr = rtrim(reserve_inst_ids, ',').split(
                      ','
                    );
                    //  reserve_inst_ids_IN = "'".implode("','",$reserve_inst_ids_arr)."'";
                    var reserve_inst_ids_IN = reserve_inst_ids_arr.join("','");
                    var check_schol_avail_clause =
                      'AND im_hash NOT IN($reserve_inst_ids_IN)';
                  } else {
                    var check_schol_avail_clause = '';
                  }

                  //echo "SELECT * FROM career_inst_microsite WHERE hash_tag LIKE '%CLAT%' AND schol_tab_text IS NOT NULL " . $check_schol_avail_clause . " LIMIT 1";die;
                  if (
                    mobExamData.hash_tag != '' &&
                    mobExamData.hash_tag != null
                  ) {
                    // $db3 = $this->load->database('b2clmsdb', TRUE);
                    //$instMicrositeData = $db3->query("SELECT * FROM career_inst_microsite WHERE hash_tag LIKE '%" . $mobExamData['hash_tag'] . "%' AND schol_tab_text IS NOT NULL " . $check_schol_avail_clause . " LIMIT 1")->row_array();
                    sql = `SELECT * FROM career_inst_microsite WHERE hash_tag LIKE %  ${mobExamData.hash_tag} % AND schol_tab_text IS NOT NULL  ${check_schol_avail_clause} LIMIT 1`;
                    var instMicrositeData = await query(sql, conn4);
                  } else {
                    var instMicrositeData = [];
                  }

                  if (instMicrositeData) {
                    var scholPostData = [
                      {
                        user_id: user_id,
                        user_first_name: userDetailRow.user_first_name,
                        user_last_name: userDetailRow.user_last_name,
                        user_image_url: userDetailRow.user_image_url,
                        community_id: 445,
                        tag: 'Scholarship',
                        post_type: 'scholarship',
                        title: instMicrositeData.im_name,
                        description: instMicrositeData.schol_tab_text,
                        status: 'publish',
                        reserve_1: instMicrositeData.im_hash,
                        add_date: Date('Y-m-d H:i:s'),
                      },
                    ];

                    //  $db2 = $this->load->database('discussiondb', TRUE);
                    // $db2->insert('edu_post', $scholPostData);
                    sql = `INSERT INTO edu_post (  user_id,user_first_name,user_last_name,user_image_url ,community_id ,tag ,post_type,title ,description ,status,reserve_1 ,add_date) VALUES (${scholPostData.user_id},${scholPostData.user_first_name},${scholPostData.user_last_name},${scholPostData.user_image_url},${scholPostData.community_id},${scholPostData.tag},${scholPostData.post_type},${scholPostData.title},${scholPostData.description},${scholPostData.status},${scholPostData.reserve_1},${scholPostData.add_date})`;
                    await query(sql, conn2);
                    schol_email_text =
                      'Scholarship from ' +
                      instMicrositeData.im_name +
                      '<br />';
                    schol_email_text += instMicrositeData.schol_tab_text;
                  } else {
                    schol_email_text = '';
                  }
                  //}

                  if (userRow) {
                    // $appData = $this->db->get_where('mob_app_detail', array('app_id' => $userDetailRow['app_id']))->row_array();
                    sql = `SELECT * FROM mob_app_detail WHERE app_id= ${userDetailRow.app_id}`;
                    var appData = await query(sql, conn);
                    if (userDetailRow.app_id > 1000) {
                      from_email = appData.org_email;
                    } else if (appData) {
                      from_email = appData.org_email;
                    } else {
                      from_email = 'noreply@educationalemail.com';
                    }

                    //  require_once './maillib/src/Mandrill.php';

                    //  $mandrill = new Mandrill('bAV03zWPNHiodhkVXNkhLQ');
                    /* Added tag on 15 may,18 by aish */
                    const sendEmail = async (
                      emailContent,
                      targetEmailAddress
                    ) => {
                      var message = {
                        subject: `Test Report -  + ${appData.org_name} `,
                        from_email: from_email,
                        to: {
                          email: '' + userRow.email + '',
                          name: '' + userRow.fname + '',
                        },
                        headers: { 'Reply-To': 'noreply@educationalemail.com' },
                        merge_vars: [
                          {
                            rcpt: '' + userRow.email + '',
                            vars: [
                              {
                                name: 'CLF',
                                content: '' + userRow.fname + '',
                              },
                              {
                                name: 'MCLF',
                                content: '' + userRow.lname + '',
                              },
                              {
                                name: 'TESTNAME',
                                content: '' + mobTestData.test_name + '',
                              },
                              {
                                name: 'TOTALQUES',
                                content: '' + y + '',
                              },
                              {
                                name: 'RQUES',
                                content: '' + correctCount + '',
                              },
                              {
                                name: 'WQUES',
                                content: '' + inCorrectCount + '',
                              },
                              {
                                name: 'URL',
                                content: '' + appData.org_url + '',
                              },
                              {
                                name: 'Reply_To',
                                content: '' + appData.reply_to + '',
                              },
                              {
                                name: 'Mailing_Add',
                                content: '' + appData.org_address + '',
                              },
                              {
                                name: 'scholarship_text',
                                content: '' + schol_email_text + '',
                              },
                            ],
                          },
                        ],
                        tags: ['mob_test_report'],
                      };

                      /* Added By Padam Jain 31-12-2018 */
                      if (
                        userDetailRow.app_id > 1000 &&
                        userDetailRow.app_id < 100000
                      ) {
                        if (userDetailRow.app_id == 1043) {
                          template_name = 'Neu_TestReportEmail_Mob_v1_mcl';
                        } else {
                          var template_name = 'Neu_TestReportEmail_Mob_v1';
                        }
                      } else {
                        /* End Added By Padam Jain 31-12-2018 */
                        var template_name = 'Neu_TestReportEmail_Mob_v1_mcl';
                        /* Added By Padam Jain 31-12-2018 */
                      }
                      /* End Added By Padam Jain 31-12-2018 */
                      // log_message('debug', 'App & Template: '.$userDetailRow['app_id']." --- ".$template_name);
                      var template_content = [
                        [
                          {
                            name: 'main',
                            content: 'Hi',
                          },
                        ],
                        [
                          {
                            name: 'footer',
                            content: 'Copyright 2019.',
                          },
                        ],
                      ];
                      // var response = $mandrill->messages->sendTemplate($template_name, $template_content, $message);

                      const template = {
                        template_name: template_name,
                        template_content: template_content,
                        message: message,
                        async: false,
                        ip_pool: 'Main Pool',
                      };

                      return new Promise((resolve, reject) => {
                        mandrill_client.messages.sendTemplate(
                          template,
                          (result) => {
                            resolve(result);
                          },
                          (e) => {
                            console.error(e);
                            reject(e);
                          }
                        );
                      });
                    };
                  }

                  /*             * *** mail sent **** */
                } //end of if result not already exist

                console.log('debug', 'exit ots_result_submit_v5 service');

                res.json(quesResponse);
              } else {
                quesResponse.flag = 5;
                quesResponse.authFlag = 1;
                //json_response = json_encode($quesResponse);
                //echo $json_response;
                res.json(quesResponse);
              }
              pool4.releaseConnection(conn4);
            }
          });
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
