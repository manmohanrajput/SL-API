const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_mob_login_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const data = {};
      data.email = req.body.email;
      data.app_id = req.body.app_id;
      data.app_hash = req.body.hash;
      data.pwd = req.body.pwd;
      var mob_Data;
      var userData = {};
      var user_Data;
      var sql =
        `select count(*)as mob_count from mob_app_detail where app_id="` +
        data.app_id +
        `" and app_hash="` +
        data.app_hash +
        `"`;
      console.log(sql);

      mob_Data = await query(sql, conn);
      console.log(mob_Data);
      if (mob_Data[0].mob_count > 0) {
        sql = `SELECT inst_id,is_admin,user_id FROM mob_app_detail WHERE app_id = ${data.app_id}`;
        console.log(sql);
        var mobApp_Data = await query(sql, conn);
        console.log(mobApp_Data);
        console.log('test data');
        sql =
          `SELECT * FROM user_detail WHERE user_email = "` +
          data.email +
          `" AND user_password="` +
          data.pwd +
          `"`;
        console.log(sql);
        user_Data = await query(sql, conn);
        console.log(user_Data);
        console.log(user_Data[0].user_id);

        var user_id_array = mobApp_Data[0].user_id;
        if (user_Data && mobApp_Data) {
          //echo "dtg";die;
          if (
            data.app_id > 1000 &&
            data.app_id != 1043 &&
            data.app_id != 100005 &&
            data.app_id != 1200
          ) {
            if (mobApp_Data.inst_id == user_Data[0].user_inst_id) {
              /* Update user appid and source on 22 apr,2017 */
              updateUserArray.app_id = data.app_id;
              updateUserArray.source = 'mob_login';

              ///$this->db->where('user_id', $user_Data[0]['user_id']);
              //$this->db->update('user_detail', $updateUserArray);
              var sql = `UPDATE user_details=${updateUserArray} WHERE user_id =${user_Data[0].user_id}`;
              await query(sql, conn);

              /*                         * ******************************************** */

              //$userData['user_image_path'] = $user_Data[0]['user_image_url'] ? $user_Data[0]['user_image_url'] : '';

              if (
                user_Data[0].user_photo.indexOf('https') !== null &&
                user_Data[0].user_photo.indexOf('https') !== -1
              )
                userData.user_image_path = user_Data[0][0].user_photo;
              else if (user_Data[0].user_photo == '') {
                userData.user_image_path = '';
              } else {
                userData.user_image_path =
                  S3URL1 + 'mcluserimage/' + user_Data[0].user_image_url + '';
              }

              userData.user_id = user_Data[0].user_id;
              userData.user_hash = user_Data[0].user_hash;
              userData.user_first_name = user_Data[0].user_first_name;
              userData.user_last_name = user_Data[0].user_last_name;
              userData.user_email = user_Data[0].user_email;
              userData.user_contact_no = user_Data[0].user_contact_no
                ? user_Data[0].user_contact_no
                : '';
              userDat.user_address = user_Data[0].user_address
                ? user_Data[0].user_address
                : '';
              userData.zip_code = user_Data[0].zip_code
                ? user_Data[0].zip_code
                : '';
              userData.user_qual = user_Data[0].user_qual
                ? user_Data[0].user_qual
                : '';
              //$userData['stream'] = $user_Data[0]['stream'] ? $user_Data[0]['stream'] : '';
              userData.org_name = user_Data[0].org_name
                ? user_Data[0].org_name
                : '';
              userData.job_title = user_Data[0].job_title
                ? user_Data[0].job_title
                : '';
              userData.stream = user_Data[0].stream ? user_Data[0].stream : '';
              userData.prev_exam_percentage = user_Data[0].prev_exam_percentage
                ? user_Data[0].prev_exam_percentage
                : '';
              userData.user_state_name = user_Data[0].user_state_name
                ? user_Data[0].user_state_name
                : '';
              userData.user_country_name = user_Data[0].user_country_name
                ? user_Data[0].user_country_name
                : '';
              userData.user_city_name = user_Data[0].user_city_name
                ? user_Data[0].user_city_name
                : '';
              userData.role = user_Data[0].user_type
                ? user_Data[0].user_type
                : '';
              userData.is_admin = mobApp_Data.is_admin;

              if (
                user_id_array.includes(user_Data[0].user_id) &&
                mobApp_Data.is_admin == 1
              ) {
                //if($userData['is_admin']==1){
                userData.is_admin = true;
              } else {
                userData.is_admin = false;
              }
              if (
                userData.user_contact_no == 1111111111 ||
                userData.user_contact_no == '1111111111'
              ) {
                userData.user_contact_no = '';
              }
              percentage = 100;

              //                    if ($userData['user_contact_no'] == '' || $userData['user_contact_no'] == NULL || $userData['user_contact_no'] == 1111111111 || $userData['user_contact_no'] == '1111111111') {
              //                        $percentage = $percentage - 30;
              //                    }
              //                    if ($userData['user_qual'] == '' && $userData['user_qual'] == NULL) {
              //                        $percentage = $percentage - 20;
              //                    }
              //
              //                    if ($userData['role'] == '' || $userData['role'] == NULL) {
              //                        $percentage = $percentage - 50;
              //                    }
              userData.percentage = percentage;
              userData.flag = 1;
            } else {
              userData.message =
                'Institute id did not matched with given app id';
              userData.flag = 2;
            }
          } else {
            //$userData['user_image_path'] = $user_Data[0]['user_image_url'] ? $user_Data[0]['user_image_url'] : '';
            console.log(user_Data[0].user_photo);
            if (
              user_Data[0].user_photo.indexOf('https') !== null &&
              user_Data[0].user_photo.indexOf('https') !== -1
            )
              userData.user_image_path = user_Data[0].user_photo;
            else if (user_Data[0].user_photo == '') {
              userData.user_image_path = '';
            } else {
              userData.user_image_path =
                'S3URL1' + 'mcluserimage/' + user_Data[0].user_image_url + '';
            }
            userData.user_id = user_Data[0].user_id;
            userData.user_hash = user_Data[0].user_hash;
            userData.user_first_name = user_Data[0].user_first_name;
            userData.user_last_name = user_Data[0].user_last_name;
            userData.user_email = user_Data[0].user_email;
            userData.user_contact_no = user_Data[0].user_contact_no
              ? user_Data[0].user_contact_no
              : '';
            userData.user_address = user_Data[0].user_address
              ? user_Data[0].user_address
              : '';
            userData.zip_code = user_Data[0].zip_code
              ? user_Data[0].zip_code
              : '';
            userData.user_qual = user_Data[0].user_qual
              ? user_Data[0].user_qual
              : '';
            userData.stream = user_Data[0].stream ? user_Data[0].stream : '';
            userData.org_name = user_Data[0].org_name
              ? user_Data[0].org_name
              : '';
            userData.job_title = user_Data[0].job_title
              ? user_Data[0].job_title
              : '';
            //$userData['stream'] = $user_Data[0]['stream'] ? $user_Data[0]['stream'] : '';
            userData.prev_exam_percentage = user_Data[0].prev_exam_percentage
              ? user_Data[0].prev_exam_percentage
              : '';
            userData.user_state_name = user_Data[0].user_state_name
              ? user_Data[0].user_state_name
              : '';
            userData.user_country_name = user_Data[0].user_country_name
              ? user_Data[0].user_country_name
              : '';
            userData.user_city_name = user_Data[0].user_city_name
              ? user_Data[0].user_city_name
              : '';
            userData.role = user_Data[0].user_type
              ? user_Data[0].user_type
              : '';
            userData.is_admin = mobApp_Data.is_admin;
            //$user_id_array = explode(',',$mobApp_Data['user_id']);
            console.log(user_id_array);
            if (
              user_id_array.includes(user_Data[0].user_id) &&
              mobApp_Data.is_admin == 1
            ) {
              // if($userData['is_admin']!=''){
              userData.is_admin = true;
            } else {
              userData.is_admin = false;
            }
            if (
              userData.user_contact_no == 1111111111 ||
              userData.user_contact_no == '1111111111'
            ) {
              userData.user_contact_no = '';
            }

            if (
              user_Data[0].user_contact_no == 1111111111 ||
              user_Data[0].user_contact_no == '1111111111'
            ) {
              userData.user_contact_no = '';
            }
            percentage = 100;

            if (
              userData.user_contact_no == '' ||
              userData.user_contact_no == null ||
              userData.user_contact_no == 1111111111 ||
              userData.user_contact_no == '1111111111'
            ) {
              percentage = percentage - 30;
            }
            if (userData.user_qual == '' && userData.user_qual == null) {
              percentage = percentage - 20;
            }

            if (userData.role == '' && userData.role == null) {
              percentage = percentage - 50;
            }
            userData.percentage = percentage;
            userData.flag = 1;
          }
        } else {
          userData.message = 'No data exist for given user';
          userData.flag = 0;
        }
        res.send(userData);
      } else {
        userData.flag = 5;
        res.send(userData);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
