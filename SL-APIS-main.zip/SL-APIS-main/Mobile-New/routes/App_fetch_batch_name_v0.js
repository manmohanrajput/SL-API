const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');
const date = require('date-and-time');

router.post('/App_fetch_batch_name_v0', async (req, res) => {
  console.log('testing');

  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const data = {};
      data.app_id = req.body.app_id;
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;

      var sql = `select count(*)as user_count from user_detail where user_id=${user_id} and user_hash="${user_hash}"`;
      var user_Data1 = (await query(sql, conn))[0];

      if (user_Data1.user_count > 0) {
        sql = `select institute_details.id,institute_details.flag_institute_management from institute_details left join mob_app_detail on mob_app_detail.inst_id=institute_details.id where mob_app_detail.app_id=${data.app_id}`;
        var inst_data = (await query(sql, conn))[0];
        if (inst_data.flag_institute_management === 1) {
          let now = new Date();

          //let day = today.getFullYear();
          let today = date.format(now, 'YYYY/MM/DD');
          let after_seven_in = date.addDays(now, 7);
          let after_seven = date.format(after_seven_in, 'YYYY/MM/DD');
          console.log(today);
          console.log(after_seven);
          sql = `SELECT * FROM batch_master WHERE batch_start_date BETWEEN ${today}  AND ${after_seven} and app_id = ${data.app_id}`;
          console.log(sql);
          const batch_Data = await query(sql, conn);
          console.log(batch_Data);
          sql = `SELECT batch_master.*,faculty_master.faculty_name FROM batch_master left join faculty_master on faculty_master.batch=batch_master.id WHERE  batch_master.batch_start_date BETWEEN ${today} AND ${after_seven} and batch_master.app_id= "${data.app_id}" order by batch_start_date asc`;
          console.log(sql);
          const batch_detail_Data = await query(sql, conn);
          console.log(batch_detail_Data);
          var user_data = {};
          if (batch_Data) {
            const batch_data = [];
            batch_Data.forEach((batch) => {
              batch_data.push([
                {
                  batch_id: batch.id,
                  batch_name: batch.batch_name,
                  batch_inst_id: inst_data.id,
                },
              ]);
            });
            user_data.batch_data = batch_data;
            user_data.flag = 1;
          } else {
            user_data.flag = 0;
          }
          const detail_data = [];

          const batch_detail = [];
          if (batch_detail_Data) {
            batch_detail_Data.forEach((detail) => {
              batch_detail.push({
                batch_id: detail.id,
                faculty_name: detail.faculty_name,
                batch_date: detail.batch_start_date,
                batch_time: detail.batch_timing,
                subject: detail.batch_subject,
              });
            });
            user_data.batch_detail = batch_detail;
            user_data.flag = 1;
          } else {
            detail_data.flag = 0;
          }
        } else {
          let batch_Data;
          sql = `SELECT * FROM b2c_inst_batch WHERE batch_app_id =${data.app_id}`;
          batch_Data = query(sql, conn);
          let today = Date.now('Y-m-d');
          let after_seven = Date.parse(today.getDate() + 7);
          sql = `SELECT * FROM b2c_batch_details WHERE batch_date BETWEEN ${today} AND ${after_seven} AND batch_id IN (SELECT batch_id FROM b2c_inst_batch WHERE batch_app_id =${data.app_id}`;

          const batch_detail_data = await query(sql, conn);

          user_data = [];
          batch_data = [];
          if (batch_Data) {
            batch_Data.forEach((batch) => {
              batch_data.push({
                batch_id: batch.batch_id,
                batch_name: batch.batch_name,
                batch_inst_id: batch.batch_inst_id,
              });
            });
            user_data.batch_data = batch_data;
            user_data.flag = 1;
          } else {
            user_data['flag'] = 0;
          }
          detail_data = [];
          let batch_detail;
          if (batch_detail_data) {
            batch_detail_data.forEach((detail) => {
              batch_detail.push({
                batch_id: detail.batch_id,
                faculty_name: detail.faculty_name,
                batch_date: Date('d-m-Y', detail.batch_date.getDate()),
                batch_time: Date('h:i A', detail.batch_time.getTime()),
                subject: detail.subject,
              });
            });
            user_data.batch_detail = batch_detail;
            user_data.flag = 1;
          } else {
            detail_data['flag'] = 0;
          }
        }

        res.json(user_data);
      } else {
        user_data.flag = 5;
        res.json(user_data);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
