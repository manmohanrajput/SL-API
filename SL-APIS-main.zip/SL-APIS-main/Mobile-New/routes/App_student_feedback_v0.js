const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_delete_comment_v0', async (req, res) => {
  
    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            pool2.getConnection(async (err, conn2) => {
                if(err){
                    console.log(err);
                    return res.status(500).send('Server Error');
                } else {
                    const user_id = req.body.user_id;
                    const user_hash = req.body.user_hash;
                    const app_id = req.body.app_id;
                    const user_feedback = req.body.user_feedback;

                    var sql = 'select count(*)as user_count from user_detail where user_id=' + user_id + ' and user_hash=\'' + user_hash + '\'';
                     user_Data1 = (await query(sql, conn))[0];
    
                    if(user_Data1[0].user_count > 0){
                     var sql ="SELECT user_email,user_first_name,user_last_name FROM user_detail WHERE user_id=" + user_id + "";
                      const user_Data = await query(sql, conn);

                     if(user_Data.user_email != ''){
                       // require_once './maillib/src/Mandrill.php';
                       mandrill = new Mandrill('bAV03zWPNHiodhkVXNkhLQ');
                       if (app_id > 1000) {
                           //var sql = $this->db->get_where('mob_app_detail', array('app_id' => $app_id))->row_array();
                           org_email = mob_app_Data.org_email;
                       } else {
                           org_email = 'contact@mycareerlift.com';
                       }

                       message = [{
                        subject : 'Student Feedback',
                        from_email : '' + user_Data.user_email + '',
                        to : [{
                            [{email: ''+ org_email + '',
                             name : '', type : 'to'}],
                            [{email : 'devendra.mycareerlift@gmail.com',
                             type : 'cc'}],
                        }],
                            headers : [{Reply-To : 'noreply@educationalemail.com'}],
                            global_merge_vars : [{
                                    name : 'FEEDBACK',
                                    content : '' + user_feedback + ''
                                }],
                                [{
                                    name : 'FULLNAME',
                                    content : '' + user_Data.user_first_name + " " + user_Data.user_last_name + ''
                                }],
                        
                          }] 
                            template_name = Student_Feedback;

                            template_content = [{
                                [{
                                    name : 'main',
                                    content : 'Hi'}],
                                [{
                                    name : 'footer',
                                    content : 'Copyright 2019.'}]
                                }]
            
            
                       //TODO   response = $mandrill->messages->sendTemplate($template_name, $template_content, $message);
                            //print_r($response);die;
                            if (response.status[0] == 'sent') {
                                success.flag = 1;
                            } else {
                                success.reason = response.reject_reason [0];
                                success.flag = 0;
                            }
       
  
                     } else {
                        success.flag = 2;
                    }
                    pool2.releaseConnection(conn2);
    
                     json.response(success);
                           
                    }
                }
            });

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;