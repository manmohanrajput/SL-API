const mysql = require('mysql');
const config = require('./default.json');
const pool = mysql.createPool({
    host: config.HOST2,
    user: config.user2,
    password: config.password2,
    database: config.database2,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

module.exports = pool;