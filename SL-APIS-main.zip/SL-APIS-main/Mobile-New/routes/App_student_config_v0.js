const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_student_config_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      
      var user_id = req.body.user_id;
      var user_hash = req.body.user_hash;
      var app_hash = req.body.app_hash;
      var resultData = {};

      var sql = `SELECT * FROM mob_app_student_config WHERE app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash= "${app_hash}") AND user_hash="${user_hash}"`;
      var appStudentElementData = await query(sql, conn);
      if (appStudentElementData.length == 0) {
        var bool = false;
      } else {
        var bool = true;
      }
      if (bool) {
        appStudentElementData.forEach((appstudentElement) => {
          var permission = appstudentElement.permission;
          var std_permission = permission.split(',');
        
          resultData.student_permissions = std_permission;
        });
        resultData.flag = 1;
      } else {
        var data = [230, 373, 229, 225, 237, 226, 331, 357, 456, 467, 234, 370];
        resultData.student_permissions = data;

        resultData.flag = 1;
      }
      res.send(resultData);

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
