const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_explain_ans_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const app_hash = req.body.app_hash;

          var sql =
            'select count(*)as user_count from user_detail where user_id=' +
            user_id +
            " and user_hash='" +
            user_hash +
            "'";
          /* $user_id = 76;
              $app_hash = "13ae065b00c9d9d215801230704c1e6f"; */
          const user_Data = (await query(sql, conn))[0];
          if (user_Data[0].user_count > 0) {
            // db2 = $this->load->database('discussiondb', TRUE);
            if (user_id > 0) {
            } else {
              console.log('user not authorised');
              //   break;
            }
            sql =
              "SELECT * FROM expl_ans_pdf WHERE app_hash='" +
              app_hash +
              "' AND pdf_status='Enable' ORDER BY date_added DESC";
            var appExpainAnsData = await query(sql, conn);

            if (!empty(appExpainAnsData)) {
              appExpainAnsData.forEach((appExplAns) => {
                const app_explAns_arr = [
                  {
                    title: appExplAns.pdf_title,
                    detail: appExplAns.pdf_detail,
                    //'pdf' => S3URL . "mclexplainanswerpdf/" . $appExplAns['pdf_file'],
                    pdf: 'mclexplainanswerpdf/' + appExplAns.pdf_file,
                    added_date: appExplAns.date_added,
                  },
                ];
                var resultData;
                resultData.push(app_explAns_arr);
              });
            } else {
              const resultData = [];
            }
            json.responnse(resultData);
            res.send(resultData);
          } else {
            resultData = [];
            resultData.flag = 5;
            json.response(resultData);
            res.send(resultData);
          }
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
