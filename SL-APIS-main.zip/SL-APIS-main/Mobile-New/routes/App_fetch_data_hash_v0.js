const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_data_hash_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const data_hash = req.body.data_hash;
          var postData;
          if (user_id > 0) {
          } else {
            console.log('user not authorised');
            return;
          }
          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `"and user_hash="` +
            user_hash +
            `"`;
          var user_Data;
          user_Data = await query(sql, conn);
          if (user_Data[0].user_count > 0) {
            //$masterUserData = $this->db->query("SELECT account_status FROM master_user_login WHERE user_id=" . $user_id . "")->row_array();
            sql = `SELECT account_status FROM master_user_login WHERE user_id=${user_id} `;
            var masterUserData = await query(sql, conn);

            //dataRow = $this->db->query("SELECT content,image FROM mob_post WHERE mob_post_hash='" . $data_hash . "'")->row_array();
            sql = `SELECT content,image FROM mob_post WHERE mob_post_hash=${data_hash}`;
            var dataRow = await query(sql, conn);

            if (dataRow) {
              if (dataRow.image != null && dataRow.image != '') {
                //$postimage = S3URL . 'postimages/' . $dataRow['image'] . '';
                var postimage = 'postimages/' + dataRow[0].image + '';
              } else {
                var postimage = '';
              }
              console.log('debug', 'if content array not empty');
              postData = [
                {
                  flag: 1,
                  content: dataRow[0].content,
                  image: postimage,
                },
              ];
            } else {
              log_message('debug', 'if content array is empty');
              postData = [
                {
                  flag: 0,
                },
              ];
            }
            res.send(postData);
          } else {
            postData.flag = 5;
            res.send(postData);
          }
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
