const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_check_email_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const email = req.body.email;
          const app_id = req.body.app_id;
          const app_hash = req.body.hash;

          var sql = `select count(*)as mob_count from mob_app_detail where app_id=${app_id} and app_hash="${app_hash}"`;
          console.log(sql);
          const mob_Data = await query(sql, conn);
          console.log(mob_Data);
          var user_Data;
          var userData = {};
          if (mob_Data[0].mob_count > 0) {
            sql = `SELECT inst_id,is_admin,user_id FROM mob_app_detail WHERE app_id =${app_id}`;
            console.log(sql);
            mobApp_Data = await query(sql, conn);
            console.log(mobApp_Data);

            sql = `SELECT * FROM user_detail WHERE user_email ="${email}" `;
            user_Data = await query(sql, conn);
            console.log(user_Data);

            var user_id_array = [];
            user_id_array.push(mobApp_Data.user_id);
            if (user_Data && mobApp_Data) {
              //echo "dtg";die;
              if (
                app_id > 1000 &&
                app_id != 1043 &&
                app_id != 100005 &&
                app_id != 1200
              ) {
                if (mobApp_Data.inst_id == user_Data[0].user_inst_id) {
                  /* Update user appid and source on 22 apr,2017 */
                  var updateUserArray = [
                    {
                      app_id: app_id,
                      source: 'mob_login',
                    },
                  ];
                  sql = `UPDATE edu_post  SET user_detail (app_id,source) VALUES (${
                    (updateUserArray.app_id, updateUserArray.source)
                  }) WHERE user_id= ${user_Data[0].user_id}`;
                  await query(sql, conn);
                  // query(`where('user_id', user_Data[0].user_id)`,conn);
                  // query(`update('user_detail', updateUserArray)`,conn);
                  /*  * ******************************************** */

                  //$userData['user_image_path'] = $user_Data[0]['user_image_url'] ? $user_Data[0]['user_image_url'] : '';
                  if (
                    user_Data[0].user_photo.indexOf('https') !== null &&
                    user_Data[0].user_photo.indexOf('https') !== -1
                  )
                    userData[0].user_image_path = user_Data[0].user_photo;
                  else if (user_Data[0].user_photo == '') {
                    userData.user_image_path = '';
                  } else {
                    userData.user_image_path =
                      S3URL1 +
                      `mcluserimage/` +
                      user_Data[0].user_image_url +
                      ``;
                  }

                  userData.user_id = user_Data[0].user_id;
                  userData.user_hash = user_Data[0].user_hash;
                  userData.user_first_name = user_Data[0].user_first_name;
                  userData.user_last_name = user_Data[0].user_last_name;
                  userData.user_email = user_Data[0].user_email;
                  userData.user_contact_no = user_Data[0].user_contact_no
                    ? user_Data[0].user_contact_no
                    : '';
                  userData.user_addres = user_Data[0].user_address
                    ? user_Data[0].user_address
                    : '';
                  userData.zip_code = user_Data[0].zip_code
                    ? user_Data[0].zip_code
                    : '';
                  userData.user_qual = user_Data[0].user_qual
                    ? user_Data[0].user_qual
                    : '';
                  //$userData['stream'] = $user_Data[0]['stream'] ? $user_Data[0]['stream'] : '';
                  userData.org_name = user_Data[0].org_name
                    ? user_Data[0].org_name
                    : '';
                  userData.job_title = user_Data[0].job_title
                    ? user_Data[0].job_title
                    : '';
                  userData.stream = user_Data[0].stream
                    ? user_Data[0].stream
                    : '';
                  userData.prev_exam_percentage = user_Data[0]
                    .prev_exam_percentage
                    ? user_Data[0].prev_exam_percentage
                    : '';
                  userData.user_state_name = user_Data[0].user_state_name
                    ? user_Data[0].user_state_name
                    : '';
                  userData.user_country_name = user_Data[0].user_country_name
                    ? user_Data[0].user_country_name
                    : '';
                  userData.user_city_name = user_Data[0].user_city_name
                    ? user_Data[0].user_city_name
                    : '';
                  userData.role = user_Data[0].user_type
                    ? user_Data[0].user_type
                    : '';
                  userData.is_admin = mobApp_Data.is_admin;

                  if (
                    user_id_array.includes(user_Data[0].user_id) &&
                    mobApp_Data.is_admin == 1
                  ) {
                    //if($userData['is_admin']==1){
                    userData.is_admin = TRUE;
                  } else {
                    userData.is_admin = FALSE;
                  }
                  if (
                    userData.user_contact_no == 1111111111 ||
                    userData.user_contact_no == '1111111111'
                  ) {
                    userData.user_contact_no = '';
                  }
                  percentage = 100;

                  //                    if ($userData['user_contact_no'] == '' || $userData['user_contact_no'] == NULL || $userData['user_contact_no'] == 1111111111 || $userData['user_contact_no'] == '1111111111') {
                  //                        $percentage = $percentage - 30;
                  //                    }
                  //                    if ($userData['user_qual'] == '' && $userData['user_qual'] == NULL) {
                  //                        $percentage = $percentage - 20;
                  //                    }
                  //
                  //                    if ($userData['role'] == '' || $userData['role'] == NULL) {
                  //                        $percentage = $percentage - 50;
                  //                    }
                  userData.percentage = percentage;
                  userData.flag = 1;
                } else {
                  userData.message =
                    'Institute id did not matched with given app id';
                  userData.flag = 2;
                }
              } else {
                //$userData['user_image_path'] = $user_Data[0]['user_image_url'] ? $user_Data[0]['user_image_url'] : '';
                var photo = user_Data[0].user_photo;
                if (
                  photo.indexOf('https') !== null &&
                  photo.indexOf('https') !== -1
                )
                  userData.user_image_path = user_Data[0].user_photo;
                else if (user_Data[0].user_photo == '') {
                  userData.user_image_path = '';
                } else {
                  userData.user_image_path =
                    S3URL1 + 'mcluserimage/' + user_Data[0].user_image_url + '';
                }
                userData.user_id = user_Data[0].user_id;
                userData.user_hash = user_Data[0].user_hash;
                userData.user_first_name = user_Data[0].user_first_name;
                userData.user_last_name = user_Data[0].user_last_name;
                userData.user_email = user_Data[0].user_email;
                userData.user_contact_no = user_Data[0].user_contact_no
                  ? user_Data[0].user_contact_no
                  : '';
                userData.user_address = user_Data[0].user_address
                  ? user_Data[0].user_address
                  : '';
                userData.zip_code = user_Data[0].zip_code
                  ? user_Data[0].zip_code
                  : '';
                userData.user_qual = user_Data[0].user_qual
                  ? user_Data[0].user_qual
                  : '';
                userData.stream = user_Data[0].stream
                  ? user_Data[0].stream
                  : '';
                userData.org_name = user_Data[0].org_name
                  ? user_Data[0].org_name
                  : '';
                userData.job_title = user_Data[0].job_title
                  ? user_Data[0].job_title
                  : '';
                //$userData['stream'] = $user_Data[0]['stream'] ? $user_Data[0]['stream'] : '';
                userData.prev_exam_percentage = user_Data[0]
                  .prev_exam_percentage
                  ? user_Data[0].prev_exam_percentage
                  : '';
                userData.user_state_name = user_Data[0].user_state_name
                  ? user_Data[0].user_state_name
                  : '';
                userData.user_country_name = user_Data[0].user_country_name
                  ? user_Data[0].user_country_name
                  : '';
                userData.user_city_name = user_Data[0].user_city_name
                  ? user_Data[0].user_city_name
                  : '';
                userData.role = user_Data[0].user_type
                  ? user_Data[0].user_type
                  : '';
                userData.is_admin = mobApp_Data.is_admin;
                //$user_id_array = explode(',',$mobApp_Data['user_id']);
                if (
                  user_id_array.includes(user_Data[0].user_id) &&
                  mobApp_Data.is_admin == 1
                ) {
                  // if($userData['is_admin']!=''){
                  userData.is_admin = true;
                } else {
                  userData.is_admin = false;
                }
                if (
                  userData.user_contact_no == 1111111111 ||
                  userData.user_contact_no == '1111111111'
                ) {
                  userData.user_contact_no = '';
                }

                if (
                  user_Data[0].user_contact_no == 1111111111 ||
                  user_Data[0].user_contact_no == '1111111111'
                ) {
                  userData.user_contact_no = '';
                }
                percentage = 100;

                if (
                  userData.user_contact_no == '' ||
                  userData.user_contact_no == null ||
                  userData.user_contact_no == 1111111111 ||
                  userData.user_contact_no == '1111111111'
                ) {
                  percentage = percentage - 30;
                }
                if (userData.user_qual == '' && userData.user_qual == NULL) {
                  percentage = percentage - 20;
                }

                if (userData.role == '' && userData.role == NULL) {
                  percentage = percentage - 50;
                }
                userData.percentage = percentage;
                userData.flag = 1;
              }
            } else {
              userData.message = 'No data exist for given email id';
              userData.flag = 0;
            }
            //on_response = json_encode(userData);
            // echo $json_response;
            // console.log(json_response);
            res.json(userData);
          } else {
            userData.flag = 5;
            //json_response = json_encode(userData);
            // echo $json_response;
            //          console.log(json_response);
            res.json(userData);
          }
        }
      });
    }
  });
});

module.exports = router;
