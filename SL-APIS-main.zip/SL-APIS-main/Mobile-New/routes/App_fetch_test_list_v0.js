const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_fetch_test_list_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;
      const app_hash = req.body.app_hash;
      const max_user_test_sync_id = req.body.max_user_test_sync_id;
      const test_count = req.body.test_count;
      const country_name = req.body.country_name;

      var sql =
        `select count(*)as user_count from user_detail where user_id="` +
        req.body.user_id +
        `" and user_hash="` +
        req.body.user_hash +
        `"`;
      const user_Data = await query(sql, conn);

      if (user_Data[0].user_count > 0) {
        if (user_id <= 0) {
          return res.status(401).send('User not Autherized');
        }
        sql = `SELECT app_id FROM mob_app_detail WHERE app_hash="${app_hash}"`;

        var mobAppHashData = await query(sql, conn);
        /* END ADDED BY PADAM JAIN 28-01-2019 */
        var app_id = mobAppHashData[0].app_id;
        /* ADDED BY PADAM JAIN 28-01-2019 */

        /* END ADDED BY PADAM JAIN 28-01-2019 */
        if (test_count < 10) {
          // this->db->where('aus_app_id', $app_id);
          // $this->db->where('aus_user_id', $user_id);
          //$this->db->update('ots_app_user_sync', array('aus_test_sync_id' => 0));
          sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0 WHERE aus_app_id=${app_id} AND aus_user_id =${user_id}`;

          await query(sql, conn);
        } else if (max_user_test_sync_id == 0) {
          // $this->db->where('aus_app_id', $app_id);
          // $this->db->where('aus_user_id', $user_id);
          // $this->db->update('ots_app_user_sync', array('aus_test_sync_id' => 0));
          sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0 WHERE aus_app_id=${app_id} AND aus_user_id =${user_id}`;
          await query(sql, conn);
        }

        // $syncTestData = $this->db->query("SELECT max(sync_test_id) as max_sync_test_id FROM mob_test_master")->row_array();
        sql = `SELECT max(sync_test_id) as max_sync_test_id FROM mob_test_master`;
        var syncTestData = await query(sql, conn);
        // $appUserSyncData = $this->db->query("SELECT aus_test_sync_id FROM ots_app_user_sync WHERE aus_user_id=" . $user_id . " AND aus_app_id=" . $app_id . "")->row_array();
        sql = `SELECT aus_test_sync_id FROM ots_app_user_sync WHERE aus_user_id= ${user_id} AND aus_app_id= ${app_id}`;
        var appUserSyncData = await query(sql, conn);
        if (appUserSyncData) {
          var user_app_sync_arr = [
            {
              aus_app_id: app_id,
              aus_user_id: user_id,
              aus_test_sync_id: 0,
            },
          ];

          // $this->db->insert('ots_app_user_sync', $user_app_sync_arr);
          sql = `INSERT INTO ots_app_user_sync (aus_app_id,aus_user_id,aus_test_sync_id) VALUES (${user_app_sync_arr[0].aus_app_id},${user_app_sync_arr[0].aus_user_id},${user_app_sync_arr[0].aus_test_sync_id})`;
          appUserSyncData.aus_test_sync_id = 0;
        } else {
        }

        if (
          max_user_test_sync_id < appUserSyncData.aus_test_sync_id &&
          max_user_test_sync_id > 0
        ) {
          appUserSyncData.aus_test_sync_id = max_user_test_sync_id;
        }

        sql = `SELECT test_id,exam_id,test_name,test_category,test_ques_no,test_time,test_mark_per_ques,test_negative_mark,test_total_mark,test_instruction,test_desc,test_status,res_id,res_per_obtain ,res_correct_ans,res_wrong_ans,mob_test_hash,sync_test_id,test_sequence_no,app_id,is_notify,test_created FROM mob_test_master LEFT JOIN mob_result ON mob_test_master.test_id = mob_result.res_test_id AND mob_result.res_user_id =${user_id} WHERE (exam_id IN(SELECT mae_exam_id FROM mob_app_exam WHERE mae_app_id=${app_id} AND mob_app_exam.status=1 AND mae_exam_id!=99999) OR app_id=${app_id}) AND sync_test_id> ${appUserSyncData.aus_test_sync_id} ORDER BY test_sequence_no ASC`;

        var testData = await query(sql, conn);

        //$testData = $this->db->query($sql)->result_array();
        var testlist = {};
        if (testData) {
          testData.forEach((test) => {
            if (test.test_status != 3) {
              testData = [
                {
                  test_hash: test.mob_test_hash,
                  exam_id: parseInt(test.exam_id),
                  test_status: parseInt(test.test_status),
                  test_name: test.test_name,
                  test_tag: test.test_category,
                  total_ques: test.test_ques_no,
                  total_time: test.test_time,
                  test_desc: test.test_desc,
                  test_status: parseInt(test.test_status),
                  test_sequence_no: test.test_sequence_no,
                  is_notify: parseInt(test.is_notify),
                  add_date: test.test_created,
                  positive_mark: test.test_mark_per_ques,
                  negative_mark: test.test_negative_mark,
                  total_mark: test.test_total_mark,
                },
              ];

              if (test.app_id > 0 && test.app_id != null) {
                testData.exam_id = 99999;
              }

              if (
                test.res_id != null &&
                test.res_id != '' &&
                test.res_id != 0
              ) {
                testData.is_attempted = 1;
                testData.percentage = test.res_per_obtain;
                testData.mark_obtain =
                  test.res_correct_ans * test.test_mark_per_ques -
                  test.res_wrong_ans * test.test_negative_mark;
              } else {
                testData.is_attempted = 0;
                testData.percentage = 0;
                testData.ark_obtain = 0;
              }

              testlist.flag = 1;
              testlist.test_data = testData;
            }
          });
          //      $this->db->where('aus_user_id', $user_id);
          //      $this->db->where('aus_app_id', $app_id);
          //      $this->db->update('ots_app_user_sync', array('aus_test_sync_id' => $syncTestData['max_sync_test_id']));

          sql = `UPDATE ots_app_user_sync SET aus_test_sync_id=${syncTestData[0].max_sync_test_id} WHERE aus_user_id=${user_id} AND aus_app_id =${app_id}  `;
          await query(sql, conn);
        } else {
          testlist.flag = 0;
          testlist.test_data = [];
        }
        testlist.max_test_sync_id = syncTestData[0].max_sync_test_id;

        //log_message('debug', 'exit sync_test_list_v10 service');
        //print_r($testlist);die;
        //$json_response = json_encode($testlist);
        // echo $json_response;
        res.send(testlist);

        pool.releaseConnection(conn);
      } else {
        testlist.flag = 0;
        testlist.test_data = [];
        // $json_response = json_encode($testlist);
        //echo $json_response;
        res.send(testlist);
      }
    }
  });
});

module.exports = router;
