
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool5 = require('../config/db5');
const query = require('../utils/query');

router.post('/App_fetch_inst_post_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            pool5.getConnection((err, conn5) => {
                if(err){
                    console.log(err);
                    return res.status(500).send('Server Error');
                } else{
                    
                    const user_id = req.body.user_id;
                    const user_hash = req.body.user_hash;
                    const app_id = req.body.app_id;

                    var user_Data1 ;
                    var sql = 'select count(*)as user_count from user_detail where user_id=' + data.user_id + ' and user_hash=\'' + data.user_hash + '\'';
                    const user_Data1 = (await query(sql, conn))[0];

                    if(user_Data1.user_count > 0){
                        var sql = 'SELECT * FROM user_detail where user_id=' + user_id;
                        const user_Data = (await query(sql, conn))[0];

                        if(user_Data){
                            if (user_Data.access_allow !== 'No') {
                                permission_data.flag = 3;
                            } else {
                                var access_Data;
                                var sql = 'SELECT * FROM app_access_request where access_user_id=' + user_id;
                                const access_Data = (await query(sql, conn5))[0];
                                if(access_Data){
                                    var sql = 'SELECT * FROM institute_details where id=' + user_Data.user_inst_id;
                                    const inst_Data = (await query(sql, conn))[0];
                                    const result_Data = [{
                                        access_user_id : user_id,
                                        inst_hash : inst_Data.institute_hash,
                                        first_name : user_Data.user_first_name,
                                        last_name : user_Data.user_last_name,
                                        contact_no : user_Data.user_contact_no,
                                        email : user_Data.user_email,
                                        request_count : 1,
                                    }]
                                    // $this->db5->insert('app_access_request', $result_data);
                                    // $this->load->library('smsgateway');
                                    // $tempId='1107161977783795895';
                                    // $sms = $user_Data['user_first_name'] . $user_Data['user_last_name'] . ' has requested to access other features of your App.Kindly approve the request.';
                                    // $this->smsgateway->send($inst_Data['mob_number'], $sms,$tempId);
                                    permission_data.flag = 1;
                                } else {
                                    // $result_data = array(
                                    //     'request_count' => $access_Data['request_count'] + 1,
                                    // );
                                    // $this->db5->where('access_user_id', $access_Data['access_user_id']);
                                    // $this->db5->update('app_access_request', $result_data);
                                    permission_data.flag = 2;
                                }
                            }
                        } else {
                            permission_data.flag = 0;
                        }
                        res.json(permission_data);
                    }
                    permission_data['flag'] = 5;
                    res.json(permission_data);
                    
                    pool.releaseConnection(conn5);
                }
            })
            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;