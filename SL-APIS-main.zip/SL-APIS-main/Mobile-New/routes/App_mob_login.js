const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

const section_data = [],
  section_list = {};

router.post('/App_mob_login', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      console.log(req.body);
      const data = {};
      data.email = req.body.email;
      data.app_id = req.body.app_id;
      data.app_hash = req.body.hash;
      data.pwd = req.body.pwd;
      var mob_Data;
      var sql =
        'select count(*)as mob_count from mob_app_detail where app_id=' +
        data.app_id +
        " and app_hash='" +
        data.app_hash +
        "'";
      mob_Data = (await query(sql, conn))[0];
      console.log(mob_Data);
      sql =
        'SELECT inst_id,is_admin,user_id FROM mob_app_detail WHERE app_id = ' +
        data.app_id;
      const mobApp_Data = (await query(sql, conn))[0];

      sql =
        "SELECT * FROM user_detail WHERE user_email = '" +
        data.email +
        "' AND user_password='" +
        data.pwd +
        "'";
      const user_Data = (await query(sql, conn))[0];
      user_id_array = mobApp_Data.user_id.split(',');
      if (user_Data && mobApp_Data) {
        if (
          data.app_id > 1000 &&
          data.app_id !== 1043 &&
          data.app_id !== 100005 &&
          data.app_id !== 1200
        ) {
          if (mobApp_Data.inst_id === user_Data.user_inst_id) {
            updateUserArray.app_id = data.app_id;
            updateUserArray.source = 'mob_login';
            // $this->db->where('user_id', $user_Data['user_id']);
            // $this->db->update('user_detail', $updateUserArray);
            console.log(updateUserArray);
          }
        }
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
