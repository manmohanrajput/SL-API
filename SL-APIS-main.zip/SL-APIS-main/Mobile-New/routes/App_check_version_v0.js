const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_check_version_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      var data = {};
      data.user_id = req.body.user_id;
      data.user_hash = req.body.user_hash;
      data.app_hash = req.body.app_hash;
      data.version_code = req.body.version_code;
      data.gcm_id = req.body.gcm_id;
      data.country_name = req.body.country_name;
      var resultData = {};
      console.log('debug', 'in check_version_v6 service');
      if (data.user_id > 0) {
      } else {
        console.log('user not autherised');
      }

      var sql = `select count(*)as user_count from user_detail where user_id=${data.user_id} and user_hash="${data.user_hash}"`;
      const user_Data = await query(sql, conn);

      if (user_Data[0].user_count > 0) {
        //$appData = $this->db->get_where('mob_app_detail', array('app_hash' => $app_hash))->row_array();
        sql = `SELECT*FROM mob_app_detail WHERE app_hash ="${data.app_hash}"`;
        var appData = await query(sql, conn);

        if (appData) {
          var appVersion = appData.app_version;
          var appForceVersion = appData.app_force_update;
        } else {
          var appVersion = 62;
          var appForceVersion = 60;
        }
        // $countryData = $this->db->query('SELECT country_id FROM `country` WHERE LOWER(country_name)= "'.strtolower($country_name).'"')->row_array();
        sql = `SELECT country_id FROM country WHERE LOWER(country_name)= "${data.country_name.toLowerCase()}"`;
        countryData = await query(sql, conn);
        if (countryData) {
          var countryId = countryData.country_id;
        } else {
          var countryId = 0;
        }
        /*echo "<li>".$appVersion." --- ".$appForceVersion;
                die;*/
        if (appForceVersion > data.version_code) {
          resultData.force_update = 0;
          resultData.description = 'Are you sure you want to exit app?';
        } else {
          resultData.force_update = 1;
        }

        if (appVersion > data.version_code) {
          resultData.app_update = true;
        } else {
          resultData.app_update = false;
        }

        if (data.user_id != '' && data.user_id != null && data.user_id != 0) {
          sql_version = `SELECT user_detail.app_version,user_detail.user_inst_id,user_detail.user_package_expire,user_detail.access_allow,master_user_login.account_status FROM user_detail LEFT JOIN master_user_login ON user_detail.user_id=master_user_login.user_id WHERE user_detail.user_id =${data.user_id}`;

          query_version = await query(sql_version, conn);

          count_version = query_version.length; //doubt

          if (count_version > 0) {
            row = query_version; //doubt

            if (
              row.user_inst_id != '' &&
              row.user_inst_id != 0 &&
              row.user_inst_id != null
            ) {
              //instData = $this->db->get_where('institute_details', array('id' => $row['user_inst_id']))->row_array();
              sql = `SELECT * FORM institute_details WHERE id = ${row.user_inst_id}`;

              var instData = await query(sql, conn);
              //$appData = $this->db->get_where('mob_app_detail',array('app_hash ' => $app_hash ))->row_array();
              sql = `SELECT * FORM mob_app_detail WHERE app_hash = ${data.app_hash}`;
              appData = await query(sql, conn);

              if (instData) {
                resultData.inst_name = instData.name;
                if (
                  row.user_package_expire ||
                  row.user_package_expire != null
                ) {
                  if (row.user_package_expire < instData.date_app_expiry) {
                    resultData.date_app_expiry = row.user_package_expire;
                    resultData.title = 'Package Expired';
                    resultData.description =
                      'Your account has expired. Please contact your institutes administrator to have your access extended';
                  } else {
                    resultData.date_app_expiry = instData.date_app_expiry;
                    resultData.title = 'Package Expired';
                    resultData.description =
                      'Your account has expired. Please contact your institutes administrator to have your access extended';
                  }
                } else {
                  resultData.date_app_expiry = instData.date_app_expiry;
                  resultData.title = 'Package Expired';
                  resultData.description =
                    'Your account has expired. Please contact your institutes administrator to have your access extended';
                }
              } else {
                resultData.inst_name = '';
                resultData.date_app_expiry = '';
                resultData.title = '';
                resultData.description = '';
              }
            } else {
              resultData.inst_name = '';
            }

            user_id_array = appData[0].user_id.split(',');

            if (user_id_array.includes(data.user_id) && appData.is_admin == 1) {
              resultData.is_admin = true;
            } else {
              resultData.is_admin = false;
            }
            //$resultData['collab_status'] = $row['collaboration_status'];
            resultData.account_status = row.account_status;
            if (row.access_allow == null) {
              resultData.access_allow = 'Yes';
            } else {
              resultData.access_allow = row.access_allow;
            }

            if (row.app_version <= data.version_code) {
              var versionData = [
                {
                  app_version: data.version_code,
                  register_gcm_id: data.gcm_id,
                },
              ];
              //$this->db->where('user_id', $user_id);
              //$this->db->update('user_detail', $versionData);
              sql = `UPDATE user_detail SET (app_version,register_gcm_id) VALUES (${versionData[0].app_version},${versionData[0].register_gcm_id})  WHERE user_id =${data.user_id}`;
              await query(sql, conn);
            }
          } else {
            resultData.inst_name = '';
          }
          last_active = Date('Y-m-d H:i:s');
          //   $this->db->where('user_id', $user_id);
          //   $this->db->update('user_detail', $last_active);
          sql = `UPDATE user_detail SET last_active ="${last_active}" WHERE user_id =${data.user_id}`;
          await query(sql, conn);
        }
        if (data.app_hash == '699c7c8f80a465b26209374ee7db8049') {
          //doubt
          // $appExamData_country = $this->db->query("SELECT mob_app_exam.*,mob_exam.exam_name,mob_exam.seq_no,mob_exam.tag,mob_exam.exam_title_1,mob_exam.exam_title_2 FROM mob_app_exam LEFT JOIN mob_exam ON mob_app_exam.mae_exam_id=mob_exam.id WHERE mae_app_id=51 AND mob_app_exam.status=1")->result_array();
          sql = `SELECT mob_app_exam.*,mob_exam.exam_name,mob_exam.seq_no,mob_exam.tag,mob_exam.exam_title_1,mob_exam.exam_title_2 FROM mob_app_exam LEFT JOIN mob_exam ON mob_app_exam.mae_exam_id=mob_exam.id WHERE mae_app_id=51 AND mob_app_exam.status=1`;
          const appExamData_country = await query(sql, conn);
          console.log(appExamData_country);
          if (empty(appExamData_country)) {
            sql = `SELECT mob_app_exam.*,mob_exam.exam_name,mob_exam.seq_no,mob_exam.tag,mob_exam.exam_title_1,mob_exam.exam_title_2 FROM mob_app_exam LEFT JOIN mob_exam ON mob_app_exam.mae_exam_id=mob_exam.id WHERE mae_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash="${data.app_hash}" ) AND mob_app_exam.status=1`;
            var appExamData = await query(sql, conn);
          } else {
            var appExamData = appExamData_country;
          }
        } else {
          sql = `SELECT mob_app_exam.*,mob_exam.exam_name,mob_exam.seq_no,mob_exam.tag,mob_exam.exam_title_1,mob_exam.exam_title_2 FROM mob_app_exam LEFT JOIN mob_exam ON mob_app_exam.mae_exam_id=mob_exam.id WHERE mae_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash="${data.app_hash}") AND mob_app_exam.status=1`;
          appExamData = await query(sql, conn);
        }
        if (appExamData) {
          appExamData.forEach((appExam) => {
            app_exam_seq = appExam.mae_exam_seq_no
              ? appExam.mae_exam_seq_no
              : 0;
            var app_exam_arr = [
              {
                exam_id: parseInt(appExam.mae_exam_id),
                exam_name: appExam.exam_name,
                exam_title_1: appExam.exam_title_1,
                exam_title_2: appExam.exam_title_2,
                tag: appExam.tag,
                //'sequence_no' => intval($appExam['seq_no']),
                sequence_no: parseInt(app_exam_seq),
                status: parseInt(appExam.status),
              },
            ];
            if (appExam.mae_exam_id == 10001) {
              app_exam_arr.exam_name = 'Current Affairs';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 1;
              app_exam_arr.exam_title_1 = 'Current Affairs';
              /*$app_exam_arr['exam_title_2'] = 'National';*/
              if (
                data.app_hash == '8e6cd74af474f619cbefa2da1837aa0' ||
                data.app_hash == '699c7c8f80a465b26209374ee7db8049'
              ) {
                app_exam_arr.exam_title_2 = 'Africa';
              } else {
                app_exam_arr.exam_title_2 = 'National';
              }
            }
            if (appExam.mae_exam_id == 10003) {
              app_exam_arr.exam_name = 'Learn English';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 4;
            }

            if (appExam.mae_exam_id == 10004) {
              app_exam_arr.exam_name = 'Vocabulary';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 5;
            }

            if (appExam.mae_exam_id == 10005) {
              app_exam_arr.exam_name = 'Financial Affairs';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 8;
            }

            if (appExam.mae_exam_id == 10006) {
              app_exam_arr.exam_name = 'GD & PI';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 6;
            }

            if (appExam.mae_exam_id == 10007) {
              app_exam_arr.exam_name = 'Commerce Terminologies';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 7;
            }

            if (appExam.mae_exam_id == 10008) {
              app_exam_arr.exam_name = 'Current Affairs ';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 2;
              app_exam_arr.exam_title_1 = 'Current Affairs';
              app_exam_arr.exam_title_2 = 'International';
            }

            if (appExam.mae_exam_id == 10009) {
              app_exam_arr.exam_name = 'Science Terminologies';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 9;
            }

            if (appExam.mae_exam_id == 10010) {
              app_exam_arr.exam_name = 'Computer Terminologies';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 10;
            }

            if (appExam.mae_exam_id == 10011) {
              app_exam_arr.exam_name = 'Banking Terminologies';
              app_exam_arr.tag = 'kz';
              app_exam_arr.sequence_no = 11;
            }

            if (appExam.mae_exam_id == 20001) {
              app_exam_arr.exam_name = 'Foreign Exam Info';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 3;
            }

            if (appExam.mae_exam_id == 20002) {
              app_exam_arr.exam_name = 'UK';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 6;
            }

            if (appExam.mae_exam_id == 20003) {
              app_exam_arr.exam_name = 'Canada';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 7;
            }

            if (appExam.mae_exam_id == 20004) {
              app_exam_arr.exam_name = 'Others';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 13;
            }

            if (appExam.mae_exam_id == 20005) {
              app_exam_arr.exam_name = 'USA';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 4;
            }

            if (appExam.mae_exam_id == 20006) {
              app_exam_arr.exam_name = 'UAE';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 5;
            }

            if (appExam.mae_exam_id == 20007) {
              app_exam_arr.exam_name = 'India';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 2;
            }

            if (appExam.mae_exam_id == 20008) {
              app_exam_arr.exam_name = 'Singapore';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 8;
            }

            if (appExam.mae_exam_id == 20009) {
              app_exam_arr.exam_name = 'Hongkong';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 9;
            }

            if (appExam.mae_exam_id == 20010) {
              app_exam_arr.exam_name = 'Europe';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 10;
            }

            if (appExam.mae_exam_id == 20011) {
              app_exam_arr.exam_name = 'New Zealand';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 11;
            }

            if (appExam.mae_exam_id == 20012) {
              app_exam_arr.exam_name = 'Australia';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 12;
            }

            if (appExam.mae_exam_id == 20013) {
              app_exam_arr.exam_name = 'University/College Updates';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 1;
            }
            if (appExam.mae_exam_id == 20014) {
              app_exam_arr.exam_name = 'Latest scholarship';
              app_exam_arr.tag = 'fe';
              app_exam_arr.sequence_no = 4;
            }

            resultData.exams = app_exam_arr;
          });
        } else {
          resultData.exams = [];
        }
        /* ADDED BY PADAM JAIN 28-01-2019 */
        if (data.app_hash == '699c7c8f80a465b26209374ee7db8049') {
          var sql = `SELECT * FROM mob_app_home WHERE mah_app_id=51 AND mah_status=1 AND mah_tag='home'`;
          var appHomeElementData = await query(sql_version, conn);
        } else {
          /* END ADDED BY PADAM JAIN 28-01-2019 */
          var sql = `SELECT * FROM mob_app_home WHERE mah_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash=${data.app_hash}) AND mah_status=1 AND mah_tag='home'`;
          var appHomeElementData = await query(sql_version, conn);
          /* ADDED BY PADAM JAIN 28-01-2019 */
        }
        /* END ADDED BY PADAM JAIN 28-01-2019 */

        if (appHomeElementData) {
          appHomeElementData.forEach((appHomeElement) => {
            var app_home_arr = [
              {
                home_element_id: appHomeElement.mah_home_element_id,
                status: appHomeElement.mah_status,
                title_1: appHomeElement.mah_title_1,
                title_2: appHomeElement['mah_title_2'],
                seq_no: parseInt(appHomeElement.mah_seq_no),
              },
            ];

            resultData.home_elements = app_home_arr;
          });
        } else {
          resultData.home_elements = [];
        }
        /* App university data */
        /* ADDED BY PADAM JAIN 28-01-2019 */
        if (data.app_hash == '699c7c8f80a465b26209374ee7db8049') {
          sql = `SELECT mob_app_home.*,dropdown.value FROM mob_app_home LEFT JOIN list_university ON mob_app_home.mah_home_element_id=list_university.univ_id LEFT JOIN dropdown on dropdown.id = list_university.univ_category WHERE mob_app_home.mah_app_id=51 AND mob_app_home.mah_status=1 AND  mob_app_home.mah_tag='univ' `;
          var appUnivElementData = await query(sql, conn);
        } else {
          /* END ADDED BY PADAM JAIN 28-01-2019 */
          sql = `SELECT mob_app_home.*,dropdown.value FROM mob_app_home LEFT JOIN list_university ON mob_app_home.mah_home_element_id=list_university.univ_id  LEFT JOIN dropdown on dropdown.id = list_university.univ_category WHERE mob_app_home.mah_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash="${data.app_hash}") AND mob_app_home.mah_status=1 AND  mob_app_home.mah_tag='univ' `;
          var appUnivElementData = await query(sql, conn);

          /* ADDED BY PADAM JAIN 28-01-2019 */
        }
        /* END ADDED BY PADAM JAIN 28-01-2019 */
        if (appUnivElementData) {
          appUnivElementData.forEach((appUnivElement) => {
            app_univ_arr = [
              {
                univ_id: appUnivElement.mah_home_element_id,
                status: appUnivElement.mah_status,
                title_1: appUnivElement.mah_title_1,
                title_2: appUnivElement.mah_title_2,
                seq_no: parseInt(appUnivElement.mah_seq_no),
                category: appUnivElement.value,
              },
            ];
            resultData.univ = app_univ_arr;
          });
        } else {
          resultData.univ = [];
        }
        /* /END of App university data*/

        res.send(resultData);
      } else {
        resultData.flag = 5;
        resultData.univ = [];
        resultData.home_elements = [];
        resultData.exams = [];
        res.send(resultData);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
