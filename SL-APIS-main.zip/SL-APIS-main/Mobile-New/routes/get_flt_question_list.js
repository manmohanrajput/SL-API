const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/get_flt_question_list', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      res.status(500).send('Server Error');
    } else {
      const user_id = req.body.user_id,
        user_hash = req.body.user_hash,
        test_id = req.body.test_id,
        section_id = req.body.section_id;
      var sql = `select count(*)as user_count from user_detail where user_id=${req.body.user_id} AND user_hash="${req.body.user_hash}"`;
      const user_data = (await query(sql, conn))[0];

      const questionlist = {};
      if (user_data.user_count > 0) {
        sql = `select test_question.*,question_master.*, ques_ans_master.* from test_question join question_master on test_question.tq_ques_id=question_master.ques_id left join ques_ans_master on ques_ans_master.qam_ques_id=test_question.tq_ques_id where tq_test_id=${test_id} AND question_master.ques_section_id= ${section_id} `;
        questionData = await query(sql, conn);

        var questionIdList = [];

        questionData.forEach((questionVal) => {
          questionIdList.push(questionVal.ques_id);
        });
        questionIdList = questionIdList.filter((v, i, a) => a.indexOf(v) === i);
        if (questionData) {
          questionIdList.forEach((ques_id) => {
            const question_data = [];

            var option_data = [];
            var ques_desc = '';
            var ques_expl = '';
            var ques_id1 = '';
            var plus_mark = '';
            var minus_mark = '';
            questionData.forEach((question) => {
              if (ques_id === question.ques_id) {
                option_data.push([
                  {
                    ans_key: question.qam_id,
                    option_desc: question.qam_ans_option,
                    is_correct: question.is_correct,
                  },
                ]);

                ques_desc = question.ques_desc;
                ques_expl = question.ques_ans_expl;
                ques_id1 = question.ques_id;
                plus_mark = question.ques_plus_mark;
                minus_mark = question.ques_neg_mark;
              }
 
              question_data.push({
                ques_id: ques_id1,
                ques_desc: ques_desc,
                positive_mark: plus_mark,
                negative_mark: minus_mark,
                ques_expl: ques_expl,
                options: option_data,
              });
            });

            questionlist.question_data = question_data;
            questionlist.flag = 1;
            res.send(questionlist);
          });
        } else {
          questionlist.flag = 0;
          questionlist.question_data = [];
          res.send(questionlist);
        }
      } else {
        questionlist.flag = 5;
        res.send(questionlist);
      }
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
