const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/get_flt_section_list', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      var section_data = [];
      var section_list = {};
      var sql = `select count(*) as user_count from user_detail where user_id=${req.body.user_id} AND user_hash="${req.body.user_hash}"`;
      var user_data = await query(sql, conn);
      if (user_data[0].user_count > 0) {
        sql = `select test_time1,test_time2,test_time3,test_time4,test_time5 from test_master where test_id=${req.body.test_id} `;
        var test_data = await query(sql, conn);
        test_data = test_data[0];
        sql = `SELECT COUNT(question_master.ques_id) as total_ques,sum(question_master.ques_plus_mark)as positive_mark,section_master.section_name,section_master.section_id FROM question_master JOIN test_question ON question_master.ques_id=test_question.tq_ques_id JOIN section_master ON question_master.ques_section_id=section_master.section_id WHERE test_question.tq_test_id= ${req.body.test_id} GROUP BY question_master.ques_section_id ORDER BY section_sequence_no ASC`;
        var sectionData = await query(sql, conn);
        if (sectionData) {
          var i = 1;
          section_list.section_data = [];
          sectionData.forEach((section) => {
            section_data = [
              {
                section_id: section.section_id,
                section_name: section.section_name,
                section_time: test_data.test_time1,
                sec_total_question: section.total_ques,
                sec_total_mark: section.positive_mark,
              },
            ];

            section_list.flag = 1;
            section_list.section_data.push(section_data);
            i = i + 1;
          });
          res.json(section_list);
        } else {
          section_list.flag = 0;
          section_list.section_data = [];
          res.json(section_list);
        }
      } else {
        section_list.flag = 5;
        const result = JSON.stringify(section_list);
        res.json(result);
      }
      pool.releaseConnection(conn);
    }

    //re.json('Response');
  });
});

module.exports = router;
