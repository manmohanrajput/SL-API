const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

function ucfirst(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

router.post('/App_fetch_post_list_v1', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          data.app_id = req.body.app_id;
          data.pref_community_id = req.body.pref_community_id;
          data.post_count = req.body.post_count;
          data.max_user_post_sync_id = req.body.max_user_post_sync_id;
          data.limit = req.body.limit;
          var post_data1;
          var post_data2 = [];

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            data.user_id +
            `" and user_hash="` +
            data.user_hash +
            `"`;
          const user_Data = await query(sql, conn);

          if (user_Data[0].user_count > 0) {
            sql = `SELECT * FROM app_user_sync WHERE daus_user_id =${data.user_id} AND daus_app_id = ${data.app_id} `;

            var app_user_sync_data = await query(sql, conn2);

            if (app_user_sync_data) {
              if (
                data.max_user_post_sync_id <
                  app_user_sync_data[0].daus_post_sync_id &&
                data.max_user_post_sync_id > 0
              ) {
                var post_clause =
                  'AND post_sync_id>' + data.max_user_post_sync_id + '';
              } else {
                var post_clause =
                  'AND post_sync_id>' +
                  app_user_sync_data[0].daus_post_sync_id +
                  '';
              }
            } else {
              var post_clause = '';
              sql = `INSERT INTO  app_user_sync (daus_user_id,daus_app_id) VALUES (${data.user_id}, ${data.app_id})`;
              await query(sql, conn2);
              //$db2->insert('app_user_sync', array('daus_user_id' => $data['user_id'], 'daus_app_id' => $data['app_id']));
            }

            if (data.post_count < 1) {
              var post_clause = '';
            }

            // $maxPostData = $db2->query("SELECT max(post_sync_id) as max_post_sync_id FROM edu_post")->row_array();
            sql = 'SELECT max(post_sync_id) as max_post_sync_id FROM edu_post';
            var maxPostData = await query(sql, conn2);

            if (data.pref_community_ids == '') {
              post_data = [];

              //$json_response = json_encode($post_data);
              //echo $json_response;
              //die;
              res.json(post_data);
              // break ;
            }

            if (
              data.user_id != '' &&
              data.user_id != null &&
              data.user_id != 0
            ) {
              var current_date = Date('Y-m-d H:i:s');

              if (data.app_id == 1043) {
                var draftPostClause =
                  ' OR edu_post.status="draft" OR edu_post.status="ignore"';
                var draftPostLimit = '100';
              } else {
                var draftPostClause = '';
                var draftPostLimit = '400';
              }
              //var trim = data.pref_community_id.rtrim(',');
              //   $postData = $db2->query(
              //     "SELECT edu_post.*,edu_user_post.type,edu_user_post.user_id as eup_user_id,edu_user_post.response_question FROM edu_post
              //           LEFT JOIN edu_user_post ON edu_post.id=edu_user_post.post_id AND edu_user_post.user_id=" . $data['user_id'] . "
              //WHERE (edu_post.status='publish' OR edu_post.status='delete' " . $draftPostClause . ") AND edu_post.community_id IN(" . rtrim($data['pref_community_ids'], ',') . ") AND edu_post.community_id != 445 AND edu_post.spam_count<4 AND edu_post.delete_flag IS NULL AND (edu_post.app_id=0 OR edu_post.app_id IS NULL) AND (publish_date<='" . $current_date . "' OR publish_date IS NULL) " . $post_clause . " ORDER BY edu_post.add_date DESC LIMIT " . $draftPostLimit . "")->result_array();

              sql = `SELECT edu_post.*,edu_user_post.type,edu_user_post.user_id as eup_user_id,edu_user_post.response_question FROM edu_post LEFT JOIN edu_user_post ON edu_post.id=edu_user_post.post_id AND edu_user_post.user_id= ${data.user_id} WHERE (edu_post.status='publish' OR edu_post.status='delete' ${draftPostClause}) AND edu_post.community_id IN( ${data.pref_community_id} ) AND edu_post.community_id != 445 AND edu_post.spam_count<4 AND edu_post.delete_flag IS NULL AND (edu_post.app_id=0 OR edu_post.app_id IS NULL) AND (publish_date<= "${current_date}" OR publish_date IS NULL)  ${post_clause} ORDER BY edu_post.add_date DESC LIMIT ${draftPostLimit}`;

              var postData = await query(sql, conn2);

              if (postData) {
                await Promise.all(
                  postData.map(async (post) => {
                    /* if(strpos($post['description'],' ')!==false && strlen($post['description'])>240)
                          {
                          $tokens = explode(' ',substr($post['description'],0,240));
                          array_pop($tokens);
                          $post['description'] = implode(' ',$tokens);
                          } */

                    var postArr = [
                      {
                        post_id: post.id,
                        community_id: post.community_id,
                        app_id: 0,
                        user_id: post.user_id,
                        fname: ucfirst(post.user_first_name),
                        lname: ucfirst(post.user_last_name),
                        post_type: post.post_type,
                        post_title: post.title,
                        //'post_description' => substr(strip_tags($post['description']),0,80),
                        post_description: post.description,
                        video_url: post.video_url,
                        user_org_name: post.user_org_name,
                        comment_count: parseInt(post.comment_count),
                        upvote_count: parseInt(post.upvote_count),
                        view_count: Math.ceil((post.view_count + 1) / 3),
                        city_name: post.user_city,
                        spam_count: parseInt(post.spam_count),
                        post_date: post.add_date,
                        is_notify: parseInt(post.is_notify),
                        tag: post.tag,
                        question_reward: post.question_reward,
                        correct_response: post.correct_response,
                        status: post.status,
                        is_user_post: 0,
                        display_type: 'post',
                        reserve_1: post.reserve_1,
                        group_hash_tag: post.group_hash_tag,
                      },
                    ];

                    if (data.user_id == post.eup_user_id) {
                      if (post.correct_response == post.response_question) {
                        postArr.ques_attempt_flag = 1;
                        postArr.is_ques_correct = 1;
                        postArr.attemptmsg =
                          'You correctly answered "' +
                          post.response_question +
                          '"';
                      } else {
                        postArr.ques_attempt_flag = 1;
                        postArr.is_ques_correct = 0;
                        postArr.attemptmsg =
                          'You answered "' +
                          post.response_question +
                          '"+ Correct answer is "' +
                          post.correct_response +
                          '".';
                      }
                    } else {
                      postArr.ques_attempt_flag = 0;
                      postArr.is_ques_correct = 0;
                      postArr.attemptmsg = '';
                    }

                    if (post.description == '' || post.description == null) {
                      postArr.post_description = '';
                    }

                    if (post.image != '' && post.image != null) {
                      //$postArr['post_image'] = S3POSTURL . $post['image'] . "";
                      postArr.post_image = post.image;
                    } else {
                      postArr.post_image = '';
                    }

                    sql = `SELECT * from edu_user_post where user_id= ${data.user_id}  and post_id=${post.id} and mark_upvote=1`;

                    var q = await query(sql, conn2);

                    if (q.length > 0) {
                      postArr.upvoteFlag = 1;
                    } else {
                      postArr.upvoteFlag = 0;
                    }

                    if (
                      post.user_job_title != '' &&
                      post.user_job_title != null
                    ) {
                      postArr.job_title = post.user_job_title;
                    } else if (
                      post.user_type.indexOf('Student') !== null &&
                      post.user_type.indexOf('Student') !== -1
                    ) {
                      postArr.job_title = 'Student';
                    } else if (
                      post.user_type.indexOf('Parent') !== null &&
                      post.user_type.indexOf('Parent') !== -1
                    ) {
                      postArr.job_title = 'Parent';
                    } else if (
                      post.user_type.indexOf('Teacher') !== null &&
                      post.user_type.indexOf('Teacher') !== -1
                    ) {
                      postArr.job_title = 'Teacher';
                    } else {
                      postArr.job_title = '';
                    }
                    var viewcount = parseInt(post.view_count);
                    sql = `UPDATE edu_post SET view_count=${
                      viewcount + 1
                    } WHERE id= ${postArr[0].post_id}`;

                    await query(sql, conn2);
                    // $db2->where('id', $postArr['post_id']);
                    //   $db2->update('edu_post', array('view_count' => $post['view_count'] + 1));

                    postArr.user_image = post.user_image_url;

                    post_data1 = [];

                    post_data1.push(postArr);
                  })
                );
              } else {
                post_data1 = [];
              }

              // $postData = $db2->query("SELECT edu_post.*,edu_user_post.type,edu_user_post.user_id as eup_user_id,edu_user_post.response_question FROM edu_post
              //             LEFT JOIN edu_user_post ON edu_post.id=edu_user_post.post_id AND edu_user_post.user_id=" . $data['user_id'] . "
              //WHERE (edu_post.status='publish' OR edu_post.status='delete') AND edu_post.delete_flag IS NULL  AND edu_post.app_id=" . $data['app_id'] . " AND (edu_post.app_id=0 OR edu_post.app_id IS NULL) " . $post_clause . "  ORDER BY edu_post.add_date DESC LIMIT 10")->result_array();

              sql = `SELECT edu_post.*,edu_user_post.type,edu_user_post.user_id as eup_user_id,edu_user_post.response_question FROM edu_post LEFT JOIN edu_user_post ON edu_post.id=edu_user_post.post_id AND edu_user_post.user_id= ${data.user_id} WHERE (edu_post.status='publish' OR edu_post.status='delete') AND edu_post.delete_flag IS NULL  AND edu_post.app_id=${data.app_id} AND (edu_post.app_id=0 OR edu_post.app_id IS NULL) ${post_clause}  ORDER BY edu_post.add_date DESC LIMIT 10`;

              var postData = await query(sql, conn2);

              if (postData) {
                postData.forEach((post) => {
                  var postArr = [
                    {
                      post_id: post.id,
                      community_id: post.community_id,
                      app_id: parseInt(post.app_id),
                      user_id: post.user_id,
                      fname: ucfirst(post.user_first_name),
                      lname: ucfirst(post.user_last_name),
                      post_type: post.post_type,
                      post_title: post.title,
                      //'post_description' => substr(strip_tags($post['description']),0,80),
                      post_description: post.description,
                      video_url: post.video_url,
                      user_org_name: post.user_org_name,
                      comment_count: parseInt(post.comment_count),
                      upvote_count: parseInt(post.upvote_count),
                      view_count: Math.ceil((post.view_count + 1) / 3),
                      city_name: post.user_city,
                      spam_count: parseInt(post.spam_count),
                      post_date: post.add_date,
                      is_notify: parseInt(post.is_notify),
                      tag: post.tag,
                      question_reward: post.question_reward,
                      correct_response: post.correct_response,
                      status: post.status,
                      is_user_post: 0,
                      display_type: 'post',
                      reserve_1: post.reserve_1,
                      group_hash_tag: post.group_hash_tag,
                    },
                  ];

                  if (data.user_id == post.eup_user_id) {
                    if (post.correct_response == post.response_question) {
                      postArr.ques_attempt_flag = 1;
                      postArr.is_ques_correct = 1;
                      postArr.attemptmsg =
                        'You correctly answered "' +
                        post.response_question +
                        '"';
                    } else {
                      postArr.ques_attempt_flag = 1;
                      postArr.is_ques_correct = 0;
                      postArr.attemptmsg =
                        'You answered "' +
                        post.response_question +
                        '". Correct answer is "' +
                        post.correct_response +
                        '".';
                    }
                  } else {
                    postArr.ques_attempt_flag = 0;
                    postArr.is_ques_correct = 0;
                    postArr.attemptmsg = '';
                  }

                  if (post.description == '' || post.description == null) {
                    postArr.post_description = '';
                  }

                  if (post.image != '' && post.image != null) {
                    //$postArr['post_image'] = S3POSTURL . $post['image'] . "";
                    postArr.post_image = post.image;
                  } else {
                    postArr.post_image = '';
                  }

                  postArr.upvoteFlag = 0;

                  if (
                    post.user_job_title != '' &&
                    post.user_job_title != null
                  ) {
                    postArr.job_title = post.user_job_title;
                  } else if (
                    post.user_type.indexOf('Student') !== null &&
                    post.user_type.indexOf('Student') !== -1
                  ) {
                    postArr.job_title = 'Student';
                  } else if (
                    post.user_type.indexOf('Parent') !== null &&
                    post.user_type.indexOf('Parent') !== -1
                  ) {
                    postArr.job_title = 'Parent';
                  } else if (
                    post.user_type.indexOf('Teacher') !== null &&
                    post.user_type.indexOf('Teacher') !== -1
                  ) {
                    postArr.job_title = 'Teacher';
                  } else {
                    postArr.job_title = '';
                  }

                  /* $this->db->where('id',$postArr['post_id']);
                          $this->db->update('edu_post',array('view_count' => $post['view_count'] + 1)); */

                  postArr.user_image = post.user_image_url;

                  post_data2.push(postArr);
                });
              } else {
                post_data2 = [];
              }

              //        $db2->where('daus_user_id', $data['user_id']);
              //      $db2->where('daus_app_id', $data['app_id']);
              //    $db2->update('app_user_sync', array('daus_post_sync_id' => $maxPostData['max_post_sync_id']));
              sql = `UPDATE app_user_sync SET daus_post_sync_id=${maxPostData[0].max_post_sync_id} WHERE daus_user_id=${data.user_id} AND  daus_app_id= ${data.app_id} `;
              await query(sql, conn2);

              var post_data = {};
              var data = post_data1.concat(post_data2);
              post_data.posts = data;

              post_data.user_max_sync_id = maxPostData[0].max_post_sync_id;

              //print_r($post_data1);die;
              //$json_response = json_encode($post_data);
              ///echo $json_response;
              //die
              res.send(post_data);
            } // end of if not empty user row
            else {
              var post_data = [];

              //$json_response = json_encode($post_data);
              //echo $json_response;
              res.send(post_data);
            }
          } else {
            var post_data = [];
            post_data.flag = 5;
            res.send(post_data);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
