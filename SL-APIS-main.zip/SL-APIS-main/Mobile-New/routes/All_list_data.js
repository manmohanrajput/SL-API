const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/All_list_data', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const category = req.body.category;
          const subcategory = req.body.subcategory;
          const type = req.body.type;

          var sql =
            "SELECT id, title, content, image, add_date,url,category,sub_category,type,mob_post_hash FROM mob_post WHERE category='" +
            data.category +
            "' AND sub_category='" +
            data.subcategory +
            "' AND type='" +
            data.type +
            "' AND status = 'active' ORDER BY sequence_number ASC limit 500";
          const listpostData = (await query(sql, conn))[0];

          if (listpostData) {
            listpostData.forEach((listpost) => {
              if (listpost.add_date != null && listpost.add_date != '') {
                const cd = new Date(listpost.add_date);
                const date = cd.formate('d-m-y');
              } else {
                const date = null;
              }
              if (listpost.url != null && listpost.url != '') {
                const url = listpost.url;
              } else {
                const url = null;
              }
              const data = [
                {
                  id: listpost.id,
                  mob_post_hash: listpost.mob_post_hash,
                  title: listpost.title,
                  add_date: date,
                  url: url,
                },
              ];
              listpost_Data.flag = 1;
              //$listpost_Data['authFlag'] = 1;
              listpost_Data.listpostData = data;
            });
          } else {
            listpost_Data.flag = 0;
            listpost_Data.listpostData = [];
          }
          json.response(listpost_Data);
        }
        pool2.releaseConnection(conn2);
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
