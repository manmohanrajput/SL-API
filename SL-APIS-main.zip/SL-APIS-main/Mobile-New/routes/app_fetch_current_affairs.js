const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/app_fetch_current_affairs', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      res.status(500).send('Server Error');
    } else {
      const category = req.body.category;
      const add_date = req.body.add_date;
      const country_name = req.body.country_name;
      const app_hash = req.body.app_hash;
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;
      var currentAffairsData;
      var listpost_Data = {};

      var sql =
        `select count(*)as user_count from user_detail where user_id="` +
        req.body.user_id +
        `" and user_hash="` +
        req.body.user_hash +
        `"`;

      const user_data = (await query(sql, conn))[0];

      if (user_data.user_count > 0) {
        sql = `SELECT country_id FROM country WHERE LOWER(country_name)= ${country_name.toLowerCase()}`;
        const countryData = (await query(sql, conn))[0];
        if (countryData) {
          countryId = countryData.country_id;
        } else {
          countryId = 0;
        }
        if (category === 'CA_ENG' || category === 'CA_HIN') {
          if (
            app_hash === '8e6cd74af474f619cbefa2da1837aa0' ||
            app_hash === '72475c87f984f0435e9e5000ded88ff' ||
            app_hash === '699c7c8f80a465b26209374ee7db8049'
          ) {
            if (countryId > 0) {
              const currentaffairssql = `SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category=${category}AND add_date < ${add_date} and post_countries REGEXP (^|,) ${countryId} (,|$)  ORDER BY add_date desc LIMIT 50`;
              currentAffairsData = await query(currentaffairssql, conn);
            } else {
              const currentaffairssql = `SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category= ${category} AND add_date < ${add_date} and  (post_countries IS NULL OR post_countries=" ")  ORDER BY add_date desc LIMIT 50`;
              currentAffairsData = await query(currentaffairssql, conn);
            }
          } else {
            const currentaffairssql = `SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category= ${category} AND add_date < ${add_date} ORDER BY add_date desc LIMIT 50`;
            currentAffairsData = await query(currentaffairssql, conn);
          }
        } else {
          const currentaffairssql = `SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category=${category}  AND add_date < ${add_date}  ORDER BY add_date desc LIMIT 50`;
          currentAffairsData = await query(currentaffairssql, conn);
        }
        console.log(currentAffairsData);
        if (currentAffairsData) {
          currentAffairsData.reverse();
          currentAffairsData.forEach((currentaffairs) => {
            if (
              currentaffairs.add_date !== null &&
              currentaffairs.add_date !== ''
            ) {
              const cd = new Datetime(currentaffairs.add_date);
              const date = cd.format('Y-m-d H:i:s');
            } else {
              const date = null;
            }
            if (
              currentaffairs.url_v2 !== null &&
              currentaffairs.url_v2 !== ''
            ) {
              const url = currentaffairs.url_v2;
            } else {
              url = null;
            }
            const data = [
              {
                mob_post_hash: currentaffairs.mob_post_hash,
                title: currentaffairs.title,
                content: currentaffairs.content,
                add_date: date,
                category: currentaffairs.category.trim(),
                subcategory: currentaffairs.sub_category,
                type: currentaffairs.type,
                url: url,
                seq_no: parseInt(currentaffairs.sequence_number),
                status: currentaffairs.status,
                is_notify: parseInt(currentaffairs.is_notify),
              },
            ];

            if (currentaffairs.type === '' || currentaffairs.type === null) {
              data.type = '';
            }
            listpost_Data.current_affairs = data;
          });
          listpost_Data.flag = 1;
        } else {
          listpost_Data = [];
          listpost_Data.flag = 0;
        }
        res.json(listpost_Data);
      } else {
        listpost_Data = [];
        listpost_Data.flag = 5;
        res.json(listpost_Data);
      }
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
