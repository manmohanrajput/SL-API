const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_community_about_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const community_id = req.body.community_id;
          const app_id = req.body.app_id;

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `" and user_hash="` +
            user_hash +
            `"`;
          const user_Data = await query(sql, conn);

          var categoryRow;
          var categoryData = {};
          if (user_Data[0].user_count > 0) {
            sql = `SELECT *FROM edu_groups WHERE id ="` + community_id + `"`;
            //$categoryRow = $db2->get_where('edu_groups', array('id' => $community_id))->row_array();
            categoryRow = await query(sql, conn2);

            if (categoryRow) {
              if (
                community_id != '' &&
                community_id != null &&
                community_id != 0
              ) {
                sql =
                  `UPDATE edu_groups SET count_post = (SELECT count(id) as postCount FROM edu_post WHERE community_id="` +
                  community_id +
                  `" AND delete_flag IS NULL AND status='publish' AND (spam_count<4 OR spam_count IS NULL)) WHERE id="` +
                  community_id +
                  `"`;
                //$this->db->query("UPDATE edu_groups SET count_follower = (SELECT count(id) as followerCount FROM edu_group_members WHERE community_id=".$community_id." AND status=1) WHERE id=".$community_id."");
              }

              categoryData.flag = 1;
              categoryData.about = categoryRow[0].about;
              categoryData.community_id = categoryRow[0].id;
              categoryData.tag = categoryRow[0].tag;
              categoryData.count_follower = categoryRow[0].count_follower;
              categoryData.count_post = categoryRow[0].count_post;
              categoryData.reward = categoryRow[0].reward;
              categoryData.joiningBonus = categoryRow[0].joining_bonus;

              if (
                categoryRow.group_logo != null &&
                categoryRow.group_logo != ''
              ) {
                categoryData.group_logo =
                  '' +
                  base_url() +
                  'upload/edu_group_logo/' +
                  categoryRow.group_logo;
              } else {
                categoryData.group_logo = '';
              }
              var grpAdminArr = [];
              grpAdminArr.push(categoryRow.group_admin);

              if (grpAdminArr.includes(user_id)) {
                categoryData.isGroupAdmin = true;
              } else {
                categoryData.isGroupAdmin = false;
              }
            } else {
              categoryData.flag = 0;
            }

            res.send(categoryData);
          } else {
            categoryData.flag = 5;
            res.send(categoryData);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
