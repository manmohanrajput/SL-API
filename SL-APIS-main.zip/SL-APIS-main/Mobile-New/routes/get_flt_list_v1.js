const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/get_flt_list_v1', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var app_id = req.body.app_id;
          var user_id = req.body.user_id;
          var user_hash = req.body.user_hash;
          var exam_id = req.body.exam_id;
          var exam_id_2 = req.body.exam_id_2;
          var sub_category = req.body.sub_category;
          var testlist = {};
          console.log('debug', 'in get_flt_list service');
          if (sub_category == '') {
            sub_category = '';
          } else {
            sub_category =
              "and test_master.subject_type='" + sub_category + "'";
          }

          var sql =
            'select count(*)as user_count from user_detail where user_id=' +
            user_id +
            " and user_hash='" +
            user_hash +
            "'";
          user_Data = await query(sql, conn);

          if (user_Data[0].user_count > 0) {
            sql =
              'SELECT test_master.test_instruction_type,test_master.test_instruction,test_master.test_id,test_master.test_name,test_master.test_exam_type_id,test_master.test_desc,test_master.test_time,test_master.test_ques_no,test_master.test_status,test_master.test_created,test_master.test_mark_per_ques,test_master.test_negative_mark,test_master.test_total_mark,test_master.test_req_per FROM test_master WHERE (test_exam_type_id=' +
              exam_id +
              ' OR test_exam_type_id=' +
              exam_id_2 +
              ') ' +
              sub_category +
              '    AND (test_master.test_status = 1 OR test_master.test_status = 2) ORDER BY test_master.test_sequence_no ASC';
            const testData = await query(sql, conn);
            if (testData) {
              testlist.test_data = [];
              await Promise.all(
                testData.map(async (test) => {
                  if (
                    test.test_exam_type_id == 46 ||
                    test.test_exam_type_id == 47 ||
                    test.test_exam_type_id == 123 ||
                    test.test_exam_type_id == 122 ||
                    test.test_exam_type_id == 130 ||
                    test.test_exam_type_id == 131 ||
                    test.test_exam_type_id == 126 ||
                    test.test_exam_type_id == 128 ||
                    test.test_exam_type_id == 2 ||
                    test.test_exam_type_id == 1 ||
                    test.test_exam_type_id == 6 ||
                    test.test_exam_type_id == 3 ||
                    test.test_exam_type_id == 134 ||
                    test.test_exam_type_id == 135 ||
                    test.test_exam_type_id == 136 ||
                    test.test_exam_type_id == 137 ||
                    test.test_exam_type_id == 33 ||
                    test.test_exam_type_id == 34 ||
                    test.test_exam_type_id == 216 ||
                    test.test_exam_type_id == 217 ||
                    test.test_exam_type_id == 114 ||
                    test.test_exam_type_id == 115 ||
                    test.test_exam_type_id == 168 ||
                    test.test_exam_type_id == 169 ||
                    test.test_exam_type_id == 142 ||
                    test.test_exam_type_id == 143 ||
                    test.test_exam_type_id == 172 ||
                    test.test_exam_type_id == 173 ||
                    test.test_exam_type_id == 17 ||
                    test.test_exam_type_id == 20 ||
                    test.test_exam_type_id == 292 ||
                    test.test_exam_type_id == 293 ||
                    test.test_exam_type_id == 296 ||
                    test.test_exam_type_id == 297 ||
                    test.test_exam_type_id == 294 ||
                    test.test_exam_type_id == 295 ||
                    test.test_exam_type_id == 304 ||
                    test.test_exam_type_id == 305 ||
                    test.test_exam_type_id == 13 ||
                    test.test_exam_type_id == 12 ||
                    test.test_exam_type_id == 300 ||
                    test.test_exam_type_id == 301 ||
                    test.test_exam_type_id == 306 ||
                    test.test_exam_type_id == 307 ||
                    test.test_exam_type_id == 29 ||
                    test.test_exam_type_id == 30 ||
                    test.test_exam_type_id == 316 ||
                    test.test_exam_type_id == 317 ||
                    test.test_exam_type_id == 31 ||
                    test.test_exam_type_id == 32 ||
                    test.test_exam_type_id == 150 ||
                    test.test_exam_type_id == 151 ||
                    test.test_exam_type_id == 308 ||
                    test.test_exam_type_id == 309 ||
                    test.test_exam_type_id == 154 ||
                    test.test_exam_type_id == 155 ||
                    test.test_exam_type_id == 310 ||
                    test.test_exam_type_id == 311 ||
                    test.test_exam_type_id == 182 ||
                    test.test_exam_type_id == 183 ||
                    test.test_exam_type_id == 186 ||
                    test.test_exam_type_id == 187 ||
                    test.test_exam_type_id == 190 ||
                    test.test_exam_type_id == 191 ||
                    test.test_exam_type_id == 194 ||
                    test.test_exam_type_id == 195 ||
                    test.test_exam_type_id == 198 ||
                    test.test_exam_type_id == 199 ||
                    test.test_exam_type_id == 9 ||
                    test.test_exam_type_id == 14 ||
                    test.test_exam_type_id == 288 ||
                    test.test_exam_type_id == 289 ||
                    test.test_exam_type_id == 202 ||
                    test.test_exam_type_id == 203
                  ) {
                    var language = 'english';
                  } else if (
                    test.test_exam_type_id == 120 ||
                    test.test_exam_type_id == 121 ||
                    test.test_exam_type_id == 124 ||
                    test['test_exam_type_id'] == 125 ||
                    test.test_exam_type_id == 132 ||
                    test.test_exam_type_id == 133 ||
                    test.test_exam_type_id == 127 ||
                    test.test_exam_type_id == 129 ||
                    test.test_exam_type_id == 7 ||
                    test.test_exam_type_id == 5 ||
                    test.test_exam_type_id == 8 ||
                    test.test_exam_type_id == 4 ||
                    test.test_exam_type_id == 138 ||
                    test.test_exam_type_id == 139 ||
                    test.test_exam_type_id == 140 ||
                    test.test_exam_type_id == 141 ||
                    test.test_exam_type_id == 118 ||
                    test.test_exam_type_id == 119 ||
                    test.test_exam_type_id == 218 ||
                    test.test_exam_type_id == 219 ||
                    test.test_exam_type_id == 116 ||
                    test.test_exam_type_id == 117 ||
                    test.test_exam_type_id == 170 ||
                    test.test_exam_type_id == 171 ||
                    test.test_exam_type_id == 144 ||
                    test.test_exam_type_id == 145 ||
                    test.test_exam_type_id == 174 ||
                    test.test_exam_type_id == 175 ||
                    test.test_exam_type_id == 184 ||
                    test.test_exam_type_id == 185 ||
                    test.test_exam_type_id == 188 ||
                    test.test_exam_type_id == 189 ||
                    test.test_exam_type_id == 192 ||
                    test.test_exam_type_id == 193 ||
                    test.test_exam_type_id == 196 ||
                    test.test_exam_type_id == 197 ||
                    test.test_exam_type_id == 200 ||
                    test.test_exam_type_id == 201 ||
                    test.test_exam_type_id == 204 ||
                    test.test_exam_type_id == 205
                  ) {
                    var language = 'hindi';
                  }

                  //                    if ($test['test_instruction_type'] == 1) {
                  //                        $test_data['instruction'] = $test['test_instruction'];
                  //                    } else if ($test['test_instruction_type'] == 0) {
                  //                        if ($test['test_exam_type_id'] == 46 ||test.test_exam_type_id == 47 ||test.test_exam_type_id == 123 ||test.test_exam_type_id == 122 ||test.test_exam_type_id == 130 ||test.test_exam_type_id == 131 ||test.test_exam_type_id == 126 ||test.test_exam_type_id == 128 ||test.test_exam_type_id == 2 ||test.test_exam_type_id == 1 ||test.test_exam_type_id == 6 ||test.test_exam_type_id == 3 ||
                  //                               test.test_exam_type_id == 134 ||test.test_exam_type_id == 135 ||test.test_exam_type_id == 136 ||test.test_exam_type_id == 137 ||test.test_exam_type_id == 33 ||test.test_exam_type_id == 34 ||test.test_exam_type_id == 216 ||test.test_exam_type_id == 217 ||test.test_exam_type_id == 114 ||test.test_exam_type_id == 115 ||test.test_exam_type_id == 168 ||test.test_exam_type_id == 169 ||
                  //                               test.test_exam_type_id == 142 ||test.test_exam_type_id == 143 ||test.test_exam_type_id == 172 ||test.test_exam_type_id == 173 ||test.test_exam_type_id == 17 ||test.test_exam_type_id == 20 ||test.test_exam_type_id == 292 ||test.test_exam_type_id == 293 ||test.test_exam_type_id == 296 ||test.test_exam_type_id == 297 ||test.test_exam_type_id == 294 ||test.test_exam_type_id == 295 ||
                  //                               test.test_exam_type_id == 304 ||test.test_exam_type_id == 305 ||test.test_exam_type_id == 13 ||test.test_exam_type_id == 12 ||test.test_exam_type_id == 300 ||test.test_exam_type_id == 301 ||test.test_exam_type_id == 306 ||test.test_exam_type_id == 307 ||test.test_exam_type_id == 29 ||test.test_exam_type_id == 30 ||test.test_exam_type_id == 316 ||test.test_exam_type_id == 317 ||
                  //                               test.test_exam_type_id == 31 ||test.test_exam_type_id == 32 ||test.test_exam_type_id == 150 ||test.test_exam_type_id == 151 ||test.test_exam_type_id == 308 ||test.test_exam_type_id == 309 ||test.test_exam_type_id == 154 ||test.test_exam_type_id == 155 ||test.test_exam_type_id == 310 ||test.test_exam_type_id == 311 ||test.test_exam_type_id == 182 ||test.test_exam_type_id == 183 ||
                  //                               test.test_exam_type_id == 186 ||test.test_exam_type_id == 187 ||test.test_exam_type_id == 190 ||test.test_exam_type_id == 191 ||test.test_exam_type_id == 194 ||test.test_exam_type_id == 195 ||test.test_exam_type_id == 198 ||test.test_exam_type_id == 199 ||test.test_exam_type_id == 202 ||test.test_exam_type_id == 203) {
                  //                            $test_data['instruction'] = '1.Total of ' . $test['test_time'] . ' duration will be given to attempt all the questions across all the sections.
                  //                                                            2.The clock has been set at the server and the countdown timer at the top right corner of your screen will display the time remaining for you to complete the exam. When the clock runs out the exam ends by default-you are not required to end or submit your exam.
                  //															3. Navigate through questions using Next or Back buttons.
                  //															4. Click on the option to select your answer.
                  //															The test will have the following structure : ' . $test['test_instruction'] . '';
                  //                        } else if ($test['test_exam_type_id'] == 120 ||test.test_exam_type_id == 121 ||test.test_exam_type_id == 124 ||test.test_exam_type_id == 125 ||test.test_exam_type_id == 132 ||test.test_exam_type_id == 133 ||test.test_exam_type_id == 127 ||test.test_exam_type_id == 129 ||test.test_exam_type_id == 7 ||test.test_exam_type_id == 5 ||test.test_exam_type_id == 8 ||test.test_exam_type_id == 4 ||
                  //                               test.test_exam_type_id == 138 ||test.test_exam_type_id == 139 ||test.test_exam_type_id == 140 ||test.test_exam_type_id == 141 ||test.test_exam_type_id == 118 ||test.test_exam_type_id == 119 ||test.test_exam_type_id == 218 ||test.test_exam_type_id == 219 ||test.test_exam_type_id == 116 ||test.test_exam_type_id == 117 ||test.test_exam_type_id == 170 ||test.test_exam_type_id == 171 ||
                  //                               test.test_exam_type_id == 144 ||test.test_exam_type_id == 145 ||test.test_exam_type_id == 174 ||test.test_exam_type_id == 175 ||test.test_exam_type_id == 184 ||test.test_exam_type_id == 185 ||test.test_exam_type_id == 188 ||test.test_exam_type_id == 189 ||test.test_exam_type_id == 192 ||test.test_exam_type_id == 193 ||test.test_exam_type_id == 196 ||test.test_exam_type_id == 197 ||
                  //                               test.test_exam_type_id == 200 ||test.test_exam_type_id == 201 ||test.test_exam_type_id == 204 ||test.test_exam_type_id == 205) {
                  //                            $test_data['instruction'] = '1.सभी प्रश्नों को हल करने के लिए' . $test['test_time'] . 'मिनिट का समय दिया जायेगा
                  //															2.सर्वर पर घड़ी सेट की गयी है, तथा आपकी स्क्रीन के दाहिने कोने में शीर्ष पर काउंट - डाउन टाइमर है जो आपके लिए परीक्षा समाप्त होने की शेष अवधि को प्रदर्शित करेगा। परीक्षा समय समाप्त होने पर, आपको अपनी परीक्षा बंद या समाप्त करने की जरूरत नहीं है। यह स्वतः बंद या जमा हो जायेगी।
                  //															3.किसी प्रश्न पर जाने हेतु  Next अथवा Back बटन का प्रयोग करें।
                  //															4.उत्तर देने हेतु कोई एक विकल्प चुने।
                  //															5.परीक्षा में निम्नलिखित अनुदेश होंगे: ' . $test['test_instruction'] . '';
                  //                        }
                  //                    }

                  // Start - Added by vasudha, Date : 20-Feb-2021

                  sql =
                    'select inst_id from mob_app_detail where app_id=' +
                    app_id +
                    '';
                  var inst_data = await query(sql, conn);
                  sql =
                    "SELECT * FROM inst_test where inst_id ='" +
                    inst_data.inst_id +
                    "' AND test_id='" +
                    test.test_id +
                    "'";
                  var num_rows = await query(sql, conn);
                  if (num_rows > 0) {
                    testDatan.test_status = 3; //1=Active
                  } else {
                    if (test.test_status == 2) {
                      testData.test_status = 2; // Coming Soon
                    } else {
                      testData.test_status = 1; //2=In-Active
                    }
                  }

                  // End - Added by vasudha, Date : 20-Feb-2021

                  var test_data = [
                    {
                      test_id: test.test_id,
                      exam_id: parseInt(test.test_exam_type_id),
                      test_language: language,
                      test_status: parseInt(testData.test_status), // line added by vasudha
                      test_name: test.test_name,
                      //'test_tag'=>$test['test_category'],
                      total_ques: test.test_ques_no,
                      total_time: test.test_time,
                      test_desc: test.test_desc,
                      // 'test_status' => intval($test['test_status']), // line comment by vasudha
                      add_date: test.test_created,
                      positive_mark: test.test_mark_per_ques,
                      negative_mark: test.test_negative_mark,
                      total_mark: test.test_total_mark,
                      test_req_per: test.test_req_per,
                    },
                  ];

                  var sql =
                    'select count(res_id) as res_count,res_id,res_per_obtain,res_correct_ans,res_marks_obtain,res_wrong_ans from result where res_user_id=' +
                    user_id +
                    ' and res_test_id=' +
                    test.test_id +
                    '';
                  var result_data = await query(sql, conn);

                  // echo $this->db->last_query();die;
                  if (result_data && result_data.res_count > 0) {
                    test_data.is_attempted = 1;
                    test_data.res_count = result_data.res_count;
                    test_data.percentage = result_data.res_per_obtain;
                    //$test_data['mark_obtain'] = ($result_data['res_correct_ans'] * $test['test_mark_per_ques']) - ($result_data['res_wrong_ans'] * $test['test_negative_mark']);
                    test_data.mark_obtain = result_data.res_marks_obtain;
                  } else {
                    test_data.is_attempted = 0;
                    test_data.res_count = 0;
                    test_data.percentage = 0;
                    test_data.mark_obtain = 0;
                  }
                  testlist.flag = 1;
                  testlist.test_data.push(test_data);
                })
              );
              res.send(testlist);
            } else {
              testlist.flag = 0;
              testlist.test_data = [];
              res.send(testlist);
            }
          } else {
            testlist.flag = 5;
            res.send(testlist);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
