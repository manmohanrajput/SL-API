const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_all_list_data_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      console.log(req.body);
      var data = {};
      data.user_id = req.body.user_id;
      data.user_hash = req.body.user_hash;
      data.category = req.body.category;
      data.subcategory = req.body.subcategory;
      data.type = req.body.type;
      var listpost_Data = {};

      var sql =
        `select count(*)as user_count from user_detail where user_id="` +
        data.user_id +
        `"and user_hash="` +
        data.user_hash +
        `"`;
      const user_Data = await query(sql, conn);
      console.log(user_Data);

      if (user_Data[0].user_count > 0) {
        sql = `SELECT id, title, content, image, add_date,url,category,sub_category,type,mob_post_hash FROM mob_post WHERE category=${data.category} AND sub_category=${data.subcategory} AND type =${data.type} AND status = "active" ORDER BY sequence_number ASC limit 500`;
        console.log(sql);

        const listpostData = await query(sql, conn);
        console.log(listpostData);
        if (listpostData) {
          listpostData.forEach((listpost) => {
            if (listpost.add_date != null && listpost.add_date != '') {
              cd = Date(listpost.add_date);
              date = cd;
            } else {
              date = null;
            }
            if (listpost.url != null && listpost.url != '') {
              url = listpost.url;
            } else {
              url = null;
            }
            data = [
              {
                id: listpost.id,
                mob_post_hash: listpost.mob_post_hash,
                title: listpost.title,
                add_date: date,
                url: url,
              },
            ];
            listpost_Data.flag = 1;
            //$listpost_Data['authFlag'] = 1;
            listpost_Data.listpostData = data;
          });
        } else {
          listpost_Data.flag = 0;
          //$listpost_Data['authFlag'] = 1;
          listpost_Data.listpostData = [];
        }

        res.json(listpost_Data);
      } else {
        listpost_Data.flag = 5;
        listpost_Data.listpostData = [];
        res.json(listpost_Data);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
