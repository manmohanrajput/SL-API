const express = require('express');
const router = express.Router();
const pool = require('../config/db');

const query = require('../utils/query');

router.post('/App_success_payment_info', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      var data = {};
      const app_hash = req.body.app_hash;
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;
      const app_id = req.body.app_id;
      const payment_id = req.body.payment_id;
      const amount = req.body.amount;

      var sql =
        `select count(*)as user_count from user_detail where  user_id ="` +
        user_id +
        `"`;
      const user_Data = await query(sql, conn);
      console.log(user_Data);
      if (user_Data[0].user_count > 0) {
        //$this->load->model('User_model');

        const insert_data = {
          user_id: user_id,
          user_hash: user_hash,
          app_id: app_id,
          payment_id: payment_id,
          amount: amount,
          created_on: Date.now(),
        };

        console.log(insert_data.user_id);
        // var lastId = $this->User_model->insert('mob_app_payment_info',$insert_data)
        sql = ` INSERT INTO mob_app_payment_info(user_id,app_id,payment_id,amount,created_on) VALUES (${insert_data.user_id},${insert_data.app_id},${insert_data.payment_id},${insert_data.amount},${insert_data.created_on}) `;

        var lastId = await query(sql, conn);
        data.status = 'success';
        data.msg = 'Payment Successfully';
        data.flag = 1;
      } else {
        data.status = 'failed';
        data.msg = 'user not authorized';
        data.flag = 5;
      }
      res.send(data);
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
