const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

function trim(str, chr) {
  var rgxtrim = !chr
    ? new RegExp('^\\s+|\\s+$', 'g')
    : new RegExp('^' + chr + '+|' + chr + '+$', 'g');
  return str.replace(rgxtrim, '');
}
function ltrim(str, chr) {
  var rgxtrim = !chr ? new RegExp('^\\s+') : new RegExp('^' + chr + '+');
  return str.replace(rgxtrim, '');
}
function rtrim(str, chr) {
  var rgxtrim = !chr ? new RegExp('\\s+$') : new RegExp(chr + '+$');
  return str.replace(rgxtrim, '');
}
router.post('/App_fetch_reading_v1', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const app_hash = req.body.app_hash;
          const row_count = req.body.row_count;
          const language = req.body.language;
          const max_reading_sync_id = req.body.max_reading_sync_id;
          var listpost_Data = {};

          if (user_id > 0) {
          } else {
            //break;
          }

          var sql = `select count(*)as user_count from user_detail where user_id=${user_id} and user_hash= "${user_hash}"`;
          const user_Data = await query(sql, conn);
          if (user_Data[0].user_count > 0) {
            //            include 'application/libraries/Ss-ga.class.php';
            //            $ssga = new ssga('UA-44140201-22', 'mob.mycareerlift.com');
            //            $ssga->set_page('/App_fetch_reading_v0');
            //            $ssga->set_page_title('App fetch reading v0');
            //            $ssga->set_event('App_fetch_reading_v0', 'fetch_reading_v0', 'fetch_reading_v0', 'fetch_reading_v0');
            //            $ssga->send();
            //            $ssga->reset();
            /* $masterUserData = $this->db->query("SELECT account_status FROM master_user_login WHERE user_id=".$user_id."")->row_array();
              if($masterUserData['account_status']==2){
              echo 'user not authorised';die;
              } */

            /*           $countryData = $this->db->query('SELECT country_id FROM `country` WHERE LOWER(country_name)= "' . strtolower($country_name) . '"')->row_array();
            if (!empty($countryData)) {
                $countryId = $countryData['country_id'];
            } else {
                $countryId = 0;
            }*/

            //  $mobAppHashData = $this->db->query("SELECT app_id FROM mob_app_detail WHERE app_hash='" . $app_hash . "'")->row_array();
            sql = ` SELECT app_id FROM mob_app_detail WHERE app_hash="${app_hash}"`;
            var mobAppHashData = await query(sql, conn);
            var app_id = mobAppHashData[0].app_id;

            if (row_count < 5) {
              // $this->db->where('aus_app_id', $app_id);
              // $this->db->where('aus_user_id', $user_id);
              // $this->db->update('ots_app_user_sync', array('aus_mob_post_sync_id' => 0));
              sql = `UPDATE ots_app_user_sync SET aus_mob_post_sync_id = 0 WHERE aus_app_id = ${app_id} AND aus_user_id = ${user_id}`;
              await query(sql, conn);
            }

            //     $appUserSyncData = $this->db->get_where('ots_app_user_sync', array('aus_user_id' => $user_id, 'aus_app_id' => $app_id))->row_array();
            sql = `SELECT * FROM ots_app_user_sync WHERE aus_user_id = ${user_id} AND aus_app_id= ${app_id}`;
            var appUserSyncData = await query(sql, conn);
            if (appUserSyncData) {
              var app_user_sync_arr = [
                {
                  aus_user_id: user_id,
                  aus_app_id: app_id,
                },
              ];
              // $this->db->insert('ots_app_user_sync', $app_user_sync_arr);
              sql = `INSERT ots_app_user_sync (aus_user_id,aus_app_id) VALUES(${app_user_sync_arr[0].aus_user_id},${app_user_sync_arr[0].aus_user_id})`;
              await query(sql, conn);
              //  $appUserSyncData = $this->db->get_where('ots_app_user_sync', array('aus_user_id' => $user_id, 'aus_app_id' => $app_id))->row_array();
              sql = `SELECT * FROM ots_app_user_sync WHERE aus_user_id= ${user_id} AND aus_app_id= ${app_id}`;
              var appUserSyncData = await query(sql, conn);
            }

            //  $mobAppReadData = $this->db->query("SELECT * FROM mob_app_reading WHERE mar_app_id = " . $app_id . " AND (mar_category = 'career_options' OR mar_category = 'career_options_hin') AND mar_type='article'")->row_array();
            sql = `SELECT * FROM mob_app_reading WHERE mar_app_id =${app_id}  AND (mar_category = 'career_options' OR mar_category = 'career_options_hin') AND mar_type='article'`;
            var mobAppReadData = await query(sql, conn);
            if (mobAppReadData) {
              if (
                mobAppReadData.mar_disable_post_ids != '' &&
                mobAppReadData.mar_disable_post_ids
              ) {
                var filter_reading =
                  'AND id NOT IN(' + mobAppReadData.mar_disable_post_ids + ')';
              } else {
                var filter_reading = '';
              }
            } else {
              var filter_reading = '';
            }

            /*            if ($app_hash == '8e6cd74af474f619cbefa2da1837aa0') {
                $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
                FROM mob_post
                WHERE (category='career_opportunities') AND type='article' AND status='active' ORDER BY sequence_number ASC";
            } else if ($app_hash == '699c7c8f80a465b26209374ee7db8049' && check_country($countryId) == 1) {
                $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
                FROM mob_post
                WHERE (category='career_opportunities') AND type='article' AND status='active' ORDER BY sequence_number ASC";
            } else {
                if ($language == 'hindi') {
                    $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
                FROM mob_post
                WHERE (category='career_options_hin') AND type='article' AND status='active' " . $filter_reading . " ORDER BY sequence_number ASC";
                } else {
                    $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
                FROM mob_post
                WHERE (category='career_options') AND type='article' AND status='active' " . $filter_reading . " ORDER BY sequence_number ASC";
                }
            }*/

            //                if ($language == 'hindi') {
            //                    $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
            //                FROM mob_post
            //                WHERE (category='career_options_hin') AND type='article' AND status='active' " . $filter_reading . " ORDER BY sequence_number ASC";
            //                } else {
            //                    $sql = "SELECT id,mob_post_hash, title, content, image, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,post_countries
            //                FROM mob_post
            //                WHERE (category='career_options') AND type='article' AND status='active' " . $filter_reading . " ORDER BY sequence_number ASC";
            //                }
            //
            //
            //            $readingData = $this->db->query($sql)->result_array();
            //            if (!empty($readingData)) {
            //                foreach ($readingData as $reading) {
            //                    if ($reading['add_date'] != NULL && $reading['add_date'] != '') {
            //                        $cd = new Datetime($reading['add_date']);
            //                        $date = $cd->format('Y-m-d H:i:s');
            //                    } else {
            //                        $date = NULL;
            //                    }
            //                    if ($reading['url_v2'] != NULL && $reading['url_v2'] != '') {
            //                        $url = $reading['url_v2'];
            //                    } else {
            //                        $url = NULL;
            //                    }
            //                    //$ids_1=$reading['exam_id_1'];
            //                    //$exam_ids_1= array_filter(explode(",", $ids_1));
            //                    //for($i=0;$i<count($exam_ids_1);$i++){
            //                    $data = array(
            //                        'mob_post_hash' => $reading['mob_post_hash'],
            //                        'title' => $reading['title'],
            //                        'content' => '',
            //                        'add_date' => $date,
            //                        'category' => $reading['category'],
            //                        'subcategory' => $reading['sub_category'],
            //                        'type' => $reading['type'],
            //                        'url' => $url,
            //                        'seq_no' => intval($reading['sequence_number']),
            //                        'status' => $reading['status'],
            //                        'is_notify' => intval($reading['is_notify']),
            //                            //'exam_id_1' => ltrim($exam_ids_1[$i],'E'),
            //                    );
            //                    //}
            //
            //                    if ($reading['category'] == '' || $reading['category'] == NULL) {
            //                        $data['category'] = '';
            //                    }
            //
            //                    if ($reading['sub_category'] == '' || $reading['sub_category'] == NULL) {
            //                        $data['subcategory'] = '';
            //                    }
            //
            //                    if ($reading['type'] == '' || $reading['type'] == NULL) {
            //                        $data['type'] = '';
            //                    }
            //
            //                    $listpost_Data_1[] = $data;
            //                }
            //            } else {
            //                $listpost_Data_1 = array();
            //            }

            //  $mobAppExamIdData = $this->db->query("SELECT mae_exam_id FROM mob_app_exam WHERE status=1 AND mae_app_id=" . $app_id . "")->result_array();
            sql = `SELECT mae_exam_id FROM mob_app_exam WHERE status=1 AND mae_app_id= ${app_id}`;
            var mobAppExamIdData = await query(sql, conn);
            var mob_app_exam_ids = '';
            mobAppExamIdData.forEach((mobAppExamId) => {
              mob_app_exam_ids += mobAppExamId.mae_exam_id + ',';
            });
            if (
              max_reading_sync_id < appUserSyncData[0].aus_mob_post_sync_id &&
              max_reading_sync_id > 0
            ) {
              appUserSyncData[0].aus_mob_post_sync_id = max_reading_sync_id;
            }

            sql = `SELECT mob_post_hash,exam_id, title, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,exam_id_1 FROM mob_post WHERE exam_id IN(${rtrim(
              mob_app_exam_ids,
              ','
            )}) AND type='article' AND mob_post_sync_id> ${
              appUserSyncData[0].aus_mob_post_sync_id
            } ORDER BY sequence_number ASC`;

            var articleReadingData = await query(sql, conn);
            if (articleReadingData) {
              articleReadingData.forEach((reading) => {
                if (reading.add_date != null && reading.add_date != '') {
                  var date = new Date(reading.add_date);
                  //   var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (reading.url_v2 != null && reading.url_v2 != '') {
                  var url = reading.url_v2;
                } else {
                  var url = null;
                }
                var ids_2 = reading.exam_id_1;
                // var exam_ids_2 = array_filter(explode(",", $ids_2));
                var exam_ids_2 = ids_2.split(',');
                for (i = 0; i < exam_ids_2.length; i++) {
                  var data = [
                    {
                      mob_post_hash: reading.mob_post_hash,
                      title: reading.title,
                      content: '',
                      add_date: date,
                      category: 'exam',
                      subcategory: ltrim(exam_ids_2[i], 'E'),
                      type: reading.type,
                      url: url,
                      seq_no: parseInt(reading.sequence_number),
                      status: reading.status,
                      is_notify: parseInt(reading.is_notify),
                      //'exam_id_1' => ltrim($exam_ids_2[$i],'E'),
                    },
                  ];
                  listpost_Data_2 = data;
                }

                if (reading.type == '' || reading.type == null) {
                  data.type = '';
                }
              });
            } else {
              listpost_Data_2 = [];
            }

            sql = `SELECT mob_post_hash,exam_id, title, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,exam_id_1 FROM mob_post WHERE exam_id IN( ${rtrim(
              mob_app_exam_ids,
              ','
            )}  ) AND type='faq' AND mob_post_sync_id> ${
              appUserSyncData[0].aus_mob_post_sync_id
            } ORDER BY sequence_number ASC`;

            var faqReadingData = await query(sql, conn);

            if (faqReadingData) {
              faqReadingData.forEach((reading) => {
                if (reading.add_date != null && reading.add_date != '') {
                  var date = Date(reading.add_date);
                  //var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (reading.url_v2 != null && reading.url_v2 != '') {
                  var url = reading.url_v2;
                } else {
                  var url = null;
                }
                var ids_3 = reading.exam_id_1;
                var exam_ids_3 = ids_3.split(',');
                for (i = 0; i < exam_ids_3.length; i++) {
                  var data = [
                    {
                      mob_post_hash: reading.mob_post_hash,
                      title: reading.title,
                      content: '',
                      add_date: date,
                      category: 'exam',
                      subcategory: ltrim(exam_ids_3[i], 'E'),
                      type: reading.type,
                      url: url,
                      seq_no: parseInt(reading.sequence_number),
                      status: reading.status,
                      is_notify: parseInt(reading.is_notify),
                      //'exam_id_1' => ltrim($exam_ids_3[$i],'E'),
                    },
                  ];
                  listpost_Data_3 = data;
                }

                if (reading.type == '' || reading.type == null) {
                  data.type = '';
                }

                //$listpost_Data_3[] = $data;
              });
            } else {
              listpost_Data_3 = [];
            }

            sql = `SELECT mob_post_hash,exam_id, title, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,exam_id_1 FROM mob_post WHERE exam_id IN(${rtrim(
              mob_app_exam_ids,
              ','
            )} ) AND type='notification' AND mob_post_sync_id>${
              appUserSyncData[0].aus_mob_post_sync_id
            } ORDER BY sequence_number ASC`;

            var notificationReadingData = await query(sql, conn);

            if (notificationReadingData) {
              notificationReadingData.forEach((reading) => {
                if (reading.add_date != null && reading.add_date != '') {
                  var date = Date(reading.add_date);
                  //var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (reading.url_v2 != null && reading.url_v2 != '') {
                  var url = reading.url_v2;
                } else {
                  var url = null;
                }
                var ids_4 = reading.exam_id_1;
                var exam_ids_4 = ids_4.split(',');
                for (i = 0; i < exam_ids_4.length; i++) {
                  var data = [
                    {
                      mob_post_hash: reading.mob_post_hash,
                      title: reading.title,
                      content: '',
                      add_date: date,
                      category: 'exam',
                      subcategory: ltrim(exam_ids_4[i], 'E'),
                      type: reading.type,
                      url: url,
                      seq_no: parseInt(reading.sequence_number),
                      status: reading.status,
                      is_notify: parseInt(reading.is_notify),
                      //'exam_id_1' => ltrim($exam_ids_4[$i],'E'),
                    },
                  ];
                  listpost_Data_4 = data;
                }

                if (reading.type == '' || reading.type == null) {
                  data.type = '';
                }

                //$listpost_Data_4[] = $data;
              });
            } else {
              listpost_Data_4 = [];
            }

            sql = `SELECT mob_post_hash,exam_id, title, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category IN('FE_USA','FE_UK','FE_CANADA','FE_OTHERS','FE_USAINFO','FE_UAE','FE_INDIA','FE_SINGAPORE','FE_HONGKONG','FE_EUROPE','FE_NEWZEALAND','FE_AUSTRALIA','FE_UNIUPDATES','FE_SCHOLARSHIP') AND mob_post_sync_id> ${appUserSyncData[0].aus_mob_post_sync_id} ORDER BY sequence_number ASC`;

            var foreignReadingData = await query(sql, conn);

            if (foreignReadingData) {
              foreignReadingData.forEach((reading) => {
                if (reading.add_date != null && reading.add_date != '') {
                  var date = new Date(reading.add_date);
                  //var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (reading.url_v2 != null && reading.url_v2 != '') {
                  var url = reading.url_v2;
                } else {
                  var url = null;
                }
                //$ids_5=$reading['exam_id_1'];
                //$exam_ids_5= array_filter(explode(",", $ids_5));
                //for($i=0;$i<count($exam_ids_5);$i++){
                var data = [
                  {
                    mob_post_hash: reading.mob_post_hash,
                    title: reading.title,
                    content: '',
                    add_date: date,
                    category: reading.category,
                    subcategory: reading.sub_category,
                    type: reading.type,
                    url: url,
                    seq_no: parseInt(reading.sequence_number),
                    status: reading.status,
                    is_notify: parseInt(reading.is_notify),
                    //'exam_id_1' => ltrim($exam_ids_5[$i],'E'),
                  },
                ];
                // }

                if (reading.type == '' || reading.type == null) {
                  data.type = '';
                }

                listpost_Data_5 = data;
              });
            } else {
              listpost_Data_5 = [];
            }

            sql = `SELECT mob_post_hash,exam_id, title, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify,exam_id_1 FROM mob_post WHERE exam_id IN( ${rtrim(
              mob_app_exam_ids,
              ','
            )} ) AND type='model_test_paper' AND mob_post_sync_id> ${
              appUserSyncData[0].aus_mob_post_sync_id
            } ORDER BY sequence_number ASC`;

            var modeltestpaperData = await query(sql, conn);

            if (modeltestpaperData) {
              modeltestpaperData.forEach((reading) => {
                if (reading.add_date != null && reading.add_date != '') {
                  var date = new Date(reading.add_date);
                  //var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (reading.url_v2 != null && reading.url_v2 != '') {
                  var url = reading.url_v2;
                } else {
                  var url = null;
                }
                var ids_6 = reading.exam_id_1;
                exam_ids_6 = ids_6.split(',');
                for (i = 0; i < exam_ids_6.length; i++) {
                  var data = [
                    {
                      mob_post_hash: reading.mob_post_hash,
                      title: reading.title,
                      content: '',
                      add_date: date,
                      category: 'exam',
                      subcategory: ltrim(exam_ids_6[i], 'E'),
                      type: reading.type,
                      url: url,
                      seq_no: parseInt(reading.sequence_number),
                      status: reading.status,
                      is_notify: parseInt(reading.is_notify),
                      //'exam_id_1' => ltrim($exam_ids_6[$i],'E'),
                    },
                  ];
                  listpost_Data_6 = data;
                }

                if (reading.type == '' || reading.type == null) {
                  data.type = '';
                }

                //$listpost_Data_6[] = $data;
              });
            } else {
              listpost_Data_6 = [];
            }

            // Commented by dev and add all category current affairs code
            /*             if($language=='hindi'){
              $currentaffairssql = "SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify
              FROM mob_post
              WHERE category IN('CA_HIN','CA_INTL_HIN') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " ORDER BY add_date DESC LIMIT 100";
              }else{
              $currentaffairssql = "SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify
              FROM mob_post
              WHERE category IN('CA_ENG','CA_INTL_ENG') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " ORDER BY add_date DESC LIMIT 100";
              } 
*/

            sql = `SELECT mob_post_hash,exam_id, title, content, add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify FROM mob_post WHERE category IN('CA_ENG','CA_HIN','CA_INTL_ENG','CA_INTL_HIN') AND mob_post_sync_id> ${appUserSyncData[0].aus_mob_post_sync_id} and (post_countries IS NULL OR post_countries='') ORDER BY add_date DESC LIMIT 100`;

            /*           if ($app_hash == '8e6cd74af474f619cbefa2da1837aa0') {
                $currentaffairssql_intl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_INTL_ENG') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and  (post_countries IS NULL OR post_countries='') ORDER BY add_date DESC LIMIT 50";
            } else if ($app_hash == '699c7c8f80a465b26209374ee7db8049' && check_country($countryId) == 1) {
                $currentaffairssql_intl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_INTL_ENG') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and  (post_countries IS NULL OR post_countries='') ORDER BY add_date DESC LIMIT 50";
            } else {
                $currentaffairssql_intl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_INTL_ENG','CA_INTL_HIN') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and  (post_countries IS NULL OR post_countries='') ORDER BY add_date DESC LIMIT 50";
            }
            $currentAffairsData_intl = $this->db->query($currentaffairssql_intl)->result_array();



            if ($app_hash == '8e6cd74af474f619cbefa2da1837aa0') {
                $currentaffairssql_ntnl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_ENG') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and post_countries in (9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,4) ORDER BY add_date DESC LIMIT 50";
                $currentAffairsData_ntnl = $this->db->query($currentaffairssql_ntnl)->result_array();
                log_message('Debug', 'Query-1: ' . $currentaffairssql_ntnl);
            } else if ($app_hash == '699c7c8f80a465b26209374ee7db8049' && check_country($countryId) == 1) {
                $currentaffairssql_ntnl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_ENG') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and post_countries in (9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,4) ORDER BY add_date DESC LIMIT 50";
                $currentAffairsData_ntnl = $this->db->query($currentaffairssql_ntnl)->result_array();
                log_message('Debug', 'Query-1: ' . $currentaffairssql_ntnl);
            }
             else {
                $currentaffairssql_ntnl = "SELECT mob_post_hash,exam_id, title, content,
                add_date,url_v2,category,sub_category,type,sequence_number,status,is_notify 
                FROM mob_post
                WHERE category IN('CA_ENG','CA_HIN') AND mob_post_sync_id>" . $appUserSyncData['aus_mob_post_sync_id'] . " and  (post_countries IS NULL OR post_countries='') ORDER BY add_date DESC LIMIT 50";
                $currentAffairsData_ntnl = $this->db->query($currentaffairssql_ntnl)->result_array();
                log_message('Debug', 'Query-2: ' . $currentaffairssql_ntnl);
            }
            $currentAffairsData = array_merge($currentAffairsData_ntnl, $currentAffairsData_intl);
*/

            var currentAffairsData = await query(sql, conn);
            var rev_arr = currentAffairsData.reverse();

            if (currentAffairsData) {
              rev_arr.forEach((currentaffairs) => {
                if (
                  currentaffairs.add_date != null &&
                  currentaffairs.add_date != ''
                ) {
                  var date = new Date(currentaffairs.add_date);
                  //var date = cd.format('Y-m-d H:i:s');
                } else {
                  var date = null;
                }
                if (
                  currentaffairs.url_v2 != null &&
                  currentaffairs.url_v2 != ''
                ) {
                  var url = currentaffairs.url_v2;
                } else {
                  var url = null;
                }
                //$ids_7=$currentaffairs['exam_id_1'];
                //$exam_ids_7= array_filter(explode(",", $ids_7));
                //for($i=0;$i<count($exam_ids_7);$i++){
                var data = [
                  {
                    mob_post_hash: currentaffairs.mob_post_hash,
                    title: currentaffairs.title,
                    content: currentaffairs.content,
                    add_date: date,
                    category: trim(currentaffairs.category),
                    subcategory: currentaffairs.sub_category,
                    type: currentaffairs.type,
                    url: url,
                    seq_no: parseInt(currentaffairs.sequence_number),
                    status: currentaffairs.status,
                    is_notify: parseInt(currentaffairs.is_notify),
                    //'exam_id_1' => ltrim($exam_ids_7[$i],'E'),
                  },
                ];
                //}

                if (currentaffairs.type == '' || currentaffairs.type == null) {
                  data.type = '';
                }

                listpost_Data_7 = data;
              });
            } else {
              listpost_Data_7 = [];
            }

            listpost_Data.reading_arr = listpost_Data_2.concat(
              listpost_Data_3,
              listpost_Data_4,
              listpost_Data_5,
              listpost_Data_6,
              listpost_Data_7
            );

            //$mobpostMaxSyncData = $this->db->query("SELECT max(mob_post_sync_id) as maxPostSyncId FROM mob_post")->row_array();
            sql = `SELECT max(mob_post_sync_id) as maxPostSyncId FROM mob_post`;
            var mobpostMaxSyncData = await query(sql, conn);
            if (app_id > 0 && user_id > 0) {
              //   $this->db->where('aus_app_id', $app_id);
              // $this->db->where('aus_user_id', $user_id);
              //$this->db->update('ots_app_user_sync', array('aus_mob_post_sync_id' => $mobpostMaxSyncData['maxPostSyncId']));

              sql = `UPDATE ots_app_user_sync SET aus_mob_post_sync_id =${mobpostMaxSyncData[0].maxPostSyncId} WHERE aus_app_id= ${app_id} AND aus_user_id= ${user_id} `;
              await query(sql, conn);
            }

            listpost_Data.max_user_reading_sync_id =
              mobpostMaxSyncData[0].maxPostSyncId;

            // $json_response = json_encode($listpost_Data);
            //echo $json_response;
            res.json(listpost_Data);
          } else {
            listpost_Data.flag = 5;
            //json_response = json_encode($listpost_Data);
            //echo $json_response;

            res.json(listpost_Data);
          }
        }
        pool2.releaseConnection(conn2);
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
