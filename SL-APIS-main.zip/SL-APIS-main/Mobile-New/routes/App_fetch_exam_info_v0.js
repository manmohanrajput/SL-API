const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_fetch_exam_info_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{

            const user_id = req.body.user_id;
            const user_hash = req.body.user_hash;
            const app_hash = req.body.app_hash; // replaced app_id with app_hash
            var sql = 'select count(*)as user_count from user_detail where user_id=' + user_id + ' and user_hash=\'' + user_hash + '\'';
            const user_Data = (await query(sql, conn))[0];
            if(user_Data.user_count > 0){
                const appData = (await query('SELECT * from mob_app_detail where app_hash=\'' + app_hash + '\'', conn))[0];

                var instData;
                if(appData){
                    instData = 
                        {
                            flag : 1,
                            about_exam : appData.about_exam
                        }
                    
                } else {
                    instData = {
                        flag: 0
                    }
                }
                res.json(instData);
            } else {
                instData = {
                    flag: 5
                }
                res.json(instData);
            }

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;