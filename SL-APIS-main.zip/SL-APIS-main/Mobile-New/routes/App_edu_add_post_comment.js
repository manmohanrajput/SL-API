const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');
const fs = require('fs');
const aws = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3');
var randomstring = require('randomstring');

function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function time() {
  var timestamp = Math.floor(new Date().getTime() / 1000);
  return timestamp;
}

function uniqid() {
  const sec = Date.now() * 1000 + Math.random() * 1000;
  const id = sec.toString(16).replace(/\./g, '').padEnd(14, '0');
  const res = `${id} ${true ? Math.trunc(Math.random() * 100000000) : ''}`;
  return res;
}

router.post('/App_edu_add_post_comment', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          data.app_id = req.body.app_id;
          data.user_first_name = req.body.user_first_name;
          data.user_last_name = req.body.user_last_name;
          data.user_image_url = req.body.user_image_url;
          data.user_type = req.body.user_type;
          data.post_id = req.body.post_id;
          data.comment = req.body.comment;
          data.comment_image = req.body.comment_image;
          var addComment = {};
          //$user_Data = $this->db->query("select count(*)as user_count from user_detail where user_id=" . $data['user_id'] . " and user_hash='" . $data['user_hash'] . "'")->row_array();
          var sql = `select count(*)as user_count from user_detail where user_id= ${data.user_id} and user_hash= "${data.user_hash}" `;
          var user_Data = await query(sql, conn);
          if (user_Data[0].user_count > 0) {
            if (
              data.user_type.indexOf('Student') !== null ||
              data.user_type.indexOf('Student') !== -1
            ) {
              var user_type = 'Student';
            } else if (
              data.user_type.indexOf('Parent') !== null ||
              data.user_type.indexOf('Parent') !== -1
            ) {
              var user_type = 'Parent';
            } else if (
              data.user_type.indexOf('Teacher') !== null ||
              data.user_type.indexOf('Teacher') !== -1
            ) {
              var user_type = 'Teacher';
            } else {
              var user_type = 'Student';
            }

            if (data.comment_image != null && data.comment_image != '') {
              var UPLOAD_DIR = '../temp';

              var dataImage = Buffer.from(data.comment_image).toString(
                'base64'
              );
              var file = UPLOAD_DIR + uniqid() + '.jpg';
              console.log('debug', 'file' + file);
              var success = fs.writeFile(file, dataImage, function (err) {
                if (err) throw err;
                console.log('Its saved!');
              });

              var imgName = time() + '.jpg';
              //$tmpName = $basePath.$file;
              var tmpName = file;

              aws.config.update({
                secretAccessKey: process.env.AWS_ID,
                accessKeyId: process.env.AWS_SECRET,
                region: 'ap-south-1',
              });
              const s3 = new aws.S3();
              //storing data on aws-s3
              var upload = multer({
                storage: multerS3({
                  s3: s3,
                  bucket: 'speedlabs',
                  acl: 'public-read',
                  metadata: function (req, file, cb) {
                    cb(null, {
                      fieldName: file.fieldname,
                    });
                  },
                  key: function (req, file, cb) {
                    cb(null, 'pixels/' + Date.now().toString());
                  },
                }),
              });
              var metaHeaders = [];
              var c_image_rand = randomstring.generate({
                length: 12,
                charset: 'numeric',
              });
              var post_image_name =
                'edu_comment_image_' + c_image_rand + '_' + time() + '.jpg';
              upload.array(tmpName, post_image_name, metaHeaders);

              data.comment_image_url = post_image_name;
            } else {
              data.comment_image_url = '';
            }
            var commentData = {
              post_id: data.post_id,
              post_type: 'post',
              user_id: data.user_id,
              user_first_name: data.user_first_name,
              user_last_name: data.user_last_name,
              user_image_url: data.user_image_url,
              type: user_type,
              comment: data.comment,
              comment_image_url: data.comment_image_url,
              add_date:
                new Date().getFullYear() +
                '-' +
                new Date().getMonth() +
                '-' +
                new Date().getDate(),
              update_date:
                new Date().getFullYear() +
                '-' +
                new Date().getMonth() +
                '-' +
                new Date().getDate(),
            };

            // $db2->insert('edu_post_comment', $commentData);
            sql = `INSERT INTO edu_post_comment (post_id,post_type, user_id,user_first_name,user_last_name,user_image_url,type,comment,comment_image_url,add_date,update_date)VALUES(${commentData.post_id},'${commentData.post_type}',${commentData.user_id},'${commentData.user_first_name}','${commentData.user_last_name}',"${commentData.user_image_url}",'${commentData.type}',"${commentData.comment}","${commentData.comment_image_url}",${commentData.add_date},${commentData.update_date})`;
            var insert_id = await query(sql, conn2);

            //  $postRow = $db2->get_where('edu_post', array('id' => $data['post_id']))->row_array();
            sql = `SELECT * FROM edu_post WHERE id = ${data.post_id}`;
            var postRow = await query(sql, conn2);

            //$latestCommentRow = $this->db->query("SELECT count(id) as commCount FROM edu_post_comment WHERE post_id=".$data['post_id']." AND (spam_count IS NULL OR spam_count<4) AND edu_post_comment.delete_flag IS NULL")->row_array();
            //$latestCommentRow = $db2->query("SELECT *FROM edu_post_comment WHERE post_id =" . $data['post_id'] . "AND (spam_count IS NULL OR spam_count <4)AND edu_post_comment.delete_flag IS NULL ORDER BY add_date DESC")->row_array();
            sql = `SELECT *FROM edu_post_comment WHERE post_id =${data.post_id} AND (spam_count IS NULL OR spam_count < 4)AND edu_post_comment.delete_flag IS NULL ORDER BY add_date DESC`;
            var latestCommentRow = await query(sql, conn2);

            if (
              data.post_id != 0 &&
              data.post_id != null &&
              data.post_id != ''
            ) {
              //  $maxPostSyncData = $db2->query(SELECT max(post_sync_id) as max_post_sync_id FROM edu_post")->row_array();
              sql = `SELECT max(post_sync_id) as max_post_sync_id FROM edu_post`;
              var maxPostSyncData = await query(sql, conn2);
              var new_post_sync_id = maxPostSyncData[0].max_post_sync_id + 1;

              //  $db2->where('id', $data['post_id']);
              // $db2->update('edu_post', array('comment_count' => $postRow['comment_count'] + 1, 'post_sync_id' => $new_post_sync_id));
              sql = `UPDATE edu_post SET comment_count=${
                postRow[0].comment_count + 1
              },post_sync_id=${new_post_sync_id} WHERE id = ${data.post_id}`;
              await query(sql, conn2);
            }

            //$push_comment_data = $db2->query("SELECT distinct user_id FROM edu_post_comment WHERE post_id=" . $data['post_id'] . " AND user_id!=" . $data['user_id'] . " ORDER BY add_date DESC LIMIT 5")->result_array();
            sql = `SELECT distinct user_id FROM edu_post_comment WHERE post_id= ${data.post_id} AND user_id!= ${data.user_id} ORDER BY add_date DESC LIMIT 5`;
            var push_comment_data = await query(sql, conn2);
            if (push_comment_data) {
              var pushcontent = [
                {
                  en: '' + commentData.comment.substr(0, 100) + '',
                },
              ];

              var pushtitle = [
                {
                  en:
                    '' +
                    capitalizeFirstLetter(data.user_first_name.toLowerCase()) +
                    '',
                },
              ];

              push_comment_data.forEach((post_comment_users) => {
                tags = [
                  {
                    key: 'user_id',
                    relation: '=',
                    value: '' + post_comment_users.user_id + '',
                  },
                ];
                tags = [{ operator: 'OR' }];
              });

              var rand_num = getRndInteger(1, 5);

              if (postRow[0].user_id != data.user_id && rand_num == 3) {
                tags = [
                  {
                    key: 'user_id',
                    relation: '=',
                    value: '' + postRow[0].user_id + '',
                  },
                ];
              } else {
                tags.pop();
              }
            }

            if (insert_id != 0 && insert_id != null) {
              addComment.flag = 1;
              addComment.comment_id = insert_id.insertId;
              if (data.comment_image_url != '') {
                //$commentImageURl = S3POSTURL . $data['comment_image_url'];
                commentImageURl = data.comment_image_url;
              } else {
                commentImageURl = '';
              }
              addComment.comment_image_url = commentImageURl;
            } else {
              addComment.flag = 0;
              addComment.comment_id = 0;
              addComment.comment_image_url = '';
            }
            res.send(addComment);
          } else {
            addComment.flag = 5;
            addComment.comment_id = 0;
            addComment.comment_image_url = '';
            res.send(addComment);
          }

          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
