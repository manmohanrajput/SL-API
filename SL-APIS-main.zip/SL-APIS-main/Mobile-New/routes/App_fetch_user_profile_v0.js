const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_inst_post_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            
            const user_id = req.body.user_id;
            const user_hash = req.body.user_hash;

            var sql = 'select count(*)as user_count from user_detail where user_id=' + data.user_id + ' and user_hash=\'' + data.user_hash + '\'';
            const user_Data = (await query(sql, conn))[0];

            if(user_Data.user_count > 0){
                sql = 'SELECT user_detail.*,city_master.city_name,state.state_name FROM user_detail LEFT JOIN city_master ON user_detail.user_city_id=city_master.city_id LEFT JOIN state ON user_detail.user_state_id=state.state_id WHERE user_detail.user_id=' + user_id;
                const userRow = (await query(sql, conn))[0];
                if(userRow){
                    var userData = [{
                        fname : userRow.user_first_name,
                        lname : userRow.user_last_name,
                        email : userRow.user_email,
                        password : userRow.user_password,
                        qualification : userRow.user_qual,
                        user_type : userRow.user_type,
                        contact : userRow.user_contact_no,
                        city : userRow.user_city_name,
                        state : userRow.user_state_name,
                        org_name : userRow.org_name,
                        job_title : userRow.job_title,
                        subject : userRow.subject,
                    }];

                    if (userRow.job_title !== '' && userRow.job_title !== NULL) {
                        userData.job_title = userRow.job_title;
                    } else if (userRow.user_type.indexOf('Student') !== -1) {
                        userData.job_title = 'Student';
                    } else if (userRow.user_type.indexOf('Parent') !== -1) {
                        userData.job_title = 'Parent';
                    } else if (userRow.user_type.indexOf('Teacher') !== -1) {
                        userData.job_title = 'Teacher';
                    } else {
                        userData.job_title = '';
                    }

                    if(userRow.user_photo.indexOf('https') !== -1){
                        userData.user_image = userRow.user_photo;
                    } else if(userRow.user_photo === ''){
                        userData.user_image = '';
                    }else{
                      userData.user_image = S3URL1 + 'mcluserimage/' + userRow.user_photo + '';  
                    }

                    userData.flag = 1;
                } else {
                    userData.flag = 0;
                }
                res.json(userData);
            } else {
                userData.flag = 5;
                res.json(userData);
            }

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;