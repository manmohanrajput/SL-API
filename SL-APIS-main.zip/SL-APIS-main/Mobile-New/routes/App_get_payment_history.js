const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_get_payment_histroy', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      var data = {};
      data.app_hash = req.body.app_hash;
      data.user_id = req.body.user_id;
      data.user_hash = req.body.user_hash;
      data.app_id = req.body.app_id;
      var data1 = {};
      var sql =
        `select count(*)as user_count from user_detail where user_id="` +
        data.user_id +
        `" and user_hash="` +
        data.user_hash +
        `"`;

      const user_Data = await query(sql, conn);

      if (user_Data[0].user_count > 0) {
        var user_pay_info;
        sql =
          `select payment_id,amount,created_on from mob_app_payment_info where user_hash="` +
          data.user_hash +
          `" AND user_id ="` +
          data.user_id +
          `" ORDER BY id DESC LIMIT 5`;

        user_pay_info = await query(sql, conn);

        data1.response = user_pay_info;
        data1.status = 'success';
        data1.msg = 'Payment History';
        data1.flag = 1;
      } else {
        data1.status = 'failed';
        data1.msg = 'No Record Found';
        data1.flag = 0;
      }
      res.json(data1);
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
