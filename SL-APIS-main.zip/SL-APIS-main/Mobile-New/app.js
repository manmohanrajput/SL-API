const express = require('express');
const cors = require('cors');

require('dotenv').config();

const PORT = process.env.PORT || 5000;

const app = express();

app.use(cors());

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

//home route
app.get('/', (req, res) => {
  res.send('API Running');
});

//get_flt_section_list route
app.use(require('./routes/get_flt_section_list'));

//get_flt_question_list route
app.use(require('./routes/get_flt_question_list'));

//App_mobile_login_v0
app.use(require('./routes/App_mob_login'));

//App_fetch_hash_v0
app.use(require('./routes/App_fetch_hash_v0'));

//App_fetch_group_list_v0
app.use(require('./routes/App_fetch_group_list_v0'));

//App_fetch_community_about_v0
app.use(require('./routes/App_edu_community_about_v0'));

//App_fetch_inst_post_v0
app.use(require('./routes/App_fetch_ins_post_v0'));

//App_all_list_data_v0
app.use(require('./routes/App_all_list_data_v0'));

//App_fetch_inst_details_v0
app.use(require('./routes/App_fetch_inst_details_v0'));

//App_fetch_exam_info_v0
app.use(require('./routes/App_fetch_exam_info_v0'));

//App_fetch_user_profile_v0
app.use(require('./routes/App_fetch_user_profile_v0'));

//App_fetch_exp_answers_v0
app.use(require('./routes/App_fetch_exp_answers_v0'));

//App_fetch_batch_name_v0
app.use(require('./routes/App_fetch_batch_name_v0'));

//App_delete_comment_v0
app.use(require('./routes/App_edu_delete_comment_v0'));

//App_edu_post_upvote_v0
app.use(require('./routes/App_edu_post_upvote_v0'));

//App_edu_delete_post_v0
app.use(require('./routes/App_edu_delete_post_v0'));

//App_edu_ques_action_v0
app.use(require('./routes/App_edu_ques_action_v0'));

//All_list_data
app.use(require('./routes/All_list_data'));

//App_edu_mark_spam_v0
app.use(require('./routes/App_edu_mark_spam_v0'));

//App_mobile_login_v0
app.use(require('./routes/App_mob_login_v0'));

//App_reset_user_sync_v0
app.use(require('./routes/App_reset_user_sync_v0'));

//App_list_data_v0
app.use(require('./routes/App_list_data_v0'));

//my
app.use(require('./routes/my'));

///App_get_payment_histroy
app.use(require('./routes/App_get_payment_history'));

//App_fetch_version_code_v0
app.use(require('./routes/App_fetch_version_code_v0'));

//App_fetch_version_code_v0
app.use(require('./routes/App_view_user_profile_v0'));

//App_fetch_edu_comments_v0
app.use(require('./routes/App_fetch_edu_comments_v0'));

//App_fetch_edu_comments_v0
app.use(require('./routes/App_success_payment_info'));

//Get_app_config_v0
app.use(require('./routes/Get_app_config_v0'));

//App_fetch_data_hash_v0
app.use(require('./routes/App_fetch_data_hash_v0'));

//App_fetch_current_affairs
app.use(require('./routes/app_fetch_current_affairs'));

//App_verify_reg_pin
app.use(require('./routes/App_verify_reg_pin'));

//App_get_payment_detail
app.use(require('./routes/App_get_payment_detail'));

//App_fetch_post_list_v1
app.use(require('./routes/App_fetch_post_list_v1'));

//App_fetch_test_list_v0
app.use(require('./routes/App_fetch_test_list_v0'));

//App_fetch_reading_v1
app.use(require('./routes/App_fetch_reading_v1'));

//App_fetch_reading_v1
//app.use(require('./routes/Fetch_flt_result'));

//App_check_version_v0
app.use(require('./routes/App_check_version_v0'));

// App_check_email_v0
app.use(require('./routes/App_check_email_v0'));

// App_result_submit_vo
app.use(require('./routes/App_result_submit_v0'));

//get_flt_list_v1
app.use(require('./routes/get_flt_list_v1'));

//App_student_config_v0
app.use(require('./routes/App_student_config_v0'));

//App_edu_add_post_comment
app.use(require('./routes/App_edu_add_post_comment'));

//App_register_user_v0
app.use(require('./routes/App_register_user_v0'));

//App_fetch_sz_data_v1
app.use(require('./routes/App_fetch_sz_data_v1'));

app.listen(PORT, () => {
  console.log(`Server is Running on port ${PORT}`);
});
