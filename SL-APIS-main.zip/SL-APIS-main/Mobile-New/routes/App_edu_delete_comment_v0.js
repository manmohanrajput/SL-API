const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_delete_comment_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const comment_id = req.body.comment_id;
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          /* $comment_id = 2;
                          $user_id = 76; */

          console.log(user_id);
          console.log(req.body);

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `" and user_hash="` +
            user_hash +
            `"`;

          var user_Data = await query(sql, conn);
          console.log(user_Data);
          console.log(sql);
          var commentData = {};

          if (user_Data[0].user_count > 0) {
            if (
              comment_id != '' &&
              comment_id != null &&
              comment_id != 0 &&
              comment_id != 'null'
            ) {
              // $db2->where('id', $comment_id);
              sql =
                `UPDATE edu_post_comment SET delete_flag = 1 WHERE id ="` +
                comment_id +
                `"`;
              await query(sql, conn2);

              //$db2->update('edu_post_comment', array('delete_flag' => 1));

              sql =
                `UPDATE edu_post SET comment_count = comment_count-1 WHERE id="` +
                commentData.post_id +
                `"`;
              comment_data = await query(sql, conn2);
              console.log(commentData);

              if (comment_data.post_id > 0) {
                sql =
                  `UPDATE edu_post SET comment_count = comment_count-1 WHERE id="` +
                  commentData.post_id +
                  `"`;
                await query(sql, conn2);
              }

              commentData.flag = 1;
            } else {
              commentData.flag = 0;
            }
            res.send(commentData);
          } else {
            commentData.flag = 5;

            res.send(commentData);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
