const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_list_data_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      const data = {};
      const user_id = req.body.user_id;
      const user_hash = req.body.user_hash;
      const categoy = req.body.categoy;
      const subcategoy = req.body.subcategoy;
      const type = req.body.type;
      const seendate = req.body.seendate;
      const rgcmid = req.body.rgcmid;
      const startlimt = req.body.startlimt;

      var sql =
        'select count(*)as user_count from user_detail where user_id=' +
        user_id +
        " and user_hash='" +
        user_hash +
        "'";
      const user_Data = (await query(sql, conn))[0];
      if (user_Data[0].user_count > 0) {
        if (seendate == '' || sendate == 0 || seendate == NULL) {
          date = '2001-01-01';
        } else {
          date = seendate;
        }

        console.log('debug', 'calling data_model get_list_post function');
        //$data['listpostData'] = $this->data_model_v1->get_list_post($data['category'],$data['subcategory'],$data['type'],$data['date'],$data['startlimit']);
        subcat = '';
        _type = '';
        if (subcategory == '' && subcategory == NULL && subcategory == 0) {
          subcat = '';
        } else if (subcategory == 'PO' || subcategory == 'CLERK') {
          subcat =
            "AND (sub_category='" + subcategory + "' OR sub_category='ALL')";
        } else {
          subcat = "AND sub_category='" + subcategory + "'";
        }

        if (type == NULL && type == '') {
          c_type = '';
        } else {
          c_type = "AND type='" + type + "'";
        }

        if (startlimit != '' && startlimit != NULL) {
          limitstring = 'LIMIT ' + startlimit + ',50';
        } else {
          limitstring = '';
        }
        if (
          category == 'CA_HIN' ||
          category == 'CA_ENG' ||
          category == 'GK_HIN' ||
          category == 'GK_ENG'
        ) {
          orderby = 'ORDER BY add_date DESC';
        } else {
          orderby = 'ORDER BY sequence_number ASC ';
        }
        console.log('debug', 'in get_list_post function');
        var sql =
          "SELECT id, title, content, image, add_date,url,category,sub_category,type,mob_post_hash FROM mob_post WHERE (category='" +
          category +
          "' " +
          subcat +
          ' ' +
          c_type +
          ") AND status = 'active'" +
          orderby +
          ' ' +
          limitstring +
          '';
        listpostData = await query(sql, conn);

        if (data.listpostData) {
          listpostData.forEach((listpost) => {
            if (listpost.add_date != null && listpost.add_date != '') {
              cd = new Datetime(listpost.add_date);
              date = cd.format('d-m-Y');
            } else {
              date = null;
            }
            if (listpost.url != null && listpost.url != '') {
              url = listpost.url;
            } else {
              url = null;
            }
            data = [
              {
                id: listpost.id,
                mob_post_hash: listpost.mob_post_hash,
                title: listpost.title,
                add_date: date,
                url: url,
              },
            ];

            listpost_Data.flag = 1;
            listpost_Data.authFlag = 1;
            listpost_Data.listpostData = data;
          });

          json.response(listpostData);
        } else {
          listpost_Data.flag = 0;
          listpost_Data.authFlag = 1;
          listpost_Data.listpostData = [];
          json.response(listpostData);
        }
      } else {
        listpost_Data.flag = 5;
        listpost_Data.authFlag = 1;
        listpost_Data.listpostData = [];
        json_response = json_encode(listpost_Data);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
