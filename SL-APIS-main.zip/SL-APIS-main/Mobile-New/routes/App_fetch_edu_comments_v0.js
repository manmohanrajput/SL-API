const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_edu_comments_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const data = {};
          data.post_id = req.body.post_id;
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;

          data.app_id = req.body.app_id;
          data.comment_limit = req.body.comment_limit;

          /* $data['post_id'] = 5;
          $data['user_id'] = 76;
          $data['app_id'] = 100009;
          $data['comment_limit'] = 0; */

          var sql = `select count(*)as user_count from user_detail where user_id=${data.user_id}`;
          const user_Data = await query(sql, conn);
          if (user_Data[0].user_count > 0) {
            // db2 = $this->load->database('discussiondb', TRUE);
            if (
              data.post_id != '' &&
              data.post_id != null &&
              data.post_id != 0
            ) {
              var sql1 = `SELECT * FROM edu_post_comment WHERE edu_post_comment.post_id=${data.post_id} AND (spam_count IS NULL OR spam_count<2) AND edu_post_comment.delete_flag IS NULL ORDER BY sticky DESC,add_date ASC LIMIT 200`;

              var commentData = await query(sql1, conn2);
            } else {
              var commentData = [];
            }
            var post_data = [];

            if (commentData) {
              await Promise.all(
                commentData.map(async (comment) => {
                  if (comment.comment_image_url != '') {
                    commentImageURl = comment.comment_image_url;
                  } else {
                    commentImageURl = '';
                  }
                  var commentArr = {
                    comment_id: comment.id,
                    user_id: comment.user_id,
                    comment: comment.comment,
                    comment_image_url: commentImageURl,
                    fname:
                      comment.user_first_name.charAt(0).toUpperCase() +
                      comment.user_first_name.slice(1),
                    lname:
                      comment.user_last_name.charAt(0).toUpperCase() +
                      comment.user_first_name.slice(1),
                    spam_count: comment.spam_count,
                    //'date' => date('d F',strtotime($comment['add_date'])),
                    date: comment.add_date,
                    server_date: Date('Y-m-d H:i:s'),
                    //'date' => '',
                  };

                  //     $commentVoteRow = $db2->get_where('edu_user_post', array('comment_id' => $comment['id'], 'user_id' => $data['user_id'], 'mark_upvote' => 1))->row_array();

                  var sql2 = `SELECT * FROM edu_user_post WHERE comment_id = ${comment.id} AND user_id = ${data.user_id} AND mark_upvote=1`; // user_id = ${data.user_id},mark_upvote=1
                  var commentVoteRow = await query(sql2, conn2);
                  if (commentVoteRow) {
                    commentArr.commentUpvoteFlag = 1;
                  } else {
                    commentArr.commentUpvoteFlag = 0;
                  }

                  sql = `SELECT count(*) as commentUpvoteCount FROM edu_user_post WHERE comment_id=${comment.id} AND mark_upvote = 1 `; //mark_upvote=1
                  var commentUpvoteRow = await query(sql, conn2);
                  var i = commentUpvoteRow[0].commentUpvoteCount;
                  commentArr.comment_upvote_count = i;

                  commentArr.user_image = comment.user_image_url;

                  post_data.push(commentArr);
                })
              );
            } else {
              var post_data = [];
              post_data.flag = 0;
            }

            if (data.post_id > 0) {
              sql = `UPDATE edu_post SET view_count=IFNULL(view_count,0)+1 WHERE id=${data.post_id}`;
              await query(sql, conn2);
            }

            res.send(post_data);
          } else {
            post_data = [];
            post_data.flag = 5;

            res.send(post_data);
          }
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
