const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const pool4 = require('../config/db4');
const query = require('../utils/query');

router.post('/App_reset_user_sync_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          pool4.getConnection(async (err, conn4) => {
            if (err) {
              console.log(err);
              return res.status(500).send('Server Error');
            } else {
              const user_id = req.body.user_id;
              const user_hash = req.body.user_hash;
              const app_id = req.body.app_id;
              var reset_sync_data = {};
              var sql = `select count(*)as user_count from user_detail where user_id = ${user_id}`;

              user_Data = await query(sql, conn);

              if (user_Data[0].user_count > 0) {
                if (user_id > 0 && app_id > 0) {
                  sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0, aus_mob_post_sync_id =0 WHERE aus_user_id =${user_id} AND aus_app_id =${app_id}`;
                  await query(sql, conn);
                  sql = `UPDATE app_user_sync SET aus_career_exchange_sync_id = 0 WHERE aus_user_id=${user_id} AND aus_app_id =${app_id}`;
                  await query(sql, conn4);
                  sql = `UPDATE app_user_sync SET daus_post_sync_id = 0 WHERE daus_user_id=${user_id} AND daus_app_id =${app_id}`;
                  await query(sql, conn2);

                  reset_sync_data.flag = 1;
                } else {
                  reset_sync_data.flag = 0;
                }
                res.send(reset_sync_data);
              } else {
                categoryData.flag = 5;
                res.send(reset_sync_data);
              }
              pool4.releaseConnection(conn4);
            }
          });
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
