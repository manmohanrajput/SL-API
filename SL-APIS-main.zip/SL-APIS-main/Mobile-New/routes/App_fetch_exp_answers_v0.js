const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_exp_answers_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            
            const user_id = req.body.user_id;  //change in mobile number in v3 hard coded
            const user_hash = req.body.user_hash;
            const app_hash = req.body.app_hash;
            const test_code = req.body.test_code;
            const school_code = req.body.school_code;

            var sql = 'select count(*)as user_count from user_detail where user_id=' + user_id + ' and user_hash=\'' + user_hash + '\'';
            const user_Data = (await query(sql, conn))[0];

            if(user_Data.user_count > 0){
                var sql = 'SELECT * FROM mob_post WHERE mob_post_hash LIKE \'' + test_code + '%\' ORDER BY id DESC LIMIT 1';
                const mobPostData = (await query(sql, conn))[0];
                var mobPost = {};
                if(mobPostData){
                    mobPost.flag = 1;
                    mobPost.test_explanation = mobPostData.content;
                } else {
                    mobPost.flag = 0;
                    mobPost.test_explanation = '';
                }

                res.json(mobPost);
            } else {
                mobPost.flag = 5;
                mobPost.test_explanation = '';
                res.json(mobPost);
            }

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;