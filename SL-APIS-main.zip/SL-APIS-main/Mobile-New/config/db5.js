const mysql = require('mysql');
const config = require('./default.json');
const pool = mysql.createPool({
    host: config.HOST5,
    user: config.user5,
    password: config.password5,
    database: config.database5,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

module.exports = pool;