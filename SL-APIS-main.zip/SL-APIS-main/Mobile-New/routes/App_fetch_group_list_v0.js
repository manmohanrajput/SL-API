const express = require('express');
const query = require('../utils/query');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');

router.post('/App_fetch_group_list_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const app_id = req.body.app_id;
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const pref_community_ids = req.body.pref_community_ids;

          var sql = `select count(*)as user_count from user_detail where user_id=${user_id} `;
          const user_Data = (await query(sql, conn))[0];
          if (user_Data.user_count > 0) {
            const pref_community_ids_arr = pref_community_ids
              .trimEnd()
              .split(',');
            sql = `SELECT edu_app_group.*,edu_groups.tag,edu_groups.count_follower,edu_groups.count_post,edu_groups.about,edu_groups.hash_tag FROM edu_app_group LEFT JOIN edu_groups ON edu_app_group.eag_community_id=edu_groups.id WHERE edu_app_group.eag_app_id= ${app_id}`;
            const appGroupData = await query(sql, conn2);
            console.log(sql);
            const app_group_arr = [];
            if (appGroupData) {
              var i = 0;
              appGroupData.forEach((appGroup) => {
                app_group_arr.push({
                  community_id: appGroup.eag_community_id,
                  tag: appGroup.tag,
                  count_follower: parseInt(appGroup.count_follower),
                  count_post: parseInt(appGroup.count_post),
                  about: appGroup.about,
                  group_hash_tag: appGroup.hash_tag,
                });

                if (pref_community_ids == '') {
                  app_group_arr[i].checked_status = 1;
                } else if (
                  pref_community_ids_arr.includes(appGroup.eag_community_id)
                ) {
                  app_group_arr[i].checked_status = 0;
                } else {
                  app_group_arr[i].checked_status = 1;
                }
                i = i++;
              });
            } else {
              app_group_arr = [];
            }
            const listGroup = app_group_arr;
            res.json(listGroup);
          } else {
            const listGroup = {};
            listGroup.flag = 5;
            res.json(listGroup);
          }
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
