const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
​
var reslist={};
router.post('/Fetch_flt_result', async (req, res) => {
  res.send("api running")
});
​
module.exports = router;
