const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');
var randomstring = require('randomstring');
var md5 = require('md5');
const mandrill = require('mandrill-api');
const mandrill_client = new mandrill.Mandrill('bAV03zWPNHiodhkVXNkhLQ');
const date1 = require('date-and-time');
const smsGateway = require('sms-gateway-nodejs')(
  'ntrinquier@provider.com',
  'p4ssw0rd'
);

function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function time() {
  var timestamp = Math.floor(new Date().getTime() / 1000);
  return timestamp;
}

router.post('/App_register_user_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          var insertData = {};

          data.mobNo = req.body.mobNo;
          data.uEmail = req.body.uEmail;
          data.uFname = req.body.uFname;
          data.uLname = req.body.uLname;
          data.uEduQual = req.body.uEduQual;
          data.stream = req.body.stream;
          data.uType = req.body.uType;
          data.uCity = req.body.uCity;
          data.uState = req.body.uState;
          data.uCountry = req.body.uCountry;
          data.source = req.body.source;
          data.gcm_id = req.body.gcm_id;
          data.version_code = req.body.version_code;
          data.app_id = req.body.app_id;
          data.image = req.body.uImage;

          var hash = md5(getRndInteger(0, 1000));
          var password = randomstring.generate({
            length: 6,
            charset: 'numeric',
          });
          var rand = time();
          var rand1 = randomstring.generate({
            length: 4,
            charset: 'numeric',
          });
          var status = await insert_user_detail(
            data.mobNo,
            data.uEmail,
            password,
            data.uFname,
            data.uLname,
            data.uEduQual,
            data.stream,
            data.uType,
            data.uCity,
            data.uState,
            data.uCountry,
            data.image,
            hash,
            data.source,
            data.gcm_id,
            data.version_code,
            data.app_id
          );

          if (status.status1 == 1) {
            success_mail(
              data.uEmail,
              data.uFname,
              data.uLname,
              hash,
              password,
              data.app_id,
              data.source
            );
          } else {
          }
          if (status.status1 == 1) {
            insertData.user_email = status.user_email;
            insertData.user_address = status.user_address;
            insertData.zip_code = status.zip_code;
            insertData.org_name = '';
            insertData.job_title = '';
            insertData.role = status.role;
            insertData.user_location = '';
            insertData.prev_exam_percentage = '';
            insertData.user_first_name = status.user_first_name;
            insertData.user_last_name = status.user_last_name;
            insertData.user_contact_no = status.user_contact_no;
            insertData.user_qual = status.user_qual;
            insertData.stream = status.stream;
            insertData.user_city_name = status.city_name;
            insertData.user_state_name = status.state_name;
            insertData.user_country_name = status.country_name;
            insertData.insert_status = 1;
            insertData.user_id = status.user_id;
            insertData.user_hash = status.user_hash;
            //$insertData['user_image_path']      = $status['user_image_path'];
            var i = String(status.user_image_path);
            if (i.indexOf('https') !== 0 && i.indexOf('https') !== null)
              //$userData['user_image'] = $userRow['user_image_url'];
              insertData.user_image_path = status.user_image_path;
            else if (status.user_image_path == '') {
              insertData.user_image_path = '';
            } else {
              insertData.user_image_path =
                S3URL1 + 'mcluserimage/' + status.user_image_path + '';
            }

            var percentage = 100;

            if (
              insertData.user_first_name == '' &&
              insertData.user_first_name == null
            ) {
              percentage = percentage - 20;
            }
            if (
              insertData.user_contact_no == '' ||
              insertData.user_contact_no == null ||
              insertData.user_contact_no == 1111111111 ||
              insertData.user_contact_no == '1111111111'
            ) {
              percentage = percentage - 30;
            }
            if (insertData.user_qual == '' && insertData.user_qual == null) {
              percentage = percentage - 20;
            }
            if (insertData.role == '' || insertData.role == null) {
              percentage = percentage - 30;
            }
            insertData.percentage = percentage;

            //$json_response =  json_encode($insertData);
            //echo $json_response;
            res.send(insertData);
          } else {
            if (status.is_update) {
              if (
                status.user_contact_no == 1111111111 ||
                status.user_contact_no == '1111111111'
              ) {
                userData.user_contact_no = '';
              }

              insertData.user_email = status.user_email;
              insertData.user_address = status.user_address;
              insertData.zip_code = status.zip_code;
              insertData.org_name = status.org_name;
              insertData.job_title = status.job_title;
              insertData.role = status.role;
              insertData.user_location = status.user_location;
              insertData.prev_exam_percentage = status.prev_exam_percentage;
              insertData.user_first_name = status.user_first_name;
              insertData.user_last_name = status.user_last_name;
              insertData.user_contact_no = status.user_contact_no;
              insertData.user_qual = status.user_qual;
              insertData.stream = status.stream;
              insertData.user_city_name = status.city_name;
              insertData.user_state_name = status.state_name;
              insertData.user_country_name = status.country_name;
              insertData.insert_status = 0;
              insertData.user_id = status.user_id;
              insertData.user_hash = status.user_hash;
              //$insertData['user_image_path']          = $status['user_image_path'];
              var image_path = String(status.user_image_path);
              if (
                image_path.indexOf('https') !== null &&
                image_path.indexOf('https') !== -1
              )
                //$userData['user_image'] = $userRow['user_image_url'];
                insertData.user_image_path = status.user_image_path;
              else if (
                status.user_image_path == '' ||
                status.user_image_path == undefined
              ) {
                insertData.user_image_path = '';
              } else {
                insertData.user_image_path =
                  S3URL1 + 'mcluserimage/' + status.user_image_path + '';
              }
              var percentage = 100;

              if (
                insertData.user_contact_no == '' ||
                insertData.user_contact_no == null ||
                insertData.user_contact_no == 1111111111 ||
                insertData.user_contact_no == '1111111111'
              ) {
                percentage = percentage - 30;
              }
              if (insertData.user_qual == '' && insertData.user_qual == null) {
                percentage = percentage - 20;
              }

              if (insertData.role == '' && insertData.role == null) {
                percentage = percentage - 50;
              }

              insertData.percentage = percentage;

              //$json_response =  json_encode($insertData);
              //echo $json_response;
              res.send(insertData);
            } else {
              //  log_message('debug','else case of is_update  then app id='.$data['app_id'] );
              //  log_message('debug','else case of is_update then email='.$data['uEmail']);
              insertData.insert_status = 2;
              insertData.message =
                'You are not authorised to access this App. Please contact your coaching/school administrator.';
              //    $json_response =  json_encode($insertData,JSON_UNESCAPED_SLASHES);
              //  echo $json_response;
              res.send(insertData);
            }
          }

          async function success_mail(
            emailTo = '',
            fname = '',
            lname = '',
            recievedHash = '',
            password = '',
            app_id,
            source = ''
          ) {
            {
              //var appData = $this->db->get_where('mob_app_detail', array('app_id' => $app_id))->row_array();
              sql = `SELECT * FROM mob_app_detail WHERE app_id =${app_id}`;
              var appData = await query(sql, conn);
              if (app_id > 1000) {
                var from_email = appData.org_email;
              } else if (appData.length != 0) {
                var from_email = appData.org_email;
              } else {
                var from_email = 'contact@mycareerlift.in';
              }

              var message = [
                {
                  subject: 'Registration Successful - ' + appData.org_name + '',
                  from_email: from_email,
                  to: { email: '' + emailTo + '', name: '' + fname + '' },
                  headers: { 'Reply-To': 'noreply@educationalemail.com' },
                  merge_vars: [
                    {
                      rcpt: '' + emailTo + '',
                      vars: [
                        {
                          name: 'CLF',
                          content: '' + fname + '',
                        },
                        {
                          name: 'MCLF',
                          content: '' + lname + '',
                        },
                        {
                          name: 'LOGIN',
                          content: '' + emailTo + '',
                        },
                        {
                          name: 'PASSWORD',
                          content: '' + password + '',
                        },
                        {
                          name: 'org_name',
                          content: '' + appData.org_name + '',
                        },
                        {
                          name: 'URL',
                          content: '' + appData.org_url + '',
                        },
                        {
                          name: 'Reply_To',
                          content: '' + appData.reply_to + '',
                        },
                        {
                          name: 'Mailing_Add',
                          content: '' + appData.org_address + '',
                        },
                      ],
                    },
                  ],
                  tags: ['mob_registration_mail'],
                },
              ];
              if (app_id > 1000 && app_id < 100000) {
                var template_name = 'Neu_RegEmail_Mobile';
              } else {
                var template_name = 'Neu_RegEmail_Mobile_mcl';
              }

              var template_content = [
                [
                  {
                    name: 'main',
                    content: 'Hi',
                  },
                ],
                [
                  {
                    name: 'footer',
                    content: 'Copyright 2019.',
                  },
                ],
              ];

              //    $response = $mandrill->messages->sendTemplate($template_name, $template_content, $message);
              const template = {
                template_name: template_name,
                template_content: template_content,
                message: message,
                async: false,
                ip_pool: 'Main Pool',
              };

              return new Promise((resolve, reject) => {
                mandrill_client.messages.sendTemplate(
                  template,
                  (result) => {
                    resolve(result);
                  },
                  (e) => {
                    console.error(e);
                    reject(e);
                  }
                );
              });
            }
          }

          async function insert_user_detail(
            contact = '',
            email = '',
            password = '',
            fname = '',
            lname = '',
            edu_qual = '',
            stream = '',
            user_type = '',
            city = '',
            state = '',
            country = '',
            image = '',
            hash = '',
            source = '',
            gcm_id = '',
            version = '',
            app_id = ''
          ) {
            var data = {};

            if (email) {
              sql = `SELECT COUNT(*) FROM user_detail WHERE user_email="${email}" OR user_fb_email="${email}" OR user_gplus_email="${email}"`;
              var isExist = await query(sql, conn);

              if (isExist) {
                sql = `SELECT * FROM user_detail WHERE user_email= "${email}" OR user_fb_email="${email}" OR user_gplus_email="${email}"`;
                var userdata = await query(sql, conn);

                var totalMonths = get_total_months(userdata[0].last_active);

                /****** code written on 27-09-2017 by aish *******/
                var userInstId = userdata[0].user_inst_id;
                //var mobAppData = $this->User_model->getDetailRow('inst_id,app_type',$table='mob_app_detail',$where=array('app_id'=>$app_id));
                sql = `SELECT inst_id,app_type FROM mob_app_detail WHERE app_id =${app_id}`;
                var mobAppData = await query(sql, conn);
                /* Added By Padam Jain 21-06-2019 */
                var updateUserArray = {};
                if (userdata[0].user_inst_id == 1736) {
                  updateUserArray.user_inst_id = mobAppData[0].inst_id;
                } else if (
                  userdata[0].user_inst_id != 1736 &&
                  totalMonths >= 6
                ) {
                  updateUserArray.user_inst_id = mobAppData[0].inst_id;
                }
                /* End Added By Padam Jain 21-06-2019 */
                if (check_sales_email(email) == 1) {
                  /* This code is same as register_user_v8 */
                  if (
                    userdata[0].user_id != '' &&
                    userdata[0].user_id != null &&
                    userdata[0].user_id != 0
                  ) {
                    updateUserArray.collaboration_status = 'active';
                    if (typeof email !== 'undefined') {
                      updateUserArray.user_email = email;
                    }
                    if (typeof source !== 'undefined') {
                      updateUserArray.source = source;
                    }
                    if (typeof app_id !== 'undefined') {
                      updateUserArray.app_id = app_id;
                    }
                    if (typeof version !== 'undefined') {
                      updateUserArray.app_version = version;
                    }
                    if (typeof contact !== 'undefined') {
                      updateUserArray.user_contact_no = contact;
                    }
                    if (typeof edu_qual !== 'undefined') {
                      updateUserArray.user_qual = edu_qual;
                    }
                    if (typeof stream !== 'undefined') {
                      updateUserArray.stream = stream;
                    }
                    if (typeof fname !== 'undefined') {
                      updateUserArray.user_first_name = fname;
                    }
                    if (typeof lname !== 'undefined') {
                      updateUserArray.user_last_name = lname;
                    }
                    if (typeof user_type !== 'undefined') {
                      updateUserArray.user_type = user_type;
                    }
                    if (typeof city !== 'undefined') {
                      updateUserArray.user_city_name = city;
                    }
                    if (typeof state !== 'undefined') {
                      updateUserArray.user_state_name = state;
                    }
                    if (typeof country !== 'undefined') {
                      updateUserArray.user_country_name = country;
                    }
                    if (typeof image !== 'undefined') {
                      updateUserArray.user_photo = image;
                    }

                    /* Added BY Padam Jain 07-08-2018 */
                    if (mobAppData[0].app_type == 'semi_secured') {
                      updateUserArray.access_allow = 'No';
                    } else {
                      updateUserArray.access_allow = null;
                    }
                    /* End Added BY Padam Jain 07-08-2018 */
                    /* Added BY Padam Jain 15-06-2018 */
                    /*if($app_id>1000){$updateUserArray['access_allow'] = 'Yes'; } else {$updateUserArray['access_allow'] = NULL;}*/
                    /* END Added BY Padam Jain 15-06-2018 */
                    //$this->User_model->update('user_detail',$where=array('user_id'=>intval($userdata['user_id'])),$updateUserArray);
                    sql = `UPDATE user_detail SET collaboration_status="${
                      updateUserArray.collaboration_status
                    }", user_email="${updateUserArray.user_email}",source="${
                      updateUserArray.source
                    }",app_id=${updateUserArray.app_id}, app_version=${
                      updateUserArray.app_version
                    },user_contact_no=${
                      updateUserArray.user_contact_no
                    },user_qual="${updateUserArray.user_qual}",stream="${
                      updateUserArray.stream
                    }",user_first_name = "${
                      updateUserArray.user_first_name
                    }",user_last_name ="${
                      updateUserArray.user_last_name
                    }"",user_type = "${
                      updateUserArray.user_type
                    }",user_city_name = "${
                      updateUserArray.user_city_name
                    }",user_state_name ="${
                      updateUserArray.user_state_name
                    }",user_country_name = "${
                      updateUserArray.user_country_name
                    }",user_photo = "${
                      updateUserArray.user_photo
                    }"WHERE user_id=${parseInt(userdata[0].user_id)}`;
                    await query(sql, conn);

                    // $appUserExist = $this->User_model->get_num_records($table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                    sql = `SELECT * FROM ots_app_user_sync WHERE aus_app_id = ${app_id} AND aus_user_id = ${userdata[0].user_id}`;
                    var appUserExist1 = await query(sql, conn);
                    var appUserExist = appUserExist1.length;
                    if (appUserExist) {
                      //appUserSyncData = $this->User_model->getDetailRow('*',$table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                      sql = `SELECT * FROM ots_app_user_sync WHERE aus_app_id = ${app_id} AND aus_user_id = ${userdata[0].user_id}`;
                      var appUserSyncData = await query(sql, conn);
                      //$update = array('aus_test_sync_id' => 0, 'aus_career_exchange_sync_id' => 0, 'aus_mob_post_sync_id' => 0);
                      //$this->User_model->update('ots_app_user_sync',$where=array('aus_app_id'=>$app_id,'aus_user_id'>$userdata['user_id']),$update);
                      sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0,aus_career_exchange_sync_id = 0, aus_mob_post_sync_id = 0 WHERE aus_app_id= ${app_id} AND aus_user_id>${userdata[0].user_id} `;
                      await query(sql, conn);
                    } else {
                      var app_user_sync_data = [
                        {
                          aus_app_id: app_id,
                          aus_user_id: userdata[0].user_id,
                          aus_test_sync_id: 0,
                          aus_career_exchange_sync_id: 0,
                          aus_mob_post_sync_id: 0,
                        },
                      ];
                      // $lastId = $this->User_model->insert('ots_app_user_sync',$app_user_sync_data);
                      sql = `INSERT INTO ots_app_user_sync (aus_app_id,aus_user_id,aus_test_sync_id,aus_career_exchange_sync_id,aus_mob_post_sync_id)VALUES(${app_user_sync_data.aus_app_id},${app_user_sync_data.aus_user_id},${app_user_sync_data.aus_test_sync_id},${app_user_sync_data.aus_career_exchange_sync_id},${app_user_sync_data.aus_mob_post_sync_id})`;
                      var lastId = await query(sql, conn);
                    }

                    // $this->User_model->update('master_user_login',$where=array('user_id'>$userdata['user_id']),array('email_verified' => 'yes', 'mobile_verified' => 'yes'));
                    sql = `UPDATE master_user_login SET email_verified = 'yes', mobile_verified = 'yes' WHERE user_id >${userdata[0].user_id}`;
                    await query(sql, conn);
                  }

                  //Remove in next version user_address,zip_code,org_name,job_title,subject
                  /* Added BY Padam Jain 15-06-2018 */
                  if (userdata[0].access_allow == null) {
                    var accessAllow = 'Yes';
                  } else {
                    var accessAllow = userdata[0].access_allow;
                  }
                  /* END Added BY Padam Jain 15-06-2018 */
                  data = {
                    is_update: 1,
                    status1: 0,
                    user_email: email,
                    user_address: userdata[0].user_address,
                    zip_code: userdata[0].zip_code,
                    org_name: userdata[0].org_name,
                    job_title: userdata[0].job_title,
                    user_location: userdata[0].user_location,
                    prev_exam_percentage: userdata[0].prev_exam_percentage,
                    user_id: userdata[0].user_id,
                    user_hash: userdata[0].user_hash,
                    /* Added BY Padam Jain 15-06-2018 */
                    access_allow: accessAllow,
                    /* END Added BY Padam Jain 15-06-2018 */
                  };

                  data.user_first_name = fname
                    ? fname
                    : userdata[0].user_first_name;
                  data.user_last_name = lname
                    ? lname
                    : userdata[0].user_last_name;
                  data.user_contact_no = contact
                    ? contact
                    : userdata[0].user_contact_no;
                  data.user_qual = edu_qual ? edu_qual : userdata[0].user_qual;
                  data.role = user_type ? user_type : userdata[0].user_type;
                  data.stream = stream ? stream : userdata[0].stream;
                  data.city_name = city ? city : userdata[0].user_city_name;
                  data.state_name = state ? state : userdata[0].user_state_name;
                  data.country_name = country
                    ? country
                    : userdata[0].user_country_name;
                  //$data['user_photo']         = $userdata['user_photo'];
                  //$data['user_image_path']    =  $image       ? $image        : $userdata['user_image_url'];
                  data.user_image_path = image ? image : userdata[0].user_photo;
                  return data;
                  /* /End of same code */
                } else if (totalMonths >= 6) {
                  /* Added by Padam Jain 10-08-2019 */
                  //log_message('debug', 'if case user id is='. $userInstId . 'and app detail institute id is =' .$mobAppData['inst_id']);
                  /* This code is same as register_user_v8 */
                  if (
                    userdata[0].user_id != '' &&
                    userdata[0].user_id != null &&
                    userdata[0].user_id != 0
                  ) {
                    updateUserArray.collaboration_status = 'active';
                    if (typeof email !== 'undefined') {
                      updateUserArrayuser_email = email;
                    }
                    if (typeof source !== 'undefined') {
                      updateUserArraysource = source;
                    }
                    if (typeof app_id !== 'undefined') {
                      updateUserArrayapp_id = app_id;
                    }
                    if (typeof version !== 'undefined') {
                      updateUserArrayapp_version = version;
                    }
                    if (typeof contact !== 'undefined') {
                      updateUserArrayuser_contact_no = contact;
                    }
                    if (typeof edu_qual !== 'undefined') {
                      updateUserArrayuser_qual = edu_qual;
                    }
                    if (typeof stream !== 'undefined') {
                      updateUserArraystream = stream;
                    }
                    if (typeof fname !== 'undefined') {
                      updateUserArrayuser_first_name = fname;
                    }
                    if (typeof lname !== 'undefined') {
                      updateUserArrayuser_last_name = lname;
                    }
                    if (typeof user_type !== 'undefined') {
                      updateUserArrayuser_type = user_type;
                    }
                    if (typeof city !== 'undefined') {
                      updateUserArrayuser_city_name = city;
                    }
                    if (typeof state !== 'undefined') {
                      updateUserArrayuser_state_name = state;
                    }
                    if (typeof country !== 'undefined') {
                      updateUserArrayuser_country_name = country;
                    }
                    //if(isset($image)){              $updateUserArray['user_image_url']      = $image;      }
                    if (typeof image !== 'undefined') {
                      updateUserArray.user_photo = image;
                    }
                    /* Added BY Padam Jain 07-08-2018 */
                    if (mobAppData[0].app_type == 'semi_secured') {
                      updateUserArray.access_allow = 'No';
                    } else {
                      updateUserArray.access_allow = null;
                    }
                    /* End Added BY Padam Jain 07-08-2018 */
                    /* Added BY Padam Jain 15-06-2018 */
                    /*if($app_id>1000){$updateUserArray['access_allow'] = 'Yes'; } else {$updateUserArray['access_allow'] = NULL;}*/
                    /* END Added BY Padam Jain 15-06-2018 */
                    //$this->User_model->update('user_detail',$where=array('user_id'=>intval($userdata['user_id'])),$updateUserArray);
                    sql = `UPDATE user_detail SET collaboration_status="${
                      updateUserArray.collaboration_status
                    }", user_email="${updateUserArray.user_email}",source="${
                      updateUserArray.source
                    }",app_id=${updateUserArray.app_id}, app_version=${
                      updateUserArray.app_version
                    },user_contact_no=${
                      updateUserArray.user_contact_no
                    },user_qual="${updateUserArray.user_qual}",stream="${
                      updateUserArray.stream
                    }",user_first_name = "${
                      updateUserArray.user_first_name
                    }",user_last_name ="${
                      updateUserArray.user_last_name
                    }",user_type = "${
                      updateUserArray.user_type
                    }",user_city_name = "${
                      updateUserArray.user_city_name
                    }",user_state_name ="${
                      updateUserArray.user_state_name
                    }",user_country_name = "${
                      updateUserArray.user_country_name
                    }",user_photo = "${
                      updateUserArray.user_photo
                    }"WHERE user_id=${parseInt(userdata[0].user_id)}`;

                    await query(sql, conn);
                    //$appUserExist = $this->User_model->get_num_records($table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                    sql = `SELECT * FROM ots_app_user_sync WHERE  aus_app_id = ${app_id}, aus_user_id= ${userdata[0].user_id}`;
                    var appUserExist1 = await query(sql, conn);
                    var appUserExist = appUserExist1.length;
                    if (appUserExist) {
                      // appUserSyncData = $this->User_model->getDetailRow('*',$table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                      sql = `SELECT * FROM ots_app_user_sync WHERE aus_app_id= ${app_id}, aus_user_id=${userdata[0].user_id}`;
                      appUserSyncData = await query(sql, conn);
                      // $update = array('aus_test_sync_id' => 0, 'aus_career_exchange_sync_id' => 0, 'aus_mob_post_sync_id' => 0);
                      //$this->User_model->update('ots_app_user_sync',$where=array('aus_app_id'=>$app_id,'aus_user_id'>$userdata['user_id']),$update);
                      sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0, aus_career_exchange_sync_id = 0, aus_mob_post_sync_id =0 WHERE aus_app_id=${app_id},aus_user_id>${userdata[0].user_id} `;
                      await query(sql, conn);
                    } else {
                      var app_user_sync_data = [
                        {
                          aus_app_id: app_id,
                          aus_user_id: userdata[0].user_id,
                          aus_test_sync_id: 0,
                          aus_career_exchange_sync_id: 0,
                          aus_mob_post_sync_id: 0,
                        },
                      ];
                      //$lastId = $this->User_model->insert('ots_app_user_sync',$app_user_sync_data);
                      sql = `INSERT INTO ots_app_user_sync (aus_app_id,aus_user_id,aus_test_sync_id,aus_career_exchange_sync_id,aus_mob_post_sync_id)VALUES(${app_user_sync_data.aus_app_id},${app_user_sync_data.aus_user_id},${app_user_sync_data.aus_test_sync_id},${app_user_sync_data.aus_career_exchange_sync_id},${app_user_sync_data.aus_mob_post_sync_id})`;
                      var lastId = await query(sql, conn);
                    }
                    //$this->User_model->update('master_user_login',$where=array('user_id'>$userdata['user_id']),array('email_verified' => 'yes', 'mobile_verified' => 'yes'));
                    sql = `UPDATE master_user_login SET email_verified = 'yes', mobile_verifie = 'yes' WHERE user_id>${userdata[0].user_id}`;
                    await query(sql, conn);
                  }

                  //Remove in next version user_address,zip_code,org_name,job_title,subject
                  /* Added BY Padam Jain 15-06-2018 */
                  if (userdata.access_allow == null) {
                    var accessAllow = 'Yes';
                  } else {
                    var accessAllow = userdata.access_allow;
                  }
                  /* END Added BY Padam Jain 15-06-2018 */
                  //log_message('debug', 'in User Deatil Email: '.$email.' ----  '.check_sales_email($email).' ----User Inst: '.$userInstId.' ----Mob. App Inst: '.$mobAppData['inst_id']);
                  data = {
                    is_update: 1,
                    status1: 0,
                    user_email: email,
                    user_address: userdata[0].user_address,
                    zip_code: userdata[0].zip_code,
                    org_name: userdata[0].org_name,
                    job_title: userdata[0].job_title,
                    user_location: userdata[0].user_location,
                    prev_exam_percentage: userdata[0].prev_exam_percentage,
                    user_id: userdata[0].user_id,
                    user_hash: userdata[0].user_hash,
                    /* Added BY Padam Jain 15-06-2018 */
                    access_allow: accessAllow,
                    /* END Added BY Padam Jain 15-06-2018 */
                  };
                  data.user_first_name = fname
                    ? fname
                    : userdata[0].user_first_name;
                  data.user_last_name = lname
                    ? lname
                    : userdata[0].user_last_name;
                  data.user_contact_no = contact
                    ? contact
                    : userdata[0].user_contact_no;
                  data.user_qual = edu_qual ? edu_qual : userdata[0].user_qual;
                  data.role = user_type ? user_type : userdata[0].user_type;
                  data.stream = stream ? stream : userdata[0].stream;
                  data.city_name = city ? city : userdata[0].user_city_name;
                  data.state_name = state ? state : userdata[0].user_state_name;
                  data.country_name = country
                    ? country
                    : userdata[0].user_country_name;
                  //$data['user_photo']         = $userdata['user_photo'];
                  //$data['user_image_path']    =  $image       ? $image        : $userdata['user_image_url'];
                  data.user_image_path = image ? image : userdata[0].user_photo;
                  /* /End of same code */
                  return data;
                } else if (
                  /* End Added by Padam Jain 10-08-2019 */
                  userInstId == mobAppData[0].inst_id &&
                  check_sales_email(email) == 0
                ) {
                  // log_message('debug', 'if case user id is='. $userInstId . 'and app detail institute id is =' .$mobAppData['inst_id']);
                  /* This code is same as register_user_v8 */
                  if (
                    userdata[0].user_id != '' &&
                    userdata[0].user_id != null &&
                    userdata[0].user_id != 0
                  ) {
                    updateUserArray.collaboration_status = 'active';
                    if (typeof email !== 'undefined') {
                      updateUserArray.user_email = email;
                    }
                    if (typeof source !== 'undefined') {
                      updateUserArray.source = source;
                    }
                    if (typeof app_id !== 'undefined') {
                      updateUserArray.app_id = app_id;
                    }
                    if (typeof version !== 'undefined') {
                      updateUserArray.app_version = version;
                    }
                    if (typeof contact !== 'undefined') {
                      updateUserArray.user_contact_no = contact;
                    }
                    if (typeof edu_qual !== 'undefined') {
                      updateUserArray.user_qual = edu_qual;
                    }
                    if (typeof stream !== 'undefined') {
                      updateUserArray.stream = stream;
                    }
                    if (typeof fname !== 'undefined') {
                      updateUserArray.user_first_name = fname;
                    }
                    if (typeof lname !== 'undefined') {
                      updateUserArray.user_last_name = lname;
                    }
                    if (typeof user_type !== 'undefined') {
                      updateUserArray.user_type = user_type;
                    }
                    if (typeof city !== 'undefined') {
                      updateUserArray.user_city_name = city;
                    }
                    if (typeof state !== 'undefined') {
                      updateUserArray.user_state_name = state;
                    }
                    if (typeof country !== 'undefined') {
                      updateUserArray.user_country_name = country;
                    }
                    // if(isset($image)){              $updateUserArray['user_image_url']      = $image;      }
                    if (typeof image !== 'undefined') {
                      updateUserArray.user_photo = image;
                    }
                    /* Added BY Padam Jain 07-08-2018 */
                    if (mobAppData[0].app_type == 'semi_secured') {
                      updateUserArray.access_allow = 'No';
                    } else {
                      updateUserArray.access_allow = null;
                    }
                    /* End Added BY Padam Jain 07-08-2018 */
                    /* Added BY Padam Jain 15-06-2018 */
                    /*if($app_id>1000){$updateUserArray['access_allow'] = 'Yes'; } else {$updateUserArray['access_allow'] = NULL;}*/
                    /* END Added BY Padam Jain 15-06-2018 */
                    //$this->User_model->update('user_detail',$where=array('user_id'=>intval($userdata['user_id'])),$updateUserArray);
                    sql = `UPDATE user_detail SET collaboration_status="${
                      updateUserArray.collaboration_status
                    }", user_email="${updateUserArray.user_email}",source="${
                      updateUserArray.source
                    }",app_id=${updateUserArray.app_id}, app_version=${
                      updateUserArray.app_version
                    },user_contact_no=${
                      updateUserArray.user_contact_no
                    },user_qual="${updateUserArray.user_qual}",stream="${
                      updateUserArray.stream
                    }",user_first_name = "${
                      updateUserArray.user_first_name
                    }",user_last_name ="${
                      updateUserArray.user_last_name
                    }",user_type = "${
                      updateUserArray.user_type
                    }",user_city_name = "${
                      updateUserArray.user_city_name
                    }",user_state_name ="${
                      updateUserArray.user_state_name
                    }",user_country_name = "${
                      updateUserArray.user_country_name
                    }",user_photo = "${
                      updateUserArray.user_photo
                    }"WHERE user_id=${parseInt(userdata[0].user_id)}`;
                    await query(sql, conn);
                    //$appUserExist = $this->User_model->get_num_records($table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                    sql = `SELECT * FROM ots_app_user_sync WHERE aus_app_id = ${app_id} AND aus_user_id = ${userdata[0].user_id}`;
                    var appUserExist1 = await query(sql, conn);
                    var appUserExist = appUserExist1.length;
                    if (appUserExist) {
                      //appUserSyncData = $this->User_model->getDetailRow('*',$table='ots_app_user_sync',$where=array('aus_app_id' => $app_id, 'aus_user_id' => $userdata['user_id']));
                      sql = `SELECT * FROM ots_app_user_sync WHERE aus_app_id= ${app_id} AND aus_user_id=${userdata[0].user_id}`;
                      appUserSyncData = await query(sql, conn);
                      //$update = array('aus_test_sync_id' => 0, 'aus_career_exchange_sync_id' => 0, 'aus_mob_post_sync_id' => 0);
                      //$this->User_model->update('ots_app_user_sync',$where=array('aus_app_id'=>$app_id,'aus_user_id'>$userdata['user_id']),$update);
                      sql = `UPDATE ots_app_user_sync SET aus_test_sync_id = 0, aus_career_exchange_sync_id = 0, aus_mob_post_sync_id =0 WHERE aus_app_id=${app_id} AND aus_user_id>${userdata[0].user_id} `;
                      await query(sql, conn);
                    } else {
                      var app_user_sync_data = [
                        {
                          aus_app_id: app_id,
                          aus_user_id: userdata[0].user_id,
                          aus_test_sync_id: 0,
                          aus_career_exchange_sync_id: 0,
                          aus_mob_post_sync_id: 0,
                        },
                      ];
                      //  $lastId = $this->User_model->insert('ots_app_user_sync',$app_user_sync_data);
                      sql = `INSERT INTO ots_app_user_sync (aus_app_id,aus_user_id,aus_test_sync_id,aus_career_exchange_sync_id,aus_mob_post_sync_id)VALUES(${app_user_sync_data.aus_app_id},${app_user_sync_data.aus_user_id},${app_user_sync_data.aus_test_sync_id},${app_user_sync_data.aus_career_exchange_sync_id},${app_user_sync_data.aus_mob_post_sync_id})`;
                      var lastId = await query(sql, conn);
                    }
                    //   $this->User_model->update('master_user_login',$where=array('user_id'>$userdata['user_id']),array('email_verified' => 'yes', 'mobile_verified' => 'yes'));
                    sql = `UPDATE master_user_login SET email_verified = 'yes', mobile_verified = 'yes' WHERE user_id>${userdata[0].user_id}`;
                    await query(sql, conn);
                    // log_message('debug', 'after email verified update');
                  }

                  //Remove in next version user_address,zip_code,org_name,job_title,subject
                  /* Added BY Padam Jain 15-06-2018 */
                  if (userdata.access_allow == null) {
                    accessAllow = 'Yes';
                  } else {
                    accessAllow = userdata[0].access_allow;
                  }
                  /* END Added BY Padam Jain 15-06-2018 */
                  //  log_message('debug', 'in User Deatil Email: '.$email.' ----  '.check_sales_email($email).' ----User Inst: '.$userInstId.' ----Mob. App Inst: '.$mobAppData['inst_id']);
                  data = {
                    is_update: 1,
                    status1: 0,
                    user_email: email,
                    user_address: userdata[0].user_address,
                    zip_code: userdata[0].zip_code,
                    org_name: userdata[0].org_name,
                    job_title: userdata[0].job_title,
                    user_location: userdata[0].user_location,
                    prev_exam_percentage: userdata[0].prev_exam_percentage,
                    user_id: userdata[0].user_id,
                    user_hash: userdata[0].user_hash,
                    /* Added BY Padam Jain 15-06-2018 */
                    access_allow: accessAllow,
                    /* END Added BY Padam Jain 15-06-2018 */
                  };
                  data.user_first_name = fname
                    ? fname
                    : userdata.user_first_name;
                  data.user_last_name = lname ? lname : userdata.user_last_name;
                  data.user_contact_no = contact
                    ? contact
                    : userdata.user_contact_no;
                  data.user_qual = edu_qual ? edu_qual : userdata.user_qual;
                  data.role = user_type ? user_type : userdata.user_type;
                  data.stream = stream ? stream : userdata.stream;
                  data.city_name = city ? city : userdata.user_city_name;
                  data.state_name = state ? state : userdata.user_state_name;
                  data.country_name = country
                    ? country
                    : userdata.user_country_name;
                  //$data['user_photo']         = $userdata['user_photo'];
                  //$data['user_image_path']    =  $image       ? $image        : $userdata['user_image_url'];
                  data.user_image_path = image ? image : userdata.user_photo;
                  return data;
                  /* /End of same code */
                } else {
                  //log_message('debug', 'in None Email: '.$email.' ----  '.check_sales_email($email).' ----User Inst: '.$userInstId.' ----Mob. App Inst: '.$mobAppData['inst_id']);
                  //log_message('debug', 'else case user id is='. $userInstId . 'and app detail institute id is =' .$mobAppData['inst_id']);
                  data.is_update = 0;
                  data.status1 = 0;
                  return data;
                }
                /*** /End of code ****/
              } else {
                if (source == 'fb_mob') {
                  fb_email = email;
                  //$fb_social_id = $social_id;
                } else {
                  fb_email = null;
                  //$fb_social_id = NULL;
                }
                if (source == 'gplus_mob') {
                  gplus_email = email;
                  //$gplus_social_id = $social_id;
                } else {
                  gplus_email = null;
                  //$gplus_social_id = NULL;
                }
                /* Added BY Padam Jain 07-08-2018 */
                //  $mobAppDetail = $this->User_model->getDetailRow('inst_id,app_type',$table='mob_app_detail',$where=array('app_id'=>$app_id));
                sql = `SELECT inst_id,app_type FROM mob_app_detail WHERE app_id=${app_id}`;
                var mobAppDetail = await query(sql, conn);
                /* echo "<pre>";print_r($mobAppDetail);echo "</pre>";
                    var_dump($mobAppDetail);die;*/

                if (mobAppDetail.app_type == 'semi_secured') {
                  accessAllowVal = 'No';
                } else {
                  accessAllowVal = null;
                }
                /* End Added BY Padam Jain 07-08-2018 */

                var userData = [
                  {
                    user_hash: md5(Math.random()).substr(1, 36),
                    user_email: email,
                    user_password: password,
                    user_first_name: fname,
                    user_last_name: lname,
                    user_city_name: city,
                    user_state_name: state,
                    user_country_name: country,
                    user_qual: edu_qual,
                    stream: stream,
                    user_type: user_type,
                    user_contact_no: contact,
                    user_created: Date('Y-m-d h:i:s'),
                    last_active: Date('Y-m-d h:i:s'),
                    user_photo: image,
                    source: source,
                    register_gcm_id: gcm_id,
                    app_version: version,
                    app_id: app_id,
                    user_fb_email: fb_email,
                    user_gplus_email: gplus_email,
                    collaboration_status: 'active',
                    user_image_url: image,
                    user_image_update: Date('Y-m-d H:i:s'),
                    /* Added BY Padam Jain 15-06-2018 */
                    access_allow: accessAllowVal,
                    /* End Added BY Padam Jain 15-06-2018 */
                  },
                ];
                // $mobAppData_exist = $this->User_model->get_num_records($table='mob_app_detail',$where=array('app_id'=>$app_id));
                sql = `SELECT * FROM mob_app_detail WHERE app_id= ${app_id}`;
                var mobAppData_exist1 = await query(sql, conn);
                var mobAppData_exist = mobAppData_exist1.length;
                if (mobAppData_exist) {
                  //   $mobAppData = $this->User_model->getDetailRow('inst_id',$table='mob_app_detail',$where=array('app_id'=>$app_id));
                  sql = `SELECT inst_id FROM mob_app_detail WHERE app_id=${app_id}`;
                  var mobAppData = await query(sql, conn);
                  if (mobAppData.inst_id != 0 && mobAppData.inst_id != null) {
                    userData.user_inst_id = mobAppData.inst_id;
                  } else {
                    userData.user_inst_id = 1736;
                  }
                } else {
                  userData.user_inst_id = 1736;
                }

                last_insert_id = null;
                // log_message('debug', 'before check email and contact blank');
                //log_message('debug', 'Access Log='. $userData['access_allow']." --- ".$accessAllowVal);
                /* Insert record in User detail */
                if (email != '' && email != null) {
                  //  $last_insert_id = $this->User_model->insert('user_detail',$userData);
                  sql = ` INSERT INTO user_detail ( user_hash,user_email,user_password,user_first_name,user_last_name,user_city_name,user_state_name,user_country_name,user_qual,stream,user_type,user_contact_no,user_created,last_active,user_photo,source,register_gcm_id,app_version,app_id,user_fb_email,user_gplus_email,collaboration_status,user_image_url,user_image_update,access_allow)VALUES(${userData.user_hash},${userData.user_email},${userData.user_password},${userData.user_first_name},${userData.user_last_name},${userData.user_city_name},${userData.user_state_name},${userData.user_country_name},${userData.user_country_name},${userData.user_qual},${userData.stream},${userData.user_type},${userData.user_contact_no},${userData.user_created},${userData.last_active},${userData.user_photo},${userData.source},${userData.register_gcm_id},${userData.app_version},${userData.app_id},${userData.user_fb_email},${userData.user_gplus_email},${userData.collaboration_status},${userData.user_image_url},${userData.user_image_update},${userData.access_allow})`;
                  var last_insert_id = await query(sql, conn);
                }

                /* Insert record in Master user login */
                if (email != '' && email != null) {
                  var masterUserData = [
                    {
                      user_id: ast_insert_id,
                      role: 'Student',
                      email: email,
                      password: md5(password),
                      fname: fname,
                      lname: lname,
                      hash: hash,
                      email_verified: 'yes',
                      mobile_verified: 'yes',
                      account_status: 1,
                    },
                  ];

                  if (source == 'mob') {
                    masterUserData.account_status = 1;
                    masterUserData.email_verified = 'yes';
                  }
                  //   $last_master_insert_id = $this->User_model->insert('master_user_login',$masterUserData);
                  sql = `INSERT INTO master_user_login (user_id,role,email,password,fname,lname,hash,email_verified,mobile_verified,account_status)VALUES(${masterUserData.user_id},${masterUserData.role},${masterUserData.email},${masterUserData.password},${masterUserData.fname},${masterUserData.lname},${masterUserData.hash},${masterUserData.email_verified},${masterUserData.mobile_verified},${masterUserData.account_status})`;
                  var last_master_insert_id = await query(sql, conn);
                }

                /* Insert record in Log Login Attempt */
                if (email != '' && email != null) {
                  var log_detail = [
                    {
                      user_id: last_insert_id,
                      user_name: userData.user_first_name,
                      mobile_no: userData.user_contact_no,
                      email: userData.user_email,
                      user_qual: userData.user_qual,
                      location: city,
                      status: 'registration successful',
                      source: source,
                    },
                  ];

                  /*curl_call($url,$data_string);*/
                  var current_date = Date();
                  var current_time = Date();
                  var data_string = log_detail;

                  //$last_login_insert_id = $this->User_model->insert('log_login_attempt',$log_login_data);
                }

                /* Insert record in App User Sync */
                var app_user_sync_data = [
                  {
                    aus_app_id: app_id,
                    aus_user_id: last_insert_id,
                    aus_test_sync_id: 0,
                    aus_career_exchange_sync_id: 0,
                    aus_mob_post_sync_id: 0,
                  },
                ];
                //$last_sync_insert_id = $this->User_model->insert('ots_app_user_sync',$app_user_sync_data);
                sql = `INSERT INTO ots_app_user_sync (aus_app_id,aus_user_id,aus_test_sync_id,aus_career_exchange_sync_id,aus_mob_post_sync_id)VALUES(${app_user_sync_data.aus_app_id},${app_user_sync_data.aus_user_id},${app_user_sync_data.aus_test_sync_id},${app_user_sync_data.aus_career_exchange_sync_id},${app_user_sync_data.aus_mob_post_sync_id})`;
                var last_sync_insert_id = await query(sql, conn);

                data.user_email = userData.user_email;
                data.user_address = null;
                data.zip_code = null;
                data.org_name = null;
                data.job_title = null;
                data.role = userData.user_type;
                data.user_location = null;
                data.prev_exam_percentage = null;
                data.user_first_name = userData.user_first_name;
                data.user_last_name = userData.user_last_name;
                data.user_contact_no = userData.user_contact_no;
                data.user_qual = userData.user_qual;
                data.stream = userData.stream;
                data.city_name = city;
                data.state_name = state;
                data.country_name = country;
                data.user_id = last_insert_id;
                data.user_hash = userData.user_hash;
                data.user_image_path = image;
                data.status1 = 1;
                /* Added BY Padam Jain 15-06-2018 */
                data.access_allow = userData.access_allow;
                /* End Added BY Padam Jain 15-06-2018 */

                /* This code has been commented bcz we don't have user contact no at time of registration */
                if (app_id > 1000) {
                  if (
                    userData.user_first_name ||
                    (userData.user_last_name && userData.user_contact_no)
                  ) {
                    //$instData = $this->db->query("SELECT mob_number FROM institute_details WHERE id=".$userData['user_inst_id']."")->row_array();
                    sql = `SELECT mob_number FROM institute_details WHERE id=${userData.user_inst_id}`;
                    var instData = await query(sql, conn);
                    if (instData) {
                      if (
                        user_type.indexOf('Student') !== 0 &&
                        user_type.indexOf('Student') !== null
                      ) {
                        var userType = 'Student';
                      } else if (
                        user_type.indexOf('Parent') !== 0 &&
                        user_type.indexOf('Parent') !== null
                      ) {
                        var userType = 'Parent';
                      } else if (
                        user_type.indexOf('Teacher') !== 0 &&
                        user_type.indexOf('Teacher') !== null
                      ) {
                        var userType = 'Teacher';
                      } else {
                        var userType = 'Student';
                      }

                      //         $text_message = '' . $userData['user_first_name'] . ' ' . $userData['user_last_name'] . ' (' . $userData['user_contact_no'] . '), ' . $userType . ', ' . $city . ' has downloaded your app.'
                      //         . 'CareerLift';
                      // if ($instData['mob_number'] != '' && $instData['mob_number'] != NULL && $instData['mob_number'] != 0) {
                      //    $this->load->library('smsgateway');
                      //    $tempId='1107161977754767270';
                      //    $this->smsgateway->send($instData['mob_number'], $text_message,$tempId);
                      // }
                    }
                  }
                }
                return data;
              }
            } else {
              data.is_update = 0;
              data.status1 = 0;
              return data;
            }
          }

          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;

function get_total_months(dbDate) {
  const now = new Date().getDate();
  //var a = date1.parse(now, 'YYYY-MM-DD hh:mm:ss');
  var string = String(dbDate);
  var b = parseInt(string.slice(8, 10));

  var dateDiffenceArray = Math.abs(now - b);

  //Date('Y-m-d H:i:s') - strtotime(dbDate)
  var years = Math.floor(dateDiffenceArray / (365 * 60 * 60 * 24));
  var months = Math.floor(
    (dateDiffenceArray - years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24)
  );
  var days = Math.floor(
    (dateDiffenceArray -
      years * 365 * 60 * 60 * 24 -
      months * 30 * 60 * 60 * 24) /
      (60 * 60 * 24)
  );
  var totalMonths = years * 12 + months;

  return totalMonths;
}
function check_sales_email(check_email) {
  const salesEmailArray = [
    //"neham.mycareerlift@gmail.com",
    //"priya.mycareerlift@gmail.com",
    //    "rinkey.mycareerlift@gmail.com",
    // "subham.mycareerlift@gmail.com",
    //"kajal.mycareerlift@gmail.com",
    //"mitali.mycareerlift@gmail.com",
    'vaibhavi.mycareerlift@gmail.com',
    'seebee.mycareerlift@gmail.com',
    // "sahil.mycareerlift@gmail.com",
    'avisha.mycareerlift@gmail.com',
    'deepak.mycareerlift@gmail.com',
    //"akashv.mycareerlift@gmail.com",
    'anirudh.mycareerlift@gmail.com',
    // "shubhamrai.mycareerlift@gmail.com",
    //"raksha.mycareerlift@gmail.com",
    // "rishika.mycareerlift@gmail.com",
    //"priyac.mycareerlift@gmail.com",
    'riddhi.mycareerlift@gmail.com',
    //    "abhisheks.mycareerlift@gmail.com",
    //    "antra.mycareerlift@gmail.com",
    'devendra.mycareerlift@gmail.com',
    //"karishma.mycareerlift@gmail.com",
    'padam.mycareerlift@gmail.com',
    'rahul.mycareerlift@gmail.com',
    'ritika.mycareerlift@gmail.com',
    //"priyanka.mycareerlift@gmail.com",
    //"nidhik.mycareerlift@gmail.com",
    'pulkit.mycareerlift@gmail.com',
    'pankaj.mycareerlift@gmail.com',
    'rishabh.mycareerlift@gmail.com',
    'sachendra.mycareerlift@gmail.com',
    'vinay.mycareerlift@gmail.com',
    //"saloni.mycareerlift@gmail.com",
    //"simran.mycareerlift@gmail.com",
    'kruti.mycareerlift@gmail.com',
    'sakshi.mycareerlift@gmail.com',
    'ruchi.mycareerlift@gmail.com',
    //    "sirilahari.mycareerlift@gmail.com",
    'kratij.mycareerlift@gmail.com',
    'rajita.mycareerlift@gmail.com',
    'nivedita.mycareerlift@gmail.com',
    'tina.mycareerlift@gmail.com',
    'rakshit.mycareerlift@gmail.com',
    'sanjay@mycareerlift.com',
    'nitil@mycareerlift.com',
    'manish@mycareerlift.com',
    'sanjayclf@gmail.com',
    //    "shailendra972@mycareerlift.com",
    'devpathare27@gmail.com',
    'vedpawar27@gmail.com',
    'rajrai111@gmail.com',
    //"karishmapatel251@gmail.com",
    //"patelkarishma44@gmail.com",
    'viralvidzpost@gmail.com',
    'manishji.gupta@gmail.com',
    'nitil_gupta@hotmail.com',
    'nitilims@gmail.com',
    //    "rthadhani2@gmail.com"
  ];
  var ret = 0;
  if (check_email) {
    salesEmailArray.forEach((salesEmail) => {
      if (salesEmail == check_email) {
        ret = 1;
      }
    });
  }
  return ret;
}
