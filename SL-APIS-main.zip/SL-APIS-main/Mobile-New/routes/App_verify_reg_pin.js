const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');
var nodemailer = require('nodemailer');
var mandrillTransport = require('nodemailer-mandrill-transport');
const md5 = require('md5-nodejs');

// program to generate random strings

// declare all characters
const characters = '0123456789';

function randomString(length) {
  let result = ' ';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }

  return result;
}

router.post('/APP_verify_reg_pin', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      res.status(500).send('Server Error');
    } else {
      
      const user_email = req.body.user_email; //change in mobile number in v3 hard coded
      const app_id = req.body.app_id;
      const app_hash = req.body.hash;
      const is_secure = req.body.is_secure;
      var verifyPinData = {};
      var sql =
        `select count(*)as mob_count from mob_app_detail where app_id="` +
        app_id +
        `" and app_hash="` +
        app_hash +
        `"`;

      const mob_Data = (await query(sql, conn))[0];

      if (mob_Data.mob_count > 0) {
        //user_email = 'deepak12345@gmail.com';  //change in mobile number in v3 hard coded
        //is_secure = 1;
        //app_id = 17;
        //req.body.user_password=1;
        // => $this->db->select('user_id,enable_app_test,user_password');
        // => $this->db->where('user_email', $user_email);
        sql = `SELECT user_id,enable_app_test,user_password FROM user_detail WHERE user_email="${user_email}"`;

        const userData = await query(sql, conn); // => $userData = $this->db->get('user_detail')->row_array();

        if (is_secure == 1) {
          const password = req.body.user_password;
          var passHash = md5(password);
          sql = `SELECT * FROM master_user_login WHERE password ="${passHash}" `;

          const masterUserData = await query(sql, conn); //= $this->db->get_where('master_user_login', array('password' => md5($password)))->row_array();
   
          if (!userData) {
            verifyPinData.flag = 0;
            verifyPinData.msg = 'Invalid Password.';
          } else {
            if (userData.enable_app_test === 1 && !masterUserData) {
              verifyPinData.flag = 1;
              //$verifyPinData['pin'] = $userData['user_password'];
              verifyPinData.msg = '';
            } else {
              verifyPinData.flag = 0;
              verifyPinData.msg = 'Invalid Password.';
            }
          }
        } else {
          pin = randomString(6);
          verifyPinData.flag = 1;
          verifyPinData.pin = pin;
          verifyPinData.msg = '';

          if (!userData) {
            verifyPinData.flag = 2;
          }
        }
        if (
          (verifyPinData.flag == 1 || verifyPinData.flag == 2) &&
          is_secure == 0
        ) {
          sql = `SELECT * FROM mob_app_detail WHERE app_id =${app_id}`;
          const appData = await query(sql, conn); //= $this->db->get_where('mob_app_detail', array('app_id' => $app_id))->row_array();

          var smtpTransport = nodemailer.createTransport(
            mandrillTransport({
              auth: {
                apiKey: 'bAV03zWPNHiodhkVXNkhLQ',
              },
            })
          );

          let mailOptions = {
            from: 'Senders@gmail.com',
            to: 'receivers@gmail.com',
            subject: 'This is from Mandrill',
            html: 'Hello,<br>Sending this email using Node and Mandrill',
          };

          let mailData = 'hello world';

          smtpTransport.sendMail(mailData, function (error, response) {
            if (error) {
              throw new Error('Error in sending email');
            }
            console.log('Message sent: ' + JSON.stringify(response));
          });
        }
        //  const json_response = JSON.stringify(verifyPinData);
        //  res.json(json_response);
        res.send(verifyPinData);
      } else {
        verifyPinData.flag = 5;
        // const json_response = JSON.stringify(verifyPinData);
        // res.json(json_response);
        res.send(verifyPinData);
      }

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
