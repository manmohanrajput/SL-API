const mysql = require('mysql');
const config = require('./default.json');
const pool = mysql.createPool({
    host: config.HOST4,
    user: config.user4,
    password: config.password4,
    database: config.database4,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

module.exports = pool;


