const mysql = require('mysql');
const config = require('./default.json');

const pool = mysql.createPool({
    host: config.HOST1,
    user: config.user1,
    password: config.password1,
    database: config.database1,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

module.exports = pool;

