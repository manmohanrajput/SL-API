const { json } = require('body-parser');
const { Template } = require('ejs');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_sz_data_v1', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          data.app_hash = req.body.app_hash;
          data.app_id = req.body.app_id;
          var sql = `select count(*)as user_count,enable_video_category,enable_notes_category from user_detail where user_id= ${data.user_id} and user_hash="${data.user_hash}" `;
          var user_Data;
          user_Data = await query(sql, conn);

          if (user_Data[0].user_count > 0) {
            //   $app_Data = $this->db->query("SELECT app_id,inst_id FROM mob_app_detail WHERE app_hash = '".$data['app_hash']."'")->row_array();
            sql = `SELECT app_id,inst_id FROM mob_app_detail WHERE app_hash ="${data.app_hash}"`;
            var app_Data = await query(sql, conn);

            if (app_Data) {
              data.app_id = app_Data[0].app_id;
            } else {
              data.app_id = 1;
            }

            /*echo "<li>".$data['app_id'];*/
            var pdf_list = [];
            var video_list = [];
            if (
              (data.app_id < 1000 || data.app_id > 100000) &&
              data.app_id != 4 &&
              data.app_id != 24 &&
              data.app_id != 25 &&
              data.app_id != 26 &&
              data.app_id != 27 &&
              data.app_id != 32 &&
              data.app_id != 33 &&
              data.app_id != 48 &&
              data.app_id != 49
            ) {
              //if($data['app_id'] < 15 || $data['app_id']> 100000){

              var app_hash = 'a7f4b141d5bf1eb8d017deaba15a5e14';
              // $pdf_Data = $this->db->query("SELECT * FROM app_pdf WHERE app_id = 1 AND app_hash = '".$app_hash."' order by pdf_id desc")->result_array();
              //$pdf_cat_Data = $this->db->query("SELECT distinct(pdf_tab) FROM app_pdf WHERE app_id = 1 AND app_hash = '".$app_hash."' order by pdf_id desc")->result_array();
              //            $where = array('app_hash'=>$app_hash,'app_id'=>1);
              //     $this->db->select('distinct(pdf_tab) as pdf_sub');
              //     $this->db->where($where);
              //     $this->db->group_start();
              //    // $this->db->where(array('video_subject!='=>'news'));
              //     $this->db->where('pdf_tab IS NULL');
              //     $this->db->or_where("pdf_tab =''");
              //     $this->db->group_end();
              //     $query1 = $this->db->get('app_pdf');
              //     $pdf_sub = $query1->result();
              // echo $this->db->last_query();die;
              sql = `distinct(pdf_tab) as pdf_sub FROM app_pdf WHERE app_hash="${app_hash}",app_id=1 AND(pdf_tab IS NULL OR pdf_tab ='')`;
              var pdf_sub = await query(sql, conn);
              var pdf_detail_data = [];
              if (pdf_sub) {
                await Promise.all(
                  pdf_sub.map(async (subRow1) => {
                    // await Promise.all(
                    //   postData.map(async (post) => {
                    if (subRow1.pdf_sub) {
                      // $where1 = array('app_hash'=>$app_hash,'app_id'=>1,'pdf_status'=>1);
                      // $this->db->select('*');
                      // $this->db->where($where1);
                      // $this->db->group_start();
                      // $this->db->or_where('pdf_tab IS NULL');
                      // $this->db->or_where("pdf_tab =''");
                      // $this->db->group_end();
                      // $query2 = $this->db->get('app_pdf');
                      // $pdf1_Data = $query2->result();
                      sql = `SELECT * FROM app_pdf WHERE app_hash="${app_hash}",app_id=1,pdf_status=1 AND (pdf_tab IS NULL OR pdf_tab ='')`;
                      var pdf1_Data = await query(sql, conn);
                    } else {
                      // $where1 = array('app_hash'=>$app_hash,'app_id'=>1,'pdf_tab'=>$subRow1->pdf_sub,'pdf_tab!='=>NULL,'pdf_tab!='=>'','pdf_status'=>1);
                      // $this->db->select('*');
                      // $this->db->where($where1);
                      // $query2 = $this->db->get('app_pdf');
                      // $pdf1_Data = $query2->result();
                      sql = `SELECT * FROM app_pdf app_hash="${app_hash}"",app_id=1,pdf_tab=${subRow1.pdf_sub},pdf_tab!=NULL,pdf_tab!='',pdf_status=1`;
                      var pdf1_Data = await query(sql, conn);
                    }
                    var listpdf = [];
                    pdf1_Data.forEach((pdfRow) => {
                      listpdf = [
                        {
                          title: pdfRow.title,
                          desc: pdfRow.sub_title,
                          url: 'mcllearnoadminpdf/' + pdfRow.pdf_name,
                          //'disclaim'=>$pdfRow->video_disclaim
                        },
                      ];
                    });
                    // print_r($listpdf);die;
                    if (listpdf) {
                      if (String(subRow1.pdf_sub).length == 0) {
                        var pdf_detail_data = [
                          { name: 'Other', content: listpdf },
                        ];
                      } else {
                        var pdf_detail_data = [
                          { name: subRow1.pdf_sub, content: listpdf },
                        ];
                      }
                    }
                  })
                );
                //$video_list=$video_detail_data;
              }
            } else {
              //$pdf_Data = $this->db->query("SELECT * FROM app_pdf WHERE app_id = '".$data['app_id']."' AND app_hash = '".$data['app_hash']."' order by pdf_id desc")->result_array();
              //$pdf_cat_Data = $this->db->query("SELECT distinct(pdf_tab) FROM app_pdf WHERE app_id = '".$data['app_id']."' AND app_hash = '".$data['app_hash']."' order by pdf_id desc")->result_array();
              // var where = [{app_hash: data.app_hash,app_id : data.app_id}]
              // $this->db->select('distinct(pdf_tab) as pdf_sub');
              // $this->db->where($where);
              //$this->db->group_start();
              // $this->db->where(array('video_subject!='=>'news'));
              // $this->db->where('pdf_tab IS NULL');
              // $this->db->or_where("pdf_tab =''");
              // $this->db->group_end();
              // $query1 = $this->db->get('app_pdf');
              // $pdf_sub = $query1->result();
              // echo $this->db->last_query();die('called');
              sql = `SELECT distinct(pdf_tab) as pdf_sub FROM app_pdf WHERE app_hash="${data.app_hash}" AND app_id = ${data.app_id} `;
              var pdf_sub = await query(sql, conn);

              var pdf_detail_data = [];
              var pdf_list1 = [];

              if (pdf_sub) {
                await Promise.all(
                  pdf_sub.map(async (subRow1) => {
                    if (subRow1.pdf_sub) {
                      // $where1 = array('app_hash'=>$data['app_hash'],'app_id'=>$data['app_id'],'pdf_status'=>1);
                      // $this->db->select('*');
                      // $this->db->where($where1);
                      // $this->db->group_start();
                      // $this->db->or_where('pdf_tab IS NULL');
                      // $this->db->or_where("pdf_tab =''");
                      // $this->db->group_end();
                      // $query2 = $this->db->get('app_pdf');
                      //$pdf1_Data = $query2->result();
                      sql = `SELECT * FROM app_pdf WHERE app_hash="${data.app_hash}" AND app_id=1 AND pdf_status=1 OR (pdf_tab IS NULL OR pdf_tab ='')`;
                      var pdf1_Data = await query(sql, conn);
                    } else {
                      // $where1 = array('app_hash'=>$data['app_hash'],'app_id'=>$data['app_id'],'pdf_tab'=>$subRow1->pdf_sub,'pdf_tab!='=>NULL,'pdf_tab!='=>'','pdf_status'=>1);
                      // $this->db->select('*');
                      // $this->db->where($where1);
                      // $query2 = $this->db->get('app_pdf');
                      // $pdf1_Data = $query2->result();
                      sql = `SELECT * FROM app_pdf WHERE app_hash="${data.app_hash}"AND app_id=1 AND pdf_tab="${subRow1.pdf_sub}" AND pdf_tab!=NULL AND pdf_tab!=''AND pdf_status=1`;
                      var pdf1_Data = await query(sql, conn);
                    }
                    var listpdf = {};
                    pdf1_Data.forEach((pdfRow) => {
                      listpdf = {
                        title: pdfRow.title,
                        des: pdfRow.sub_title,
                        url: 'mcllearnoadminpdf/' + pdfRow.pdf_name,
                        //'disclaim'=>$pdfRow->video_disclaim
                      };
                    });
                    // print_r($listpdf);die;
                    if (listpdf) {
                      if (String(subRow1.pdf_sub).length == 0) {
                        pdf_detail_data = [{ name: 'Other', content: listpdf }];
                      } else {
                        pdf_detail_data = [
                          { name: subRow1.pdf_sub, content: listpdf },
                        ];
                      }
                    }
                    pdf_list1.push(pdf_detail_data);
                  })
                );
                //$video_list=$video_detail_data;
              }
            }

            var Temp = [];
            if (user_Data[0].enable_notes_category) {
              // $notes_category_data=$this->db->query("SELECT distinct(category_id) as Catid,category_name FROM  inst_notes_category  where category_status ='active' AND inst_id=".$app_Data['inst_id']." and category_id in (".$user_Data['enable_notes_category'].")")->result_array();
              sql = `SELECT distinct(category_id) as Catid,category_name FROM  inst_notes_category  where category_status ='active' AND inst_id=${app_Data[0].inst_id} and category_id in (${user_Data[0].enable_notes_category})`;
              var notes_category_data = await query(sql, conn);

              // $notes_data=$this->db->query("SELECT * FROM `inst_notes` where inst_id=".$app_Data['inst_id']." and notes_status='active' and notes_category_id in (".$user_Data['enable_notes_category'].")")->result_array();
              sql = `SELECT * FROM inst_notes where inst_id=${app_Data.inst_id} and notes_status='active' and notes_category_id in (${user_Data[0].enable_notes_category})`;
              var notes_data = await query(sql, conn);
              // print_r($category_data);die;
              //echo $this->db->last_query();die;
              var Notescatlist = [];
              notes_category_data.forEach((notesscat) => {
                var listNotes1 = [];
                notes_data.forEach((notes) => {
                  //echo $notes['notes_category_id'];
                  if (notesscat.Catid == notes.notes_category_id) {
                    listNotes1 = {
                      title: notes.notes_title,
                      url: 'learnoadmin/mclinstpdf' + notes.notes_name,
                      cat_id: notes.notes_category_id,
                    };
                  }
                });
                var listNotes2 = [];
                listNotes2.push(listNotes1);
                Notescatlist = [
                  { name: notesscat.category_name, content: listNotes2 },
                ];
                Temp.push(Notescatlist);
              });
            } else {
              Temp = [];
            }
            //$video_list = $catlist;
            // print_r($video_list);die;

            var pdf_list = [];
            pdf_list.push(pdf_list1.concat(Temp));

            //$video_Data = $this->db->query("SELECT * FROM app_video WHERE app_hash = '".$data['app_hash']."' AND video_subject!='news' AND video_status=1 order by video_id desc")->result_array();

            // $where = array('app_hash'=>$data['app_hash'],'app_id'=>$data['app_id']);
            // $this->db->select('distinct(video_subject) as uni_sub');
            // $this->db->where($where);
            // $this->db->group_start();
            // $this->db->where(array('video_subject!='=>'news'));
            // $this->db->or_where('video_subject IS NULL');
            // $this->db->or_where("video_subject =''");
            // $this->db->group_end();
            // $query1 = $this->db->get('app_video');
            // $video_sub = $query1->result();

            sql = `SELECT distinct(video_subject) as uni_sub FROM app_video WHERE app_hash="${data.app_hash}" AND app_id=${data.app_id} AND (video_subject!='news' OR video_subject IS NULL OR video_subject ='' )`;
            var video_sub = await query(sql, conn);
            var video_detail_data = [];
            var listVideo = [];
            var Temp1 = [];
            if (video_sub) {
              await Promise.all(
                video_sub.map(async (subRow) => {
                  if (String(subRow.uni_sub).length == 0) {
                    // $where1 = array('app_hash'=>$data['app_hash'],'app_id'=>$data['app_id'],'video_status'=>1);
                    // $this->db->select('*');
                    // $this->db->where($where1);
                    // $this->db->group_start();
                    // $this->db->or_where('video_subject IS NULL');
                    // $this->db->or_where("video_subject =''");
                    // $this->db->group_end();
                    // $query2 = $this->db->get('app_video');
                    // $video_Data = $query2->result();
                    sql = `select * from app_video where app_hash="${data.app_hash}",app_id=${data.app_id},video_status=1 and (video_subject IS NULL or video_subject ='')`;
                    var video_Data = await query(sql, conn);
                  } else {
                    // $where1 = array('app_hash'=>$data['app_hash'],'app_id'=>$data['app_id'],'video_subject'=>$subRow->uni_sub,'video_subject!='=>NULL,'video_subject!='=>'','video_status'=>1);
                    // $this->db->select('*');
                    // $this->db->where($where1);
                    // $query2 = $this->db->get('app_video');
                    // $video_Data = $query2->result();
                    sql = `SELECT * FROM app_video WHERE app_hash="${data.app_hash}" AND app_id=${data.app_id} AND video_subject= "${subRow.uni_sub}" AND video_subject!=NULL AND video_subject!='' AND video_status=1`;
                    var video_Data = await query(sql, conn);
                  }

                  video_Data.forEach((videoRow) => {
                    listVideo = [
                      {
                        title: videoRow.video_title,
                        desc: videoRow.video_description,
                        url: videoRow.video_link,
                        disclaim: videoRow.video_disclaim,
                      },
                    ];
                  });
                  if (listVideo) {
                    if (String(subRow.uni_sub).length == 0) {
                      video_detail_data = [
                        { name: 'Other', content: listVideo },
                      ];
                    } else {
                      video_detail_data = [
                        { name: subRow.uni_sub, content: listVideo },
                      ];
                    }
                  }
                  Temp1.push(video_detail_data);
                })
              );
              //$video_list=$video_detail_data;
            }
            /*edited by rahul*/
            if (user_Data[0].enable_video_category) {
              //$videocategory_data=$this->db->query("SELECT distinct(inst_video_fs.fs_name),fs_id FROM  inst_video_fs  where fs_status ='Active' AND inst_id=".$app_Data['inst_id']." and fs_id in (".$user_Data['enable_video_category'].")")->result_array();
              sql = `SELECT distinct(inst_video_fs.fs_name),fs_id FROM  inst_video_fs  where fs_status ='Active' AND inst_id=${app_Data[0].inst_id} and fs_id in (${user_Data[0].enable_video_category})`;
              var videocategory_data = await query(sql, conn);
              //print_r($videocategory_data);die;
              //echo $this->db->last_query();die;
              //  $category_data=$this->db->query("SELECT * FROM `inst_videos` where inst_id=".$app_Data['inst_id']." and video_status='Active' and video_subject in (".$user_Data['enable_video_category'].")")->result_array();
              sql = `SELECT * FROM inst_videos where inst_id=${app_Data[0].inst_id} and video_status='Active' and video_subject in (${user_Data[0].enable_video_category})`;
              var category_data = await query(sql, conn);
              // print_r($category_data);die;
              var catlist = [];
              var listVideo2 = [];
              var listVideo1 = [];
              var Temp2 = [];
              videocategory_data.forEach((cat) => {
                category_data.forEach((video) => {
                  if (cat.fs_id == video.video_subject) {
                    if (
                      String(video.video_url).length == 0 &&
                      video.video_file
                    ) {
                      var url = 'mcllearnoadminvideo/' + video.video_file;
                    } else {
                      var url = video.video_url;
                    }
                    listVideo1 = [
                      {
                        title: video.video_title,
                        desc: video.video_desc,
                        url: url,
                        cat_id: video.video_subject,
                        disclaim: '',
                      },
                    ];
                  }
                  listVideo2.push(listVideo1);
                });
                catlist = [{ name: cat.fs_name, content: listVideo2 }];
                Temp2.push(catlist);
              });
            } else {
              catlist = [];
            }
            //$video_list = $catlist;
            // print_r($video_list);die;
            var video_list = [];
            video_list.push(Temp1.concat(Temp2));
            /**/

            if (pdf_list || video_list) {
              var response_array = [
                { flag: 1, pdf: pdf_list, video: video_list },
              ];
            } else {
              var response_array = [
                { flag: 0, pdf: pdf_list, video: video_list },
              ];
            }
            res.send(response_array);
          } else {
            var response_array = {};
            response_array.flag = 5;
            res.send(response_array);
          }
          pool2.releaseConnection(conn2);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
