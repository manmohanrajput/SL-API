const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_fetch_inst_post_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            
            const user_id = req.body.user_id;
            const user_hash = req.body.user_hash;
            const app_hash = req.body.app_hash; // replaced app_id with app_hash
            
            var sql = 'select count(*)as user_count from user_detail where user_id=' + data.user_id + ' and user_hash=\'' + data.user_hash + '\'';
            const user_Data = (await query(sql, conn))[0];
            if(userData.user_count > 0){
                //$appData = $this->db->get_where('mob_app_detail', array('app_hash' => $app_hash))->row_array();
                sql = 'SELECT * from mob_app_detail where app_hash=\'' + app_hash + '\'';
                const appData = (await query(sql, conn))[0];
                if(appData){
                    if((appData.app_id > "10000") && appData.app_id < "10100"){
                        var org_logo_name = appData.org_logo;
                    } else {
                        var org_logo_name = 'http://online-cdn.in/Logo/mob_app_detail/' + appData.org_logo + '';
                    }

                    $instData = [
                        {
                            flag : 1,
                            //org_logo : 'http://mycareerlift.com/upload/mob_app_detail/'.$appData['org_logo'].'',
                            org_logo : org_logo_name,
                            org_name : appData.org_name,
                            org_address : appData.org_address,
                            org_type : appData.org_type,
                            about_us : appData.about_us,
                            city : appData.city,
                            state : appData.state,
                            contact_details : appData.contact_details,
                        }
                    ]

                    const user_id_array = appData.user_id.split(',');
                    var instData;

                    if (user_id_array.includes(user_id) && appData.is_admin == 1) {
                        instData.is_admin = TRUE;
                    } else {
                        instData.is_admin = FALSE;
                    }

                    if (appData.wallet_support == 1) {
                        instData.wallet_support = TRUE;
                    } else {
                        instData.wallet_support = FALSE;
                    }
                } else {
                    instData = [{
                        flag: 0
                    }];
                }
                res.json(instData);
            } else {
                instData.flag = 5;
                res.json(instData);
            }

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;