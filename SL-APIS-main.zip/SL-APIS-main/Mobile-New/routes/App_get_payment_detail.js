const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool5 = require('../config/db5');
const query = require('../utils/query');

router.post('/App_get_payment_detail', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool5.getConnection(async (err, conn5) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          data.payment = [];
          data.app_hash = req.body.app_hash;
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          data.app_id = req.body.app_id;
          var data1 = {};
          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            data.user_id +
            `" and user_hash="` +
            data.user_hash +
            `"`;
          const user_Data = await query(sql, conn);

          if (user_Data[0].user_count > 0) {
            sql = `select institute_details.id,institute_hash,institute_details.flag_institute_management from institute_details left join mob_app_detail on mob_app_detail.inst_id=institute_details.id where mob_app_detail.app_id=${data.app_id}`;
            const inst_data = await query(sql, conn);

            var inst_id = inst_data[0].institute_hash;

            sql = `select * from web_pay_online where inst_hash="${inst_id}" and wpo_status=1 order by wpo_id ASC`;

            //$this->load->model('Common_modal');
            var resultPayOnline = await query(sql, conn5); // = $this->Common_modal->getResult('*',array('inst_hash'=>$inst_id,'wpo_status'=>1), $limit = '', $offset = 0, $order_by = 'wpo_id', $order = 'ASC',$join = array(),'web_pay_online');

            if (resultPayOnline) {
              resultPayOnline.forEach((row) => {
                let result = [
                  {
                    pg: row.wpo_name,
                    payment_gateway_env: row.wpo_environment,
                    payment_gateway_mid: row.wpo_merchant_id,
                    payment_gateway_access_key: row.wpo_access_key,
                    payment_gateway_access_code: row.wpo_access_code,
                    payment_gateway_txn_url: row.wpo_txn_url,
                    payment_gateway_response_url: row.wpo_response_url,
                    payment_gateway_cancel_url: row.wpo_cancel_url,
                    payment_gateway_other_url: row.wpo_other_url,
                    payment_gateway_regis_domain: row.wpo_merchant_website,
                  },
                ];
                data1.payment = result;
              });
              data1.status = 'success';
              data1.flag = 1;
            } else {
              data1.payment = [
                {
                  pg: '',
                  payment_gateway_env: '',
                  payment_gateway_mid: '',
                  payment_gateway_access_key: '',
                  payment_gateway_access_code: '',
                  payment_gateway_txn_url: '',
                  payment_gateway_response_url: '',
                  payment_gateway_cancel_url: '',
                  payment_gateway_other_url: '',
                  payment_gateway_regis_domain: '',
                },
              ];
              data1.status = 'failed';
              data1.flag = 0;
            }
          } else {
            data1.status = 'failed';
            data1.msg = 'user not authorized';
            data1.flag = 5;
          }
          res.json(data1);
          pool5.releaseConnection(conn5);
        }
      });
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
