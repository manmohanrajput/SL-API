const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const query = require('../utils/query');

router.post('/App_fetch_hash_v0', async (req, res) => {

    pool.getConnection(async (err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            var data = {};
            data.app_id = req.body.app_id;
            data.app_hash = req.body.app_hash;
            data.user_id = req.body.user_id;
            var sql = 'select count(*)as mob_count from mob_app_detail where app_id=' + data.app_id + ' and app_hash=\'' + data.app_hash + '\'';
            var mob_Data = (await query(sql, conn))[0];
            var userData = {};
            if(mob_Data.mob_count > 0){
                var app_Data;
                sql = 'SELECT user_hash FROM user_detail WHERE user_id = ' + data.user_id;
                app_Data = (await query(sql, conn))[0];
                if(app_Data){
                    userData.flag = 1;
                    userData.user_hash = app_Data.user_hash;
                } else{
                    userData.flag = 0;
                }
            } else {
                userData.flag = 5;
            }
            const json_response = JSON.stringify(userData);
            res.json(userData);

            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;