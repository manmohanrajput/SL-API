const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_delete_post_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          const post_id = req.body.post_id;
          const user_id = req.body.user_id;
          const user_hash = req.body.user_hash;
          const postData = {};

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            user_id +
            `" and user_hash="` +
            user_hash +
            `"`;
          user_Data = (await query(sql, conn))[0];
          console.log(user_data);

          if (user_Data[0].user_count > 0) {
            if (
              post_id != '' &&
              post_id != NULL &&
              post_id != 0 &&
              post_id != 'null'
            ) {
              var sql = `SELECT max(post_sync_id) as max_post_sync_id FROM edu_post`;
              var maxPostSyncData = await query(sql, conn2);
              var new_post_sync_id = maxPostSyncData.max_post_sync_id + 1;

              sql =
                `UPDATE edu_post SET status = delete SET delete_flag = 1 SET post_sync_id ="` +
                new_post_sync_id +
                `"WHERE id="` +
                post_id +
                `"`;
              await query(sql, conn2);

              postData.flag = 1;
            } else {
              postData.flag = 0;
            }
            res.send(postData);
          } else {
            postData.flag = 5;
            res.send(postData);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
