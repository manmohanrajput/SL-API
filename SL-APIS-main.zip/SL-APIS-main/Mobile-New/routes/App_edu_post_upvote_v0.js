const { json } = require('body-parser');
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');
const query = require('../utils/query');

router.post('/App_edu_post_upvote_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      pool2.getConnection(async (err, conn2) => {
        if (err) {
          console.log(err);
          return res.status(500).send('Server Error');
        } else {
          var data = {};
          data.user_id = req.body.user_id;
          data.user_hash = req.body.user_hash;
          data.app_id = req.body.app_id;
          data.post_id = req.body.post_id;
          var resultData = {};

          var sql =
            `select count(*)as user_count from user_detail where user_id="` +
            data.user_id +
            `" and user_hash="` +
            data.user_hash +
            `"`;
          var user_Data = await query(sql, conn);
          if (user_Data[0].user_count > 0) {
            //print_r ($data);
            console.log('debug', 'inn edu_post_vote_v1 webservice');

            console.log('debug', 'user_id is' + data.user_id + '');
            console.log('debug', 'post_id is' + data.post_id + '');
            sql =
              `SELECT *FROM edu_user_post WHERE user_id="` +
              data.user_id +
              `" AND post_id="` +
              data.post_id +
              `" AND mark_upvote=1 `;
            var row = await query(sql, conn2);

            if (row.num_rows > 0) {
              resultdata.flag = 0;
            } else if (
              data.user_id != null &&
              data.user_id != '' &&
              data.user_id != 0
            ) {
              const edupostdata = [
                {
                  user_id: data.user_id,
                  post_id: data.post_id,
                  type: 'post',
                  mark_upvote: 1,
                  date: Date('y-m-d h:i:s '),
                },
              ];
              // $eduUserPostData = $db2->get_where('edu_user_post', array('user_id' => $data['user_id'], 'post_id' => $data['post_id'], 'type' => 'post'))->row_array();
              //TODO
              sql =
                `SELECT *FROM edu_user_post WHERE user_id ="` +
                data.user_id +
                `" AND post_id="` +
                data.post_id +
                `" AND type = "post"`;
              var eduUserPostData = [];
              eduUserPostData = await query(sql, conn2);

              if (eduUserPostData) {
                sql =
                  `UPDATE edu_user_post SET user_id="` +
                  data.user_id +
                  `",post_id="` +
                  data.post_id +
                  `",type ="post", mark_upvote=1, date ="` +
                  Date('y-m-d h:i:s ') +
                  `" where id ="` +
                  eduUserPostData[0].id +
                  `"`;
                await query(sql, conn2);
              } else {
                sql =
                  `INSERT into edu_user_post(user_id,post_id,type,mark_up)"` +
                  edupostdata +
                  `"`;
                await query(sql, conn2);
              }

              sql =
                `SELECT id,upvote_count FROM edu_post WHERE id="` +
                data.post_id +
                `"`;
              var postRow = await query(sql, conn2);

              if (postRow) {
                sql = `SELECT max(post_sync_id) as max_post_sync_id FROM edu_post`;
                var maxPostSyncData = await query(sql, conn2);
                // $new_post_sync_id = $maxPostSyncData['max_post_sync_id'] + 1;
                var new_post_sync_id =
                  parseInt(maxPostSyncData[0].max_post_sync_id) + 1;
                sql =
                  `UPDATE edu_post SET upvote_count = "` +
                  postRow[0].upvote_count +
                  1 +
                  `" ,post_sync_id ="` +
                  new_post_sync_id +
                  `"  WHERE id ="` +
                  postRow[0].id +
                  `"`;
                await query(sql, conn2);
              }

              resultData.flag = 1;
            } else {
              resultData.flag = 0;
            }
            res.send(resultData);
          } else {
            resultData.flag = 5;
            res.send(resultData);
          }
          pool2.releaseConnection(conn2);
        }
      });

      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
