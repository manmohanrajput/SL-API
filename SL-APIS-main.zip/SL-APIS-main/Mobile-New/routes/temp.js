const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const pool2 = require('../config/db2');

router.post('/App_fetch_inst_post_v0', async (req, res) => {

    pool.getConnection((err, conn) => {
        if(err){
            console.log(err);
            return res.status(500).send('Server Error');
        } else{
            pool2.getConnection((err, conn2) => {
                if(err){
                    console.log(err);
                    return res.status(500).send('Server Error');
                } else{
                    
                    pool.releaseConnection(conn2);
                }
            })
            pool.releaseConnection(conn);
        }
    })

});

module.exports = router;