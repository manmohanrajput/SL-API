const express = require('express');
const router = express.Router();
const pool = require('../config/db');

const query = require('../utils/query');

router.post('/Get_app_config_v0', async (req, res) => {
  pool.getConnection(async (err, conn) => {
    if (err) {
      console.log(err);
      return res.status(500).send('Server Error');
    } else {
      console.log(req.body);
      const app_hash = req.body.app_hash;
      const version_code = req.body.version_code;

      // $appHomeElementData = $this->db->query("SELECT * FROM mob_app_home WHERE mah_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash='" . $app_hash . "') AND mah_status=1 AND mah_tag='home'")->result_array();

      var sql = `SELECT * FROM mob_app_home WHERE mah_app_id=(SELECT app_id FROM mob_app_detail WHERE app_hash=${app_hash}  AND mah_status=1 AND mah_tag='home')`;
      console.log(sql);
      const appHomeElementData = await query(sql, conn);
      console.log(appHomeElementData);
      var resultData = {};
      if (appHomeElementData) {
        appHomeElementData.forEach((appHomeElement) => {
          var app_home_arr = [
            {
              home_element_id: appHomeElement.mah_home_element_id,
              status: appHomeElement.mah_status,
              title_1: appHomeElement.mah_title_1,
              title_2: appHomeElement.mah_title_2,
              seq_no: parseInt(appHomeElement.mah_seq_no),
            },
          ];

          resultData.home_elements = app_home_arr;
        });
        resultData.flag = 1;
      } else {
        resultData.home_elements = [];
        resultData.flag = 0;
      }
      res.send(resultData);
      pool.releaseConnection(conn);
    }
  });
});

module.exports = router;
